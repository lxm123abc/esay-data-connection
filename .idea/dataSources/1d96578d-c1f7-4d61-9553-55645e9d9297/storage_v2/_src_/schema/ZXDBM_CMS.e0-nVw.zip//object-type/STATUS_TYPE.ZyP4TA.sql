create TYPE "STATUS_TYPE"                                                                          as object
(
	operresult 	number(3,0),
	status		number(3,0)
);
/


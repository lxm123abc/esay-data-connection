create package           package_icm_task is

  --
  function f_byte_substr
  (
    i_instring    in varchar2,
    i_begin       in number ,
    i_end         in number
  )   return varchar2;

  function f_get_objecttype
  (
    i_flag           in  number,    --标志 0-对象 1-mapping
    i_elementtype    in  varchar2,  --对象类型
    i_parenttype     in  varchar2   --父对象类型
  ) return number;

  function f_get_actionttype
  (
    i_action         in  varchar2  --操作类型 1-REGIST 2-UPDATE 3-DELETE
  ) return number;

  -- 定时解锁，查看任务解锁情况
  function f_synctask_search
  return number;

  -- 查看当前任务是否被锁
  function f_synctask_search
  (
   i_taskindex    in number
  ) return number;

  --update iptv task result
  procedure sp_synctask_update
  (
    i_correlateid    in varchar2,
    i_result         in number
  );


  --插入对象发布日志表
  procedure sp_object_sync_record_insert
  (
   i_taskindex    in  number,    --对象发布所属工单编号
   i_objectindex  in  number,    --对象index或mapping的index
   i_objectid     in  varchar2,  --对象编码，cms系统根据规则生成
   i_objectcode   in  varchar2,  --文广code，为对象时必填
   i_objecttype   in  number,    --对象类型编号：1-service，2-Category，3-Program......
   i_elementid    in  varchar2,  --对象为mapping时必填，mapping的elementid
   i_elementcode  in  varchar2,  --文广elementcode，对象为mapping时且发布到2.0平台时必填
   i_parentid     in  varchar2,  --对象为mapping时必填，mapping的parentid
   i_parentcode   in  varchar2,  --文广parentcode，对象为mapping时且发布到2.0平台时必填
   i_actiontype   in  number,    --同步类型：1-REGIST，2-UPDATE，3-DELETE
   i_destindex    in  number,    --目标系统index
   i_objetclass   in varchar2,  --对象类别 object或mapping
   o_retcode      out number,    --返回值 0-成功 1-获取键值失败 2-插入失败
   o_desc         out varchar2   --结果描述
  );

  --插入文广对象注入日志表
  procedure sp_object_cpcnt_record_insert
  (
   i_taskindex    in  number,     --任务主键
   i_correlateid  in  varchar2,   --对象所属工单编号
   i_objecttype   in  number,     --对象类型:Program,movie,service,Category,mapping......
   i_actiontype   in  number,     --同步类型:1-REGIST,2-UPDATE,3-DELETE
   i_objectid     in  varchar2,   --对象id,为mapping时对应elementid
   i_objectcode   in  varchar2,   --对象code,为mapping时对应elementcode
   i_parentid     in  varchar2,   --文广parentid,对象为mapping时必填
   i_parentcode   in  varchar2,   --文广parentcod,对象为mapping时必填
   i_retvalue     in  number,     --cms入库结果
   i_retdesc      in  varchar2,   --cms入库结果描述
   o_retcode      out number,     --返回值  0-成功
   o_desc         out varchar2    --结果描述
  );

  --更新网元状态
  procedure sp_synctask_deal_forne
  (
   i_targettype        in  number,
   i_correlateid       in  varchar2,
   i_contentmngxmlurl  in  varchar2,
   i_priority          in  number,
   i_taskindex         in  number,
   i_batchid           in  number,
   i_status            in  number,
   i_target_taskindex  in  number,
   o_retcode           out number,
   o_desc              out varchar2
  );

  --下游发布数据和对象记录回滚操作
  procedure sp_synctask_deal_rollback
  (
   i_taskindex   number
  );

  procedure sp_service_bind
  (
   i_content_id    in  varchar2, --content id
   i_content_type  in  number,   --1:vod 2:series
   o_rtn_value     out number,
   o_rtn_desc      out varchar2
  );

---------------------------------------------------------------------------------
  --deal object
  procedure sp_smg_program
  (
    i_correlateid    in varchar2,
    i_id             in varchar2,
    i_action         in varchar2,
    i_code           in varchar2,
    i_name           in varchar2,
    i_ordernumber    in varchar2,
    i_originalname   in varchar2,
    i_sortname       in varchar2,
    i_searchname     in varchar2,
    i_genre          in varchar2,
    i_actordisplay   in varchar2,
    i_writerdisplay  in varchar2,
    i_originalcountry in varchar2,
    i_language       in varchar2,
    i_releaseyear    in varchar2,
    i_orgairdate     in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision   in varchar2,
    i_description   in varchar2,
    i_pricetaxin    in varchar2,
    i_status        in varchar2,
    i_sourcetype    in varchar2,
    i_seriesflag    in varchar2,
    i_type          in varchar2,
    i_keywords      in varchar2,
    i_tags          in varchar2,
    i_reserve1      in varchar2,
    i_reserve2      in varchar2,
    i_reserve3      in varchar2,
    i_reserve4      in varchar2,
    i_reserve5      in varchar2,
    i_storagetype   in varchar2,
    i_rmediacode    in varchar2,
    i_taskindex     in number,
    o_objindex		  out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  procedure sp_smg_movie
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_type          in varchar2,
    i_fileurl       in varchar2,
    i_sourcedrmtype in varchar2,
    i_destdrmtype   in varchar2,
    i_audiotype     in varchar2,
    i_screenformat  in varchar2,
    i_closedcaptioning  in varchar2,
    i_ocsurl        in varchar2,
    i_duration      in varchar2,
    i_filesize      in varchar2,
    i_bitratetype   in varchar2,
    i_videotype     in varchar2,
    i_audieotype    in varchar2,
    i_resolution    in varchar2,
    i_videoprofile  in varchar2,
    i_systemlayer   in varchar2,
    i_taskindex     in number,
    i_domain		in varchar2,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex		  out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  procedure sp_smg_channel
  (
    i_correlateid       in varchar2,
    i_id                in varchar2,
    i_action            in varchar2,
    i_code              in varchar2,
    i_channelnumber     in varchar2,
    i_channelname       in varchar2,
    i_callsign          in varchar2,
    i_timeshift         in varchar2,
    i_storageduration   in varchar2,
    i_timeshiftduration in varchar2,
    i_description       in varchar2,
    i_country           in varchar2,
    i_state             in varchar2,
    i_city              in varchar2,
    i_zipcode           in varchar2,
    i_type              in varchar2,
    i_subtype           in varchar2,
    i_language          in varchar2,
    i_status            in varchar2,
    i_starttime         in varchar2,
    i_endtime           in varchar2,
    i_macrovision       in varchar2,
    i_videotype         in varchar2,
    i_audiotype         in varchar2,
    i_streamtype        in varchar2,
    i_bilingual         in varchar2,
    i_weburl            in varchar2,
    i_taskindex         in number,
    o_objindex          out number,
    o_objid             out varchar2,
    o_param1            out varchar2,
    o_param2            out varchar2,
    o_retvalue          out number,
    o_retstring         out varchar2
  );

  procedure sp_smg_schedule
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_channelid    in varchar2,
    i_channelcode  in varchar2,
    i_programname  in varchar2,
    i_searchname   in varchar2,   --搜索名称供界面搜索
    i_genre        in varchar2,   --schedule的默认类别(genre)
    i_sourcetype   in varchar2,   --1-VOD   5-Advertisement
    i_startdate    in varchar2,
    i_starttime    in varchar2,
    i_duration     in varchar2,
    i_status       in varchar2,
    i_description  in varchar2,
    i_objecttype   in varchar2,   --关联的对象类型   1-LiveTV Program(直播频道用)  2-VOD Program(虚拟频道用)  3-LiveTV Channel(虚拟频道中引入的直播频道)
    i_objectcode   in varchar2,   --关联对象code  objecttype为1时，填programcode(对于live流，原来没有相关的program关联，需新增program)  objecttype为2时，填programcode(关联已有VOD)  objecttype为3时，填channelcode(关联已有livechannel)
    i_taskindex    in number,
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  );

  procedure sp_smg_picture
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_fileurl      in varchar2,
    i_description  in varchar2,
    i_taskindex    in number,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  );

  procedure sp_smg_column
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_parentcode    in varchar2,
    i_parentid      in varchar2,
    i_name          in varchar2,
    i_sequence      in varchar2,
    i_status        in varchar2,
    i_description   in varchar2,
    i_taskindex     in number,
    o_objindex      out number,
    o_objid         out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  procedure sp_smg_series
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_ordernumber          in varchar2,
    i_originalname         in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_orgairdate           in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision          in varchar2,
    i_price                in varchar2,
    i_volumncount          in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_type                 in varchar2,         --节目内容类型
    i_keywords             in varchar2,         --关键字
    i_tags                 in varchar2,         --关联标签
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  );

  --deal cast
  procedure sp_smg_cast
  (
   i_correlateid          in varchar2,
   i_id                   in varchar2,
   i_action               in varchar2,
   i_code                 in varchar2,
   i_castname             in varchar2,
   i_persondisplayname    in varchar2,
   i_personsortname       in varchar2,
   i_personsearchname     in varchar2,
   i_firstname            in varchar2,
   i_middlename           in varchar2,
   i_lastname             in varchar2,
   i_sex                  in varchar2,
   i_birthday             in varchar2,
   i_hometown             in varchar2,
   i_education            in varchar2,
   i_height               in varchar2,
   i_weight               in varchar2,
   i_bloodgroup           in varchar2,
   i_marriage             in varchar2,
   i_favorite             in varchar2,
   i_webpage              in varchar2,
   i_description          in varchar2,
   i_taskindex            in number,
   o_objindex             out number,
   o_objid                out varchar2,
   o_param1               out varchar2,
   o_param2               out varchar2,
   o_retvalue             out number,
   o_retstring            out varchar2
  );

  --deal castrolemap
  procedure sp_smg_castrolemap
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_castrole             in varchar2,
    i_castid               in varchar2,
    i_castcode             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  );

  --deal physicalchannel
  procedure sp_smg_physicalchannel
  (
   i_correlateid      in varchar2,
   i_id               in varchar2,
   i_action           in varchar2,
   i_code             in varchar2,
   i_channelid        in varchar2,
   i_channelcode      in varchar2,
   i_bitratetype      in varchar2,
   i_multicastip      in varchar2,
   i_multicastport    in varchar2,
   i_taskindex        in number,
   i_domain		      in varchar2,
   o_objindex         out number,
   o_objid            out varchar2,
   o_param1           out varchar2,
   o_param2           out varchar2,
   o_retvalue         out number,
   o_retstring        out varchar2
  );

  procedure sp_smg_service
  (
   i_correlateid            in varchar2,
   i_id                     in varchar2,
   i_action                 in varchar2,
   i_code                   in varchar2,
   i_name                   in varchar2,
   i_type                   in varchar2,
   i_sortname               in varchar2,
   i_searchname             in varchar2,
   i_rentalperiod           in varchar2,
   i_ordernumber            in varchar2,
   i_licensingwindowstart   in varchar2,
   i_licensingwindowend     in varchar2,
   i_price                  in varchar2,
   i_status                 in varchar2,
   i_description            in varchar2,
   i_keywords               in varchar2,
   i_tags                   in varchar2,
   i_reserve1               in varchar2,
   i_reserve2               in varchar2,
   i_reserve3               in varchar2,
   i_reserve4               in varchar2,
   i_reserve5               in varchar2,
   i_taskindex              in number,
   o_objindex               out number,
   o_objid                  out varchar2,
   o_param1                 out varchar2,
   o_param2                 out varchar2,
   o_retvalue               out number,
   o_retstring              out varchar2
  );

  --deal mapping
  procedure sp_smg_sync_mapdel
  (
      i_correlateid       in varchar2,
      i_mappingid         in varchar2,
      i_action            in varchar2,
      i_parenttype        in varchar2,
      i_elementtype       in varchar2,
      i_parentid          in varchar2,
      i_elementid         in varchar2,
      i_parentcode        in varchar2,
      i_elementcode       in varchar2,
      i_type              in varchar2,
      i_sequence          in varchar2,
      i_taskindex         in number,
      o_objindex          out number,
      o_objid             out varchar2,
      o_param1            out varchar2,
      o_param2            out varchar2,
      o_retvalue          out number,
      o_retstring         out varchar2
  );

  procedure sp_smg_sync_mapreg
  (
    i_correlateid in varchar2,
    i_mappingid   in varchar2,
    i_action      in varchar2,
    i_parenttype  in varchar2,
    i_elementtype in varchar2,
    i_parentid    in varchar2,
    i_elementid   in varchar2,
    i_parentcode  in varchar2,
    i_elementcode in varchar2,
    i_type        in varchar2,
    i_validstart  in varchar2,
    i_validend    in varchar2,
    i_sequence    in varchar2,
    i_taskindex   in number,
    o_objindex    out number,
    o_objid       out varchar2,
    o_param1      out varchar2,
    o_param2      out varchar2,
    o_retvalue    out number,
    o_retstring   out varchar2
  );
---------------------------------------------------------------------------------

----------------------------other begin------------------------------------------
  procedure sp_smg_sync_checkactor
  (
    i_actorname    in varchar2,
    i_actortype    in varchar2,
    i_contentindex in number,
    o_retvalue     out number
  );

----------------------------other end---------------------------------------------
end package_icm_task;
/


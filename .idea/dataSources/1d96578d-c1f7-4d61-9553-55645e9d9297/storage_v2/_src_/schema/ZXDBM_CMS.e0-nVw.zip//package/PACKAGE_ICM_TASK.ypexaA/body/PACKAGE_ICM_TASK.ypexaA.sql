create package body           package_icm_task is

------------------------------------------------
  function f_byte_substr
  (
    i_instring    in varchar2,
    i_begin       in number ,
    i_end         in number
  )
  return varchar2
  is
    v_instring      varchar2(4000);
    v_outstring     varchar2(4000);
  begin
    if (i_instring is null) then
      return i_instring;
    end if;

    --substrb是按照字节截取。整个思路是利用汉字占2个字节，如果截取到半个汉字和完整的汉字 length是相同的
    --如果相等，说明 1-begin是完整汉字，此时就截取到begin;否则说明1-begin不是完整汉字，截取到(begin-1)
    if length(substrb(i_instring, 1, i_begin)) = length(substrb(i_instring, 1, i_begin-1)) then
      v_instring := substrb(i_instring, i_begin);
    else
      v_instring := substrb(i_instring, i_begin - 1);
    end if;
    --此时的字符串类似传入的.
    --如果相等,说明1-end不是完整汉字，此时截取到end-1;否则说明1-end是完整汉字，截取到end
    if length(substrb(v_instring, 1, i_end)) = length(substrb(v_instring, 1, i_end+1)) then
      v_outstring := substrb(v_instring, 1, i_end - 1 );
    else
      v_outstring := substrb(v_instring, 1, i_end);
    end if;

    return v_outstring;
  exception
    when others then
      return '';
  end f_byte_substr;

  --根据类型获取对应的数字
  function f_get_objecttype
  (
    i_flag           in  number,    --标志 0-对象 1-mapping
    i_elementtype    in  varchar2,  --对象类型
    i_parenttype     in  varchar2   --父对象类型
  ) return number
  as
    v_result       number(3);      --返回值
    v_elementtype  varchar2(100);  --对象类型
    v_parenttype   varchar2(100);  --父对象类型
  begin

    --初始化
    v_result := -1;

    if(i_flag=0) then
      v_elementtype:=lower(i_elementtype);

      if(v_elementtype='package') then
        v_result:=1;
      elsif(v_elementtype='category') then
        v_result:=2;
      elsif(v_elementtype='program') then
        v_result:=3;
      elsif(v_elementtype='series') then
        v_result:=4;
      elsif(v_elementtype='channel') then
        v_result:=5;
      elsif(v_elementtype='schedule') then
        v_result:=6;
      elsif(v_elementtype='movie') then
        v_result:=7;
      elsif(v_elementtype='physicalchannel') then
        v_result:=8;
      elsif(v_elementtype='schedulerecord') then
        v_result:=9;
      elsif(v_elementtype='picture') then
        v_result:=10;
      elsif(v_elementtype='cast') then
        v_result:=11;
      elsif(v_elementtype='castrolemap') then
        v_result:=12;
      end if;
    else
      v_elementtype:=lower(i_elementtype);
      v_parenttype:=lower(i_parenttype);

      if(v_parenttype='package' and v_elementtype='program')then
        v_result:=21;
      elsif(v_parenttype='package' and v_elementtype='series')then
        v_result:=22;
      elsif(v_parenttype='package' and v_elementtype='channel')then
        v_result:=23;
      elsif(v_parenttype='package' and v_elementtype='schedule')then
        v_result:=24;
      elsif(v_parenttype='picture' and v_elementtype='package')then
        v_result:=25;
      elsif(v_parenttype='category' and v_elementtype='program')then
        v_result:=26;
      elsif(v_parenttype='category' and v_elementtype='series')then
        v_result:=27;
      elsif(v_parenttype='category' and v_elementtype='channel')then
        v_result:=28;
      elsif(v_parenttype='category' and v_elementtype='schedule')then
        v_result:=29;
      elsif(v_parenttype='category' and v_elementtype='package')then
        v_result:=30;
      elsif(v_parenttype='picture' and v_elementtype='category')then
        v_result:=31;
      elsif(v_parenttype='program' and v_elementtype='movie')then
        v_result:=32;
      elsif(v_parenttype='program' and v_elementtype='schedulerecord')then
        v_result:=33;
      elsif(v_parenttype='program' and v_elementtype='castrolemap')then
        v_result:=34;
      elsif(v_parenttype='picture' and v_elementtype='program')then
        v_result:=35;
      elsif(v_parenttype='series' and v_elementtype='program')then
        v_result:=36;
      elsif(v_parenttype='series' and v_elementtype='castrolemap')then
        v_result:=37;
      elsif(v_parenttype='picture' and v_elementtype='series')then
        v_result:=38;
      elsif(v_parenttype='picture' and v_elementtype='channel')then
        v_result:=39;
      elsif(v_parenttype='schedule' and v_elementtype='schedulerecord')then
        v_result:=40;
      elsif(v_parenttype='picture' and v_elementtype='cast')then
        v_result:=41;
      end if;
    end if;

    return v_result;
  exception
    when others then
      return -1;
  end;

  function f_get_actionttype
  (
    i_action         in  varchar2  --操作类型 REGIST UPDATE DELETE
  ) return number
  as
    v_result       number(3);      --返回值
  begin
  	v_result := -1;

  	if (upper(i_action) = 'REGIST') then
      v_result := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_result := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_result := 3;
    end if;
    return v_result;
  exception
    when others then
      return -1;
  end;

  function f_synctask_search
  return number
  is
    v_taskindex     number(10) := 0;
    v_count         number(3) := 0;
    v_subcount      number(3) := 0;
  begin
    --detailindex all is ok in the same taskindex
    --20131128 liuxp 添加taskindex排序 提高解锁查询效率
    for m in (
              select a.taskindex, a.icount
              from
              (
               select taskindex, count(*) as icount
               from zxdbm_cms.icm_smg_synctask_detail
               group by taskindex
              ) a,zxdbm_cms.imp_cms_synctask b
              where a.taskindex = b.taskindex and b.status = 32 order by a.taskindex
             )
    loop
      --init
      v_count := 0;

      for n in (
                select detailindex, code
                from zxdbm_cms.icm_smg_synctask_detail
                where taskindex = m.taskindex
                order by detailindex
               )
      loop
        --find min detailindex status not normal in the same code.
        --by lsm 2013.04.26:删除了过滤条件 and detailindex<n.detailindex
        select count(*) into v_subcount
        from zxdbm_cms.icm_smg_synctask_detail
        where code = n.code and taskindex < m.taskindex;
        if v_subcount = 0 then
          v_taskindex := m.taskindex;
          v_count := v_count + 1;
        --taskindex can not send,goto next taskindex
        else
          exit;
        end if;
      end loop;

      --if detailindex in the same taskindex all ok, then send the taskindex.
      --return the first found
      if v_count = m.icount then
        --delete from zxdbm_iptv.icm_smg_synctask_detail where taskindex = v_taskindex ;
        --update zxdbm_iptv.icm_smg_synctask set status = 30 where taskindex = v_taskindex;
        --commit;
        return v_taskindex;
      end if;
    end loop;

--by lsm :由于所有对象都有插入detail表，并且status为0，故下面的流程没有用到，因此注释掉
--by lxp :20130703 对于不存在detail信息的任务 解锁处理
    for o in (
              select taskindex
              from zxdbm_cms.imp_cms_synctask
              where status = 32
             )
    loop
      select count(*) into v_count
      from zxdbm_cms.icm_smg_synctask_detail
      where taskindex = o.taskindex;
      if v_count = 0 then
        v_taskindex := o.taskindex;
        --update zxdbm_iptv.icm_smg_synctask set status = 30 where taskindex = v_taskindex;
        --commit;
        return v_taskindex;
      end if;
    end loop;

    --find nothing
    v_taskindex := 0;
    return v_taskindex;
  exception
    when others then
      return v_taskindex;
  end f_synctask_search;

  function f_synctask_search
  (
    i_taskindex    in number
  )
  return number
  is
    v_taskindex     number(10) := 0;
    v_count         number(3) := 0;
    v_subcount      number(3) := 0;
  begin
    --detailindex all is ok in the same taskindex
    select taskindex into v_taskindex
    from zxdbm_cms.imp_cms_synctask a
    where a.taskindex = i_taskindex;
--    and a.status = 32;
    for n in (select detailindex, code
              from zxdbm_cms.icm_smg_synctask_detail
              where taskindex = v_taskindex
              order by detailindex
             )
    loop
      --find min detailindex status not normal in the same code.
      --by lsm 2013.04.26:删除了过滤条件 and detailindex<n.detailindex
      select count(*) into v_subcount
      from zxdbm_cms.icm_smg_synctask_detail
      where code = n.code
      and taskindex < v_taskindex;
      if v_subcount = 0 then
        v_count := v_count + 1;
      --taskindex can not send, exit
      else
        v_count := 0;
        exit;
      end if;
    end loop;

    --if detailindex in the same taskindex all ok, then send the taskindex.
    --return
    if v_count <> 0 then
      --delete from zxdbm_iptv.icm_smg_synctask_detail where taskindex = v_taskindex ;
      --update zxdbm_iptv.icm_smg_synctask set status = 30 where taskindex = v_taskindex;
      --commit;
      return v_taskindex;
    end if;


--by lsm 2013.04.26:由于所有对象都有插入detail表，并且status为0，故下面的流程没有用到，因此注释掉
--by lxp :20130703 对于不存在detail信息的任务 解锁处理(delete时部分对象不插入detail表)
--by lxp :20140219 sp_imp_synctask_update时，未更新为32（避免挂死时update后deal过程未执行，该任务无法自动重新执行），去掉status过滤条件
--    for o in ( select taskindex from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindex and status = 32) loop
    for o in ( select taskindex from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindex) loop
      select count(*) into v_count from zxdbm_cms.icm_smg_synctask_detail where taskindex = o.taskindex;
      if v_count = 0 then
        v_taskindex := o.taskindex;
        --update zxdbm_iptv.icm_smg_synctask set status = 30 where taskindex = v_taskindex;
        --commit;
        return v_taskindex;
      end if;
    end loop;


    --find nothing
    v_taskindex := 0;
    return v_taskindex;
  exception
    when others then
      return v_taskindex;
  end f_synctask_search;

-----------------timing task begin-----------------------

  --update iptv task result
  procedure sp_synctask_update
  (
    i_correlateid    in varchar2,
    i_result         in number
  )
  as
  begin
    update zxdbm_cms.imp_cms_synctask set result = nvl(result, 0) + nvl(i_result, 0), status = 20
    where correlateid = i_correlateid;
  exception when others then
    update zxdbm_cms.imp_cms_synctask set result = 1, status = 20 where correlateid = i_correlateid;
  end sp_synctask_update;

  --插入日志对象表
  procedure sp_object_sync_record_insert
  (
   i_taskindex    in number,    --对象发布所属工单编号
   i_objectindex  in number,    --对象index或mapping的index
   i_objectid     in varchar2,  --对象编码，cms系统根据规则生成
   i_objectcode   in varchar2,  --文广code，为对象时必填
   i_objecttype   in number,    --对象类型编号：1-service，2-Category，3-Program......
   i_elementid    in varchar2,  --对象为mapping时必填，mapping的elementid
   i_elementcode  in varchar2,  --文广elementcode，对象为mapping时且发布到2.0平台时必填
   i_parentid     in varchar2,  --对象为mapping时必填，mapping的parentid
   i_parentcode   in varchar2,  --文广parentcode，对象为mapping时且发布到2.0平台时必填
   i_actiontype   in number,    --同步类型：1-REGIST，2-UPDATE，3-DELETE
   i_destindex	  in number,    --目标系统index
   i_objetclass   in varchar2,  --对象类别 object或mapping
   o_retcode      out number,    --返回值 0-成功 1-获取键值失败 2-插入失败
   o_desc         out varchar2   --结果描述
  )
  as
    v_syncindex   number(10,0);  --主键
    v_systemtime  varchar2(14);  --当前时间 yyyymmddhh24miss
  begin
    o_retcode:=0;  --初始化
    o_desc:='';

    -- <add 20130319 对象数据不存在，则无需生成对象日志>
    if i_objectid is null then
    	o_retcode:=0;
    	o_desc:='object data not exist,wgcode='||i_objectcode;
    	return;
	end if;

    v_systemtime:=to_char(sysdate,'yyyymmddhh24miss');

    zxdbm_umap.sp_getmaxvalue('object_sync_record_index', 1, v_syncindex );
    if(v_syncindex = 0)then
      o_retcode:=1;
      o_desc:='get index failed';
      return;
    end if;
    -- <mod 20130320 lxp: 新增reserve1字段，暂存correlateid字段>
    if (lower(i_objetclass) = 'object') then
      insert into zxdbm_cms.object_sync_record
           (syncindex,taskindex,objectindex,objectid,objectcode,objecttype,elementid,
            elementcode,parentid,parentcode,actiontype,starttime,destindex,reserve1)
      values(v_syncindex,0,i_objectindex,i_objectid,i_objectcode,i_objecttype,null,
             null,null,null,i_actiontype,v_systemtime,i_destindex,i_taskindex);
    elsif (lower(i_objetclass) = 'mapping') then
      insert into zxdbm_cms.object_sync_record
            (syncindex,taskindex,objectindex,objectid,objectcode,objecttype,elementid,
             elementcode,parentid,parentcode,actiontype,starttime,destindex,reserve1)
      values(v_syncindex,0,i_objectindex,i_objectid,null,i_objecttype,i_elementid,
            i_elementcode,i_parentid,i_parentcode,i_actiontype,v_systemtime,i_destindex,i_taskindex);
    end if;
  exception when others then
    o_retcode:=2;
    o_desc:='insert zxdbm_cms.object_sync_record failed'||substr(sqlerrm,1,128);
  end sp_object_sync_record_insert;

  --插入文广对象注入日志表
  procedure sp_object_cpcnt_record_insert
  (
   i_taskindex    in  number,     --任务主键
   i_correlateid  in  varchar2,   --对象所属工单编号
   i_objecttype   in  number,     --对象类型:Program,movie,service,Category,mapping......
   i_actiontype   in  number,     --同步类型:1-REGIST,2-UPDATE,3-DELETE
   i_objectid     in  varchar2,   --对象id,为mapping时对应elementid
   i_objectcode   in  varchar2,   --对象code,为mapping时对应elementcode
   i_parentid     in  varchar2,   --文广parentid,对象为mapping时必填
   i_parentcode   in  varchar2,   --文广parentcod,对象为mapping时必填
   i_retvalue     in  number,     --cms入库结果
   i_retdesc      in  varchar2,   --cms入库结果描述
   o_retcode      out number,     --返回值  0-成功
   o_desc         out varchar2    --结果描述
  )
  as
    v_cpcntindex    number(10);   --文广对象注入日志表主键
    v_systime       char(14);     --系统时间
  begin
    o_retcode := 0;
    o_desc := package_imp_icm.static_success;

    v_systime := to_char(sysdate,'YYYYMMDDHH24MISS');

    --获取主键
    zxdbm_umap.sp_getmaxvalue('object_cpcnt_record_index', 1, v_cpcntindex );

    insert into zxdbm_cms.object_cpcnt_record
          (taskindex,cpcntindex,correlateid,objecttype,actiontype,objectid,
          objectcode,parentid,parentcode,starttime,resultcode,resultdesc)
    values(i_taskindex,v_cpcntindex,i_correlateid,i_objecttype,i_actiontype,decode(i_objectid,null,'1',i_objectid),
    i_objectcode,i_parentid,i_parentcode,v_systime,decode(i_retvalue,0,2,3),'cms:'||i_retdesc);
  exception
    when others then
      rollback;
      o_retcode := 1;
      o_desc := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_object_cpcnt_record_insert;

  --更新网元
  --20130709 lxp 下游网元priority字段更新
  procedure sp_synctask_deal_forne
  (
   i_targettype        in  number,
   i_correlateid       in  varchar2,
   i_contentmngxmlurl  in  varchar2,
   i_priority          in  number,
   i_taskindex         in  number,
   i_batchid           in  number,
   i_status            in  number,
   i_target_taskindex  in  number,
   o_retcode           out number,
   o_desc              out varchar2
  )
  as
    v_targetindex    number(10);
    v_platformindex  number(10);   --cnt_platform_sync表主键
    v_objectid       varchar2(255);
    v_statuslist     type_number;  --状态值列表
    v_status         number(10) :=300;   --状态值 按优先级排序 0-待发布 400-发布失败 500-修改发布失败 200-发布中  300-发布成功
    v_operresult     number(10);
    v_systime        char(14) := to_char(sysdate,'yyyymmddhh24miss');
  begin
    --初始化
    o_retcode := 0;
    o_desc := package_imp_icm.static_success;

    --获取目标系统的主键,如果有相同网元，则只发一个按targetindex排序获取最小的那个
    select targetindex into v_targetindex from
    (
     select targetindex from zxdbm_cms.targetsystem where targettype=i_targettype and status=0 order by targetindex
    )
    where rownum=1;

    --更新对象发布记录
    --<20130215 add 'and destindex = v_targetindex'>
    --<20130320 mod 新增reserve1字段，暂存correlateid值>
    update zxdbm_cms.object_sync_record set taskindex=i_target_taskindex
    where reserve1=to_number(i_correlateid) and destindex = v_targetindex;

    --更新发布状态
    for n in(
         select actiontype,objectid,objecttype,parentid,destindex
         from zxdbm_cms.object_sync_record
         where taskindex=i_target_taskindex
        )
    loop
      if (n.actiontype = 1) then
        v_operresult := 10;
      elsif (n.actiontype = 2) then
        v_operresult := 40;
      elsif (n.actiontype = 3) then
        v_operresult := 70;
      end if;

      --部分对象的objectid需要重新获取
      if (n.objecttype = 7) then
        --movie
        select programid into v_objectid from zxdbm_cms.cms_movie where movieid=n.objectid and rownum=1;
      elsif (n.objecttype = 8) then
        --physicalchannel
        select channelid into v_objectid from zxdbm_cms.physicalchannel where physicalchannelid=n.objectid and rownum=1;
      elsif (n.objecttype = 9) then
        --schedulerecord
        select scheduleid into v_objectid from zxdbm_cms.cms_schedulerecord where schedulerecordid=n.objectid and rownum=1;
      --elsif (n.objecttype = 10) then
        --picture
        --select objectid into v_objectid from zxdbm_cms.cnt_target_sync where parentid = n.objectid and rownum = 1;
      elsif (n.objecttype = 32) then
        --program-movie
        v_objectid := n.parentid;
      else
        v_objectid := n.objectid;
      end if;

      --更新每个对象的网元发布数据状态
      update zxdbm_cms.cnt_target_sync
      set status=200, operresult=v_operresult
      where objectid=v_objectid
      and targetindex=n.destindex
      and rownum=1
      returning relateindex
      into v_platformindex;

      select status bulk collect into v_statuslist
      from zxdbm_cms.cnt_target_sync
      where relateindex=v_platformindex;
      for i in 1..v_statuslist.count
      loop
        if (v_statuslist(i) = 0) then
          v_status :=0;
          exit;
        elsif ((v_statuslist(i) = 400) and (v_status != 0)) then
          v_status :=400;
        elsif ((v_statuslist(i) = 500) and (v_status not in (0,400))) then
          v_status :=500;
        elsif ((v_statuslist(i) = 200) and (v_status not in (0,400,500))) then
          v_status :=200;
        elsif ((v_statuslist(i) = 300) and (v_status not in (0,400,500,200))) then
          v_status :=300;
        end if;
      end loop;
      --更新每个对象的平台发布数据的状态
      update zxdbm_cms.cnt_platform_sync
      set status=v_status
      where syncindex=v_platformindex;
    end loop;

    --插入下游网元任务
    insert into zxdbm_cms.cnt_sync_task
          (taskindex,wg_taskindex,batchid,starttime,status,priority,retrytimes,correlateid,contentmngxmlurl,source,destindex)
    values(i_target_taskindex,i_taskindex,i_batchid,v_systime,i_status,nvl(i_priority,5),3,i_correlateid,i_contentmngxmlurl,2,v_targetindex);

  exception
    when others then
      o_retcode :=1;
      o_desc := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_synctask_deal_forne;

  --异常回滚
  procedure sp_synctask_deal_rollback
  (
   i_taskindex   number
  )
  as
  begin
    if (i_taskindex is null) then
      return;
    end if;
    --删除注册操作的网元发布数据
/*
    delete from zxdbm_cms.cnt_target_sync t
    where exists  (
                   select * from zxdbm_cms.object_sync_record r
                   where t.objectindex=r.objectindex
                   and t.objecttype=r.objecttype
                   and r.actiontype=1
                   and r.taskindex=i_taskindex
                  );
*/
    --删除注册操作的平台发布数据
/*
    delete from zxdbm_cms.cnt_platform_sync t
    where exists  (
                   select * from zxdbm_cms.object_sync_record r
                   where t.objectindex=r.objectindex
                   and t.objecttype=r.objecttype
                   and r.actiontype=1
                   and r.taskindex=i_taskindex
                  );
*/
    --删除下游对象记录
    delete from zxdbm_cms.object_sync_record
    where reserve1=i_taskindex;
  exception
    when others then
      null;
  end sp_synctask_deal_rollback;

  procedure sp_service_bind
  (
   i_content_id    in  varchar2, --content id
   i_content_type  in  number,   --1:vod 2:series
   o_rtn_value     out number,
   o_rtn_desc      out varchar2
  )
  as
    auto_vod_service    constant char(11) := 'VOD_SERVICE';
    auto_series_service constant char(14) := 'SERIES_SERVICE';
    type_vod            constant number := 1;
    type_series         constant number := 2;

    illegal_type_error     constant number := 0;
    content_notexist_error constant number := 0;
    service_notexist_error constant number := 0;
    other_error            constant number := 0;

    v_content_index   number(10);
    v_price           number(12,2);
    v_exist           number(10);
    v_srv_id          varchar2(32);
    v_srv_index       number(10);
    v_keyword         varchar2(32);
    v_objecttype      number(3);
    v_objindex        number(10);
    v_mappingid       varchar2(32);
    v_platformlist    type_number;
    v_platformindex   number(10);
    v_targetindexlist type_number;
    v_tarsyncindex    number(10);
    v_logindex        number(10);
    systime           varchar2(14);

    e_illegal_type exception;
    e_content_notexist exception;
    e_service_notexist exception;

  begin
    o_rtn_value := 0;
    o_rtn_desc  := null;
    systime := to_char(sysdate,'yyyymmddhh24miss');

    if (i_content_type not in (type_vod, type_series)) then
      zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
      insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objid1,errordesc,errortime,errobjectname)
      values(v_logindex,2,i_content_id,'type error:'||i_content_type,systime,'zxdbm_cms.sp_service_bind');
      raise e_illegal_type;
    end if;

  begin
      if (i_content_type = type_vod) then
        select programindex,pricetaxin
        into v_content_index,v_price
        from zxdbm_cms.cms_program
        where programid=i_content_id
        and rownum=1;
      else
        select  seriesindex,pricetaxin
        into  v_content_index,v_price
        from zxdbm_cms.cms_series
        where seriesid = i_content_id
        and rownum=1;
      end if;
  exception
    when no_data_found then
      zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
      insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objid1,errordesc,errortime,errobjectname)
      values(v_logindex,2,i_content_id,'object not exists type:'||i_content_type,systime,'zxdbm_cms.sp_service_bind');
      raise e_content_notexist;
  end;

    if (i_content_type = type_vod) then
      v_keyword := auto_vod_service;
    else
      v_keyword := auto_series_service;
    end if;

    select count(*)
      into v_exist
      from zxdbm_cms.imp_sh_cms_config
     where config_name = v_keyword
       and config_type = 5
       and varchar_value = 'Y';
    if (v_exist = 0) then
      return;
    end if;

    --get service id and index
    begin
      select varchar_value
        into v_srv_id
        from zxdbm_cms.imp_sh_cms_config
       where config_name like v_keyword || '_%'
         and number_value = v_price*100
         and config_type = 5
         and rownum = 1;
    exception
      when no_data_found then
        begin
          select varchar_value
            into v_srv_id
            from zxdbm_cms.imp_sh_cms_config
           where config_name = v_keyword || '_OTHER'
             and config_type = 5
             and rownum = 1;
        exception
          when no_data_found then
            null;
        end;
    end;
    begin
      select serviceindex into v_srv_index
      from zxdbm_cms.service
      where serviceid=v_srv_id and rownum=1;
    exception
      when no_data_found then
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
              (logindex,sourcetype,objid1,errordesc,errortime,errobjectname)
        values(v_logindex,2,v_srv_id,'service not exists :',systime,'zxdbm_cms.sp_service_bind');
        raise e_service_notexist;
    end;

    if(i_content_type = type_vod)then
      v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','package');
      --先删除service-program的mapping
      delete from zxdbm_cms.service_program_map m
      where programid = i_content_id and exists
      (
        select * from zxdbm_cms.imp_sh_cms_config c
        where m.serviceid=c.varchar_value
        and config_name like v_keyword || '_%'
        and varchar_value is not null
      );

      --后新增service-program的mapping
      zxdbm_umap.sp_getmaxvalue('cms_service_program_map_index', 1, v_objindex);
      v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
      insert into zxdbm_cms.service_program_map
            (mapindex,mappingid,serviceindex,serviceid,
             programindex,programid,status,createtime)
      values
            (v_objindex,v_mappingid,v_srv_index,v_srv_id,
             v_content_index,i_content_id,0,to_char(sysdate, 'yyyymmddhh24miss'));
    else
      v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','package');
      --先删除service-series的mapping
      delete from zxdbm_cms.service_series_map m
      where seriesid = i_content_id and exists
      (
        select * from zxdbm_cms.imp_sh_cms_config c
        where m.serviceid=c.varchar_value
        and config_name like v_keyword || '_%'
        and varchar_value is not null
      );

      --再新增service-series的mapping
      zxdbm_umap.sp_getmaxvalue('cms_service_series_map_index', 1, v_objindex);
      v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
      insert into zxdbm_cms.service_series_map
            (mapindex,mappingid,serviceindex,serviceid,
             seriesindex,seriesid,status,createtime)
      values
            (v_objindex,v_mappingid,v_srv_index,v_srv_id,
             v_content_index,i_content_id,0,to_char(sysdate, 'yyyymmddhh24miss'));
    end if;

    --删除平台绑定关系
    delete from zxdbm_cms.cnt_platform_sync p
    where elementid=i_content_id and objecttype=v_objecttype
    and exists
    (
     select * from zxdbm_cms.imp_sh_cms_config c
     where p.parentid=c.varchar_value
     and config_name like v_keyword || '_%'
     and varchar_value is not null
    );

    --删除网元绑定关系
    delete from zxdbm_cms.cnt_target_sync t
    where elementid=i_content_id and objecttype=v_objecttype
    and exists
    (
     select * from zxdbm_cms.imp_sh_cms_config c
     where t.parentid=c.varchar_value
     and config_name like v_keyword || '_%'
     and varchar_value is not null
    );

    --新增平台绑定关系
    select distinct platform bulk collect into v_platformlist
    from zxdbm_cms.targetsystem where status=0;
    for i in 1..v_platformlist.count
    loop
      zxdbm_umap.sp_getmaxvalue('cnt_platform_sync_index', 1, v_platformindex);
      insert into zxdbm_cms.cnt_platform_sync
            (syncindex,objecttype,objectindex,objectid,
             elementid,parentid,platform,status,isfiledelete)
      values(v_platformindex,v_objecttype,v_objindex,v_mappingid,
             i_content_id,v_srv_id,v_platformlist(i),300,0);

      --新增网元绑定关系  service不往CDN下发，所以过滤掉CDN网元
      select targetindex bulk collect into v_targetindexlist
      from zxdbm_cms.targetsystem
      where status=0 and platform=v_platformlist(i) and targettype<>3;
      for j in 1..v_targetindexlist.count
      loop
        zxdbm_umap.sp_getmaxvalue('cnt_target_sync_index', 1, v_tarsyncindex);
        insert into zxdbm_cms.cnt_target_sync
              (syncindex,relateindex,objecttype,objectindex,
               objectid,elementid,parentid,targetindex,status,operresult)
        values(v_tarsyncindex,v_platformindex,v_objecttype,v_objindex,
               v_mappingid,i_content_id,v_srv_id,v_targetindexlist(j),300,20);
      end loop;
    end loop;

    o_rtn_value := 0;
    o_rtn_desc := 'bind success';
  exception
    when e_illegal_type then
      o_rtn_value := illegal_type_error;
    when e_content_notexist then
      o_rtn_value := content_notexist_error;
    when e_service_notexist then
      o_rtn_value := service_notexist_error;
    when others then
      o_rtn_desc := substr(sqlerrm, 1, 128);
      zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
      insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objid1,errordesc,errortime,errobjectname)
      values(v_logindex,2,i_content_id,'unknow exeption:'||o_rtn_desc,systime,'zxdbm_cms.sp_service_bind');
      o_rtn_value := other_error;
  end sp_service_bind;

-----------------timing task end-------------------------



-----------------object begin-------------------------
  procedure sp_smg_program
  (
    i_correlateid    in varchar2,
    i_id             in varchar2,
    i_action         in varchar2,
    i_code           in varchar2,
    i_name           in varchar2,
    i_ordernumber    in varchar2,
    i_originalname   in varchar2,
    i_sortname       in varchar2,
    i_searchname     in varchar2,
    i_genre          in varchar2,
    i_actordisplay   in varchar2,
    i_writerdisplay  in varchar2,
    i_originalcountry in varchar2,
    i_language       in varchar2,
    i_releaseyear    in varchar2,
    i_orgairdate     in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision   in varchar2,
    i_description   in varchar2,
    i_pricetaxin    in varchar2,
    i_status        in varchar2,
    i_sourcetype    in varchar2,
    i_seriesflag    in varchar2,
    i_type          in varchar2,
    i_keywords      in varchar2,
    i_tags          in varchar2,
    i_reserve1      in varchar2,
    i_reserve2      in varchar2,
    i_reserve3      in varchar2,
    i_reserve4      in varchar2,
    i_reserve5      in varchar2,
    i_storagetype   in varchar2,
    i_rmediacode    in varchar2,
    i_taskindex     in number,
    o_objindex		  out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_action        varchar2(20);
    v_actiontype    number(3);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_programid     varchar2(32):='0';  --内容id（根据规则自动生成）
    v_licenseindex  number(10);    --牌照方index
    v_licenseid     varchar2(40);  --牌照方id
    v_retcode       number(10);
    v_desc          varchar2(255);
    v_objecttype    number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --check content obj in main table
    select count(*) into v_count from zxdbm_cms.cms_program where cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'program not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'program not exists ';
      return;
    end if;

    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'program',null);
    --删除工作流
    zxdbm_cms.sp_clear_workflow_data
    (
     v_objecttype,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	 i_code,            --对象的文广code
  	 v_retcode,         --返回值 0-成功
     v_desc             --结果描述信息
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 2;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if v_action = 'REGIST' then
      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      o_param1 := v_cpcode;
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取programid 添加异常保护
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'PROG', v_cspid, v_programid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objid := v_programid;

      --获取牌照方id
      begin
        select bindindex, lpid into v_licenseindex, v_licenseid from zxdbm_cms.cms_cpbind where cpid=v_cpcode and rownum=1;
      exception
        when others then
          v_licenseindex:=0;
          v_licenseid:='0';
      end;

      zxdbm_umap.sp_getmaxvalue('cms_program_index', 1, v_objindex);
      o_objindex := v_objindex;
      insert into zxdbm_cms.cms_program
      (
        programindex, programid, cpcontentid, namecn, ordernumber, unicontentid
        , originalnamecn, sortname, country, language, releaseyear, orgairdate
        , licensingstart, licensingend, macrovision, sourcetype, viewpoint
        , programtype, genre, reserve1, reserve2, reserve3, reserve4, reserve5
        , firstletter, effectivedate, expirydate, desccn, pricetaxin
        , seriesflag, isvalid, status, servicekey, entrysource, actors, writers
        , cpindex, cpid, countrytype, licenseindex, licenseid, workflow, workflowlife
      )
      values
      (
        v_objindex, v_programid, i_code, i_name, i_ordernumber, i_code
        , i_originalname, i_sortname, i_originalcountry, i_language, i_releaseyear, i_orgairdate
        , i_licensingwindowstart, i_licensingwindowend, i_macrovision, i_sourcetype, i_keywords
        , f_byte_substr(i_type,1,40), f_byte_substr(i_genre,1,32), i_reserve1, i_reserve2, i_reserve3, i_reserve4, i_reserve5
        , i_searchname, i_licensingwindowstart, i_licensingwindowend, f_byte_substr(i_description, 1, 1024), i_pricetaxin
        , i_seriesflag, i_status, 0, 'CMS', 3, i_actordisplay, i_writerdisplay
        , v_cpindex, v_cpcode, 1, v_licenseindex, v_licenseid, 0, 0
      );

      --根据价格与service绑定
      sp_service_bind(v_programid,1,v_retcode,v_desc);

    --update
    elsif v_action = 'UPDATE' then
      update zxdbm_cms.cms_program
      set namecn        = nvl(i_name, namecn),
          ordernumber   = nvl(i_ordernumber,ordernumber),
          originalnamecn= nvl(i_originalname,originalnamecn),
          sortname      = nvl(i_sortname,sortname),
          country       = nvl(i_originalcountry,country),
          language      = nvl(i_language,language),
          releaseyear   = nvl(i_releaseyear,releaseyear),
          orgairdate    = nvl(i_orgairdate,orgairdate),
          licensingstart= nvl(i_licensingwindowstart,licensingstart),
          licensingend  = nvl(i_licensingwindowend,licensingend),
          macrovision   = nvl(i_macrovision,macrovision),
          sourcetype    = nvl(i_sourcetype,sourcetype),
          viewpoint     = nvl(i_keywords,viewpoint),
          programtype   = nvl(f_byte_substr(i_type,1,40),programtype),
          genre         = nvl(f_byte_substr(i_genre,1,32),genre),
          reserve1      = nvl(i_reserve1,reserve1),
          reserve2      = nvl(i_reserve2,reserve2),
          reserve3      = nvl(i_reserve3,reserve3),
          reserve4      = nvl(i_reserve4,reserve4),
          reserve5      = nvl(i_reserve5,reserve5),
          firstletter   = nvl(i_searchname, firstletter),
          effectivedate = nvl(i_licensingwindowstart,effectivedate),
          expirydate    = nvl(i_licensingwindowend,expirydate),
          pricetaxin    = nvl(i_pricetaxin,pricetaxin),
          seriesflag    = nvl(i_seriesflag,seriesflag),
          desccn        = nvl(f_byte_substr(i_description, 1, 1024), desccn),
          isvalid       = nvl(i_status,isvalid),
          status        = 0,
          actors        = nvl(i_actordisplay, actors),
          writers       = nvl(i_writerdisplay,writers)
      where cpcontentid = i_code
      returning programindex,programid,cpid into o_objindex,v_programid,o_param1;

      o_objid := v_programid;

      --根据价格与service绑定
      sp_service_bind(v_programid,1,v_retcode,v_desc);
    elsif v_action = 'DELETE' then
      select programindex,programid,cpid into o_objindex,o_objid,o_param1
      from zxdbm_cms.cms_program
      where cpcontentid = i_code;
      --删除操作在插入对象日志后更新对象状态，由同步任务删除
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     v_programid,    --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_smg_program;

-- 20130806 liuxp add domain 入参
  procedure sp_smg_movie
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_type          in varchar2,
    i_fileurl       in varchar2,  --newfileurl
    i_sourcedrmtype in varchar2,
    i_destdrmtype   in varchar2,
    i_audiotype     in varchar2,
    i_screenformat  in varchar2,
    i_closedcaptioning  in varchar2,
    i_ocsurl        in varchar2,
    i_duration      in varchar2,
    i_filesize      in varchar2,
    i_bitratetype   in varchar2,
    i_videotype     in varchar2,
    i_audieotype    in varchar2,
    i_resolution    in varchar2,
    i_videoprofile  in varchar2,
    i_systemlayer   in varchar2,
    i_taskindex     in number,
    i_domain		in varchar2,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex		  out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_action        varchar2(20);
    v_actiontype    number(3);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex    number(9); --auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult    number(1);
    v_elementindex  number(10);
    v_movieid       varchar2(32):='0';   --movieid
    v_objecttype    number(3);
    v_retcode       number(10);
    v_desc          varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --check file obj in main table
    --select count(*) into v_count from zxdbm_umap.ucm_file t where t.catagorycode = i_code;
    select count(*) into v_count from zxdbm_cms.cms_movie t where t.cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'movie not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'movie not exists ';
      return;
    end if;

    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'movie',null);
    --删除工作流
    zxdbm_cms.sp_clear_workflow_data
    (
     v_objecttype,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	 i_code,            --对象的文广code
  	 v_retcode,         --返回值 0-成功
     v_desc             --结果描述信息
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 2;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
	if i_workmode = 0 and (v_action = 'REGIST' or v_action = 'UPDATE') then
	  begin
	    select fileurl into o_param2 from zxdbm_cms.cut_full_movie_tmp
	    where moviecode=i_code and rownum=1;
	  exception
	    when no_data_found then
	    o_retvalue := 3;
	    o_retstring := package_imp_icm.static_error||'cut full movie not exist:'||i_code;
	  end;
	end if;
    if v_action = 'REGIST' then
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取movieid
      zxdbm_cms.sp_get_physicalcntidbywgcode(i_code,'MOVI', v_cspid, v_movieid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objid := v_movieid;

      zxdbm_umap.sp_getmaxvalue('cms_movie_index', 1, v_objindex);
      o_objindex := v_objindex;
      --fileurl为相对路径，但传进来的为绝对路径
      insert into zxdbm_cms.cms_movie
      (
        movieindex, movieid, movietype, fileurl, servicekey
        , cpcontentid, sourcedrmtype, destdrmtype, audiotrack
        , screenformat, closedcaptioning, duration, filesize
        , bitratetype, videotype, audiotype, resolution
        , videoprofile, systemlayer, domain, namecn, status, workflow, workflowlife
        , entrysource, reservesel1
      )
      values
      (
        -- filesize 字段为空时，默认为1024Bytes
        -- by liuxp 20130715 bitratetype字段透传 入库时 超出规范(1~7) 默认为4
        v_objindex, v_movieid, i_type, 'NAS'||substr(i_fileurl, instr(i_fileurl, '/', 1,3) ), 'CMS'
        , i_code, to_number(i_sourcedrmtype), to_number(i_destdrmtype), to_number(i_audieotype)
        , to_number(i_screenformat), to_number(i_closedcaptioning), nvl(i_duration,'01300000'), nvl(to_number(i_filesize),1024)
        , case when to_number(i_bitratetype) is null then null
			when to_number(i_bitratetype) between 1 and 7 then to_number(i_bitratetype)
			else 4 end, to_number(i_videotype), to_number(i_audiotype), to_number(i_resolution)
        , to_number(i_videoprofile), to_number(i_systemlayer), i_domain, substr(i_fileurl,instr(i_fileurl, '/', -1) + 1), 0, 0, 0
        , 3, null
       )
       returning filesize
       into o_param1;
    elsif v_action = 'UPDATE' then
      update zxdbm_cms.cms_movie
      set movietype    = nvl(i_type,movietype)
        , sourcedrmtype= nvl(to_number(i_sourcedrmtype),sourcedrmtype)
        , destdrmtype  = nvl(to_number(i_destdrmtype),destdrmtype)
        , audiotrack   = nvl(to_number(i_audieotype),audiotrack)
        , screenformat = nvl(to_number(i_screenformat),screenformat)
        , closedcaptioning = nvl(to_number(i_closedcaptioning),closedcaptioning)
        , duration     = nvl(i_duration,duration)
        , filesize     = nvl(to_number(i_filesize),filesize)
--        , bitratetype  = nvl(to_number(i_bitratetype),bitratetype)
		, bitratetype  = case when to_number(i_bitratetype) is null then bitratetype
			when to_number(i_bitratetype) between 1 and 7 then to_number(i_bitratetype)
			else 4 end
        , videotype    = nvl(to_number(i_videotype),videotype)
        , audiotype    = nvl(to_number(i_audiotype),audiotype)
        , resolution   = nvl(to_number(i_resolution),resolution)
        , videoprofile = nvl(to_number(i_videoprofile),videoprofile)
        , systemlayer  = nvl(to_number(i_systemlayer),systemlayer)
        -- 20140326 domain 允许更新
        , domain       = nvl(i_domain,domain)
        , namecn       = nvl(substr(i_fileurl,instr(i_fileurl, '/', -1) + 1),namecn)
        , status       = 0
        , reservesel1  = null
        , reserveTime1 = null
      where cpcontentid = i_code
      returning movieindex,movieid,filesize
      into o_objindex,o_objid,o_param1;
    elsif v_action = 'DELETE' then
      --20130321 mod lxp: 新增movie删除标记 reservesel1 1-文广已下发删除
      --20131111 mod lxp: 新增movie删除时间标记 reserveTime1 记录当前时间
      update zxdbm_cms.cms_movie
      set reservesel1 = 1, reserveTime1 = to_char(sysdate, 'yyyymmddhh24miss')
      where cpcontentid = i_code
      returning movieindex,movieid,filesize
      into o_objindex,o_objid,o_param1;
/*
      select movieindex,movieid,filesize into o_objindex,o_objid,o_param1
      from zxdbm_cms.cms_movie
      where cpcontentid = i_code;
*/
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_movie;

  procedure sp_smg_channel
  (
    i_correlateid       in varchar2,
    i_id                in varchar2,
    i_action            in varchar2,
    i_code              in varchar2,
    i_channelnumber     in varchar2,
    i_channelname       in varchar2,
    i_callsign          in varchar2,
    i_timeshift         in varchar2,
    i_storageduration   in varchar2,
    i_timeshiftduration in varchar2,
    i_description       in varchar2,
    i_country           in varchar2,
    i_state             in varchar2,
    i_city              in varchar2,
    i_zipcode           in varchar2,
    i_type              in varchar2,
    i_subtype           in varchar2,
    i_language          in varchar2,
    i_status            in varchar2,
    i_starttime         in varchar2,
    i_endtime           in varchar2,
    i_macrovision       in varchar2,
    i_videotype         in varchar2,
    i_audiotype         in varchar2,
    i_streamtype        in varchar2,
    i_bilingual         in varchar2,
    i_weburl            in varchar2,
    i_taskindex         in number,
    o_objindex          out number,
    o_objid             out varchar2,
    o_param1            out varchar2,
    o_param2            out varchar2,
    o_retvalue          out number,
    o_retstring         out varchar2
  )
  as
    v_action        varchar2(20);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_parentindex   number(10);
    v_starttime     varchar2(8);
    v_endtime       varchar2(8);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_channelid     varchar2(32);  --频道id
    v_licenseindex  number(10);    --牌照方index
    v_licenseid     varchar2(40);  --牌照方id
    v_retcode       number(10);
    v_desc          varchar2(255);
    -- 20131121 liuxp 配置实现timeshift的取值
    v_timeshift			number(10); -- 默认 1：时移生效
    v_storageduration	number(10); -- 默认 168小时
    v_timeshiftduration	number(10); -- 默认 120分钟
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;
    v_timeshift			:= 1;
    v_storageduration	:= 168;
    v_timeshiftduration	:= 120;

    --find channel from main table
    select count(*) into v_count from zxdbm_cms.cms_channel where cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'channel not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'channel not exists ';
      return;
    end if;

    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'channel',null);
    --删除工作流
    zxdbm_cms.sp_clear_workflow_data
    (
     v_objecttype,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	 i_code,            --对象的文广code
  	 v_retcode,         --返回值 0-成功
     v_desc             --结果描述信息
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 2;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

      -- 20131121 liuxp timeshift为空 则取配置的值 update时亦用
      begin
        select cfgvalue into v_timeshift from zxdbm_umap.usys_config
        where cfgkey='cms.imp.chan.timeshift' and servicekey='CMS';
        select cfgvalue into v_storageduration from zxdbm_umap.usys_config
        where cfgkey='cms.imp.chan.storageduration' and servicekey='CMS';
        select cfgvalue into v_timeshiftduration from zxdbm_umap.usys_config
        where cfgkey='cms.imp.chan.timeshiftduration' and servicekey='CMS';
      exception when no_data_found then
        null;
      end;

    --regist
    if v_action = 'REGIST' then
/*    --20140319 liuxp 频道允许重名
      --channel name can not same
      select count(*) into v_count from zxdbm_cms.cms_channel where channelname = i_channelname;
      if v_count > 0 then
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||'channel name already exists in channel';
        return;
      end if;
*/
      --check time
      if i_starttime >= i_endtime then
        o_retvalue := 8;
        o_retstring := package_imp_icm.static_error||'channel endtime must be larger than starttime ';
        return;
      end if;

      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取频道id
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'CHAN', v_cspid, v_channelid, v_retcode, v_desc);
      if v_retcode <> 0 then
        rollback;
        o_retvalue := 4;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;
      o_objid := v_channelid;

      --获取牌照方id
      begin
        select bindindex, lpid into v_licenseindex, v_licenseid from zxdbm_cms.cms_cpbind where cpid=v_cpcode and rownum=1;
      exception
        when others then
          v_licenseindex:=0;
          v_licenseid:='0';
      end;

      --channel not exist in main table,insert into main table
      zxdbm_umap.sp_getmaxvalue('cms_ucdn_channel', 1, v_objindex);
      o_objindex := v_objindex;
      o_param1 := nvl(i_channelnumber,999);
      insert into zxdbm_cms.cms_channel
      (
        channelindex, channelid, channelnumber, channelname, callsign
        , timeshift, channeltype, isvalid, starttime, endtime
        , cpcontentid, storageduration, timeshiftduration, description
        , country, zipcode, subtype, language, macrovision, videotype, audiotype
        , streamtype, bilingual, weburl, cpindex, cpid, licenseindex, licenseid, status
        , workflow, workflowlife, entrysource,state,city
      )
      values
      (
        v_objindex, v_channelid, nvl(i_channelnumber,999), i_channelname,i_callsign
        , nvl(i_timeshift,v_timeshift),i_type,i_status, i_starttime,i_endtime
        , i_code,
        decode(nvl(i_timeshift,v_timeshift),1,nvl(i_storageduration,v_storageduration),i_storageduration),
        decode(nvl(i_timeshift,v_timeshift),1,nvl(i_timeshiftduration,v_timeshiftduration),i_timeshiftduration), f_byte_substr(i_description, 1, 1024), i_country
        , i_zipcode, i_subtype, i_language, i_macrovision, i_videotype, i_audiotype
        , i_streamtype, i_bilingual, i_weburl, v_cpindex, v_cpcode, v_licenseindex, v_licenseid, 0
        , 0, 0, 3,i_state,i_city
      );
    --update
    elsif v_action = 'UPDATE' then
/*    --20140319 liuxp 频道允许重名
      --channel name can not same
      select count(*) into v_count from zxdbm_cms.cms_channel where channelname = i_channelname and cpcontentid <> i_code;
      if v_count > 0 then
        o_retvalue := 5;
        o_retstring := package_imp_icm.static_error||'channel name already exists in channel';
        return;
      end if;
*/
      --check time
      if i_starttime is null or i_endtime is null then

        --if 'i_starttime' is null, 'i_endtime' is not null
        if i_starttime is null and i_endtime is not null then
          select starttime into v_starttime
          from zxdbm_cms.cms_channel where cpcontentid = i_code and rownum=1;

          if v_starttime >= i_endtime and v_starttime is not null then
            o_retvalue := 8;
            o_retstring := package_imp_icm.static_error||'channel endtime must be larger than starttime ';
            return;
          end if;
        end if;

        --if 'i_starttime' is not null, 'i_endtime' is null
        if i_starttime is not null and i_endtime is null then
          select endtime into v_endtime
          from zxdbm_cms.cms_channel where cpcontentid = i_code and rownum=1;

          if i_starttime >= v_endtime and v_endtime is not null then
            o_retvalue := 8;
            o_retstring := package_imp_icm.static_error||'channel endtime must be larger than starttime ';
            return;
          end if;
        end if;

        --if 'i_starttime' 'i_endtime' both of them are null
        --then do nothing
      else
        --if 'i_starttime' 'i_endtime' both of them are not null
        if i_starttime >= i_endtime then
          o_retvalue := 8;
          o_retstring := package_imp_icm.static_error||'channel endtime must be larger than starttime ';
          return;
        end if;
      end if;

      update zxdbm_cms.cms_channel
      set channelnumber = nvl( i_channelnumber,channelnumber)
         ,channelname   = nvl( i_channelname,channelname)
         ,callsign      = nvl(i_callsign,callsign)
         ,timeshift     = nvl(i_timeshift,timeshift)
         ,channeltype   = nvl(i_type,channeltype)
         ,isvalid       = nvl(i_status,isvalid)
         ,starttime     = nvl( i_starttime,starttime)
         ,endtime       = nvl(i_endtime,endtime)
         ,cpcontentid   = nvl( i_code,cpcontentid)
--         ,storageduration = nvl(i_storageduration,storageduration) -- 20131121 liuxp
         ,storageduration = decode(nvl(i_timeshift,timeshift),1,nvl(nvl(i_storageduration,storageduration),v_storageduration),nvl(i_storageduration,storageduration))
--         ,timeshiftduration = nvl( i_timeshiftduration,timeshiftduration)
         ,timeshiftduration = decode(nvl(i_timeshift,timeshift),1,nvl(nvl(i_timeshiftduration,timeshiftduration),v_timeshiftduration),nvl(i_timeshiftduration,timeshiftduration))
         ,description   = nvl( i_description,description)
         ,country       = nvl(i_country,country)
         ,zipcode       = nvl( i_zipcode,zipcode)
         ,subtype       = nvl( i_subtype,subtype)
         ,language      = nvl( i_language,language)
         ,macrovision   = nvl( i_macrovision,macrovision)
         ,videotype     = nvl( i_videotype,videotype)
         ,audiotype     = nvl(i_audiotype,audiotype)
         ,streamtype    = nvl( i_streamtype,streamtype)
         ,bilingual     = nvl(i_bilingual,bilingual)
--         ,weburl        = nvl(i_weburl,weburl)
         ,weburl        = decode(nvl(i_type,channeltype),2,nvl(nvl(i_weburl,weburl),'http://127.0.0.1'),nvl(i_weburl,weburl))
         ,status        = 0
         ,state         = nvl(i_state,state)
         ,city          = nvl(i_city,city)
      where cpcontentid = i_code
      return channelindex, channelid, channelnumber into o_objindex, o_objid, o_param1;

      --更新物理频道名称
      if(i_channelname is not null)then
        update zxdbm_cms.physicalchannel set namecn=i_channelname where channelid=(select channelid from zxdbm_cms.cms_channel where cpcontentid = i_code and rownum=1);
      end if;

    --delete
    elsif v_action = 'DELETE' then
      select channelindex, channelid into o_objindex, o_objid
      from zxdbm_cms.cms_channel
      where cpcontentid = i_code and rownum=1;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 7;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_channel;

  procedure sp_smg_physicalchannel
  (
    i_correlateid      in varchar2,
    i_id               in varchar2,
    i_action           in varchar2,
    i_code             in varchar2,
    i_channelid        in varchar2,
    i_channelcode      in varchar2,
    i_bitratetype      in varchar2,
    i_multicastip      in varchar2,
    i_multicastport    in varchar2,
    i_taskindex        in number,
    i_domain		   in varchar2,
    o_objindex         out number,
    o_objid            out varchar2,
    o_param1           out varchar2,
    o_param2           out varchar2,
    o_retvalue         out number,
    o_retstring        out varchar2
  )
  as
    v_action        varchar2(20);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_objindex      number(10);
    v_channelid     varchar2(32);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);      --auto package index
    v_servicebindmapindex number(10);  --pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_starttime     char(14);
    v_endtime       char(14);
    v_physicalchannelid  varchar2(32):='0';  --PhysicanlChannel在CMS内的唯一标识（根据规则自动生成）
    v_srccasttype  varchar2(50);
    v_channelname  varchar2(64);
    v_destcasttype varchar2(50); -- 20140507 lxp 新增
    v_retcode      number(10);
    v_desc         varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --find physicalChannel from main table
    select count(*) into v_count from zxdbm_cms.physicalchannel where cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'physicalchannel not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'physicalchannel not exists ';
      return;
    end if;

    if(i_multicastip is not null)then
      v_srccasttype:='multicast';
    else
      v_srccasttype:='unicast';
    end if;
     --regist
    if v_action = 'REGIST' then
      --判断对应的频道是否存在
      begin
        select channelname, channelid into v_channelname, v_channelid
        from zxdbm_cms.cms_channel
        where cpcontentid=i_channelcode and rownum=1;
      exception
        when others then
          o_retvalue := 1;
          o_retstring := package_imp_icm.static_error||'the logical channel do not exists';
          return;
      end;

      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取物理频道id
      zxdbm_cms.sp_get_physicalcntidbywgcode(i_code,'PHCH', v_cspid, v_physicalchannelid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 2;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      -- 20140507 lxp 查询频道用户访问方式 默认是组播方式 如果有配置 则认为是单播方式
      v_destcasttype := 'multicast';
      select count(*) into v_count from zxdbm_cms.imp_sh_cms_config where
      CONFIG_NAME='CP_IMP_CASTTYPE' and CONFIG_TYPE=11 and VARCHAR_VALUE=v_cspid;
      if v_count > 0 then
        v_destcasttype := 'unicast';
      end if;

      o_objid := v_physicalchannelid;
      o_param1 := v_channelid;

      --channel not exist in main table,insert into main table
      zxdbm_umap.sp_getmaxvalue('physicalchannel', 1, v_objindex);
      o_objindex := v_objindex;
      -- 20131121 liuxp 单播时，unicasturl填写默认值'rtsp://127.0.0.1'
      insert into zxdbm_cms.physicalchannel
      (
       physicalchannelindex, physicalchannelid, destcasttype, srccasttype
       , bitratetype, cpcontentid, channelid, multicastip, multicastport
       , timeshift, storageduration, timeshiftduration, namecn, status
       , workflow, workflowlife, entrysource, domain, unicasturl
      )
      values
      (
       v_objindex, v_physicalchannelid, v_destcasttype/*'unicast'*/, v_srccasttype
       , decode(i_bitratetype,2,4,4,6,4), i_code, v_channelid, i_multicastip, i_multicastport
       , 1, 36, 30, v_channelname, 0
       , 0, 0, 3, i_domain,decode(v_srccasttype,'unicast','rtsp://127.0.0.1','')
      );

    --update
    elsif v_action = 'UPDATE' then
      update zxdbm_cms.physicalchannel
      set  bitratetype = nvl(decode(i_bitratetype,2,4,4,6,null,null,4),bitratetype)
          ,multicastip = nvl(i_multicastip,multicastip)
          ,multicastport = nvl(i_multicastport,multicastport)
          -- 20140326 domain 允许更新
          , domain       = nvl(i_domain,domain)
          ,status      = 0
      where cpcontentid = i_code
      returning physicalchannelindex, physicalchannelid, channelid into o_objindex, o_objid, o_param1;

    --delete
    elsif v_action = 'DELETE' then
      select physicalchannelindex, physicalchannelid, channelid into o_objindex, o_objid, o_param1
      from zxdbm_cms.physicalchannel
      where cpcontentid = i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'physicalchannel',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
    exception
      when others then
        rollback;
        o_retvalue := 4;
        o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_physicalchannel;

  procedure sp_smg_service
  (
   i_correlateid            in varchar2,
   i_id                     in varchar2,
   i_action                 in varchar2,
   i_code                   in varchar2,
   i_name                   in varchar2,
   i_type                   in varchar2,
   i_sortname               in varchar2,
   i_searchname             in varchar2,
   i_rentalperiod           in varchar2,
   i_ordernumber            in varchar2,
   i_licensingwindowstart   in varchar2,
   i_licensingwindowend     in varchar2,
   i_price                  in varchar2,
   i_status                 in varchar2,
   i_description            in varchar2,
   i_keywords               in varchar2,
   i_tags                   in varchar2,
   i_reserve1               in varchar2,
   i_reserve2               in varchar2,
   i_reserve3               in varchar2,
   i_reserve4               in varchar2,
   i_reserve5               in varchar2,
   i_taskindex              in number,
   o_objindex               out number,
   o_objid                  out varchar2,
   o_param1                 out varchar2,
   o_param2                 out varchar2,
   o_retvalue               out number,
   o_retstring              out varchar2
  )
  as
    v_action        varchar2(20);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_serviceid     varchar2(32);
    v_retcode       number(10);
    v_desc          varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --action
    select count(*) into v_count from zxdbm_cms.service where servicecode = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'service not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'service not exists ';
      return;
    end if;


    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'package',null);
    --删除工作流
    zxdbm_cms.sp_clear_workflow_data
    (
     v_objecttype,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	 i_code,            --对象的文广code
  	 v_retcode,         --返回值 0-成功
     v_desc             --结果描述信息
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 2;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    --regist
    if v_action = 'REGIST' then
      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      --service name + cpindex  can not same
      select count(*) into v_count from zxdbm_cms.service where servicename = i_name and cpindex = v_cpindex;
      if v_count > 0 then
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||'service name + cpcode already exists in service';
        return;
      end if;
      --serveic not exist in main table,insert into main table
      zxdbm_umap.sp_getmaxvalue('ucdn_service_index', 1, v_objindex);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取serviceid
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'PACK', v_cspid, o_objid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 4;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objindex := v_objindex;
      -- 20131121 liuxp 3.0规范feecode单位为分 cp下发单位为元
      insert into zxdbm_cms.service
      (
        serviceindex, servicecode, serviceid, servicename, feecode
        , description, status, effecttime
        , createtime, modtime, cpindex, workflow, workflowlife
      )
      values
      (
        v_objindex, i_code, o_objid , i_name, nvl(substr(to_char(to_number(i_price)*100),1,8),'1')
        , f_byte_substr(i_description, 1, 1024), 0, i_licensingwindowstart
        ,  v_nowtime, v_nowtime, v_cpindex, 0, 0
      );
    --update
    elsif v_action = 'UPDATE' then
      --service name + cpindex  can not same
      select count(*) into v_count from zxdbm_cms.service where servicename = i_name and cpindex = v_cpindex and servicecode <> i_code;
      if v_count > 0 then
        o_retvalue := 5;
        o_retstring := package_imp_icm.static_error||'service name + cpcode already exists in service';
        return;
      end if;
      --update
      update zxdbm_cms.service
      set servicename = nvl(i_name,servicename),
          modtime     = v_nowtime,
          feecode     = nvl(substr(to_char(to_number(i_price)*100),1,8),feecode),
          description = nvl(f_byte_substr(i_description, 1, 1024), description),
          status      = 0
      where servicecode = i_code
      returning serviceindex, serviceid into o_objindex, o_objid;
    --delete
    elsif v_action = 'DELETE' then
      select serviceindex, serviceid into o_objindex, o_objid
      from zxdbm_cms.service
      where servicecode = i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 7;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_service;

procedure sp_smg_cast
  (
   i_correlateid          in varchar2,
   i_id                   in varchar2,
   i_action               in varchar2,
   i_code                 in varchar2,
   i_castname             in varchar2,
   i_persondisplayname    in varchar2,
   i_personsortname       in varchar2,
   i_personsearchname     in varchar2,
   i_firstname            in varchar2,
   i_middlename           in varchar2,
   i_lastname             in varchar2,
   i_sex                  in varchar2,
   i_birthday             in varchar2,
   i_hometown             in varchar2,
   i_education            in varchar2,
   i_height               in varchar2,
   i_weight               in varchar2,
   i_bloodgroup           in varchar2,
   i_marriage             in varchar2,
   i_favorite             in varchar2,
   i_webpage              in varchar2,
   i_description          in varchar2,
   i_taskindex            in number,
   o_objindex             out number,
   o_objid                out varchar2,
   o_param1               out varchar2,
   o_param2               out varchar2,
   o_retvalue             out number,
   o_retstring            out varchar2
  )
  as
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_action        varchar2(20);
    v_castid        varchar2(32);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select count(*) into v_count from zxdbm_cms.castcdn where castcode=i_code;
    if(v_count>0 and upper(i_action) = 'REGIST')then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'cast not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'cast not exists ';
      return;
    end if;

    --regist
    if (v_action = 'REGIST') then
      --insert into a new cast
      zxdbm_umap.sp_getmaxvalue('cms_cast', 1, v_objindex);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --get castid
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'CAST', v_cspid, o_objid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 2;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objindex := v_objindex;
      insert into zxdbm_cms.castcdn
      (
       castindex, castid, castname, persondisplayname, personsortname, personsearchname
       , firstname, middlename, lastname, sex, birthday, hometown, education
       , height, weight, bloodgroup, marriage, favorite, webpage, description
       , status, castcode
      )
      values
      (
       v_objindex, o_objid, decode(i_castname, null, i_firstname, i_castname), i_persondisplayname, i_personsortname, i_personsearchname
       , i_firstname, i_middlename, i_lastname, i_sex, i_birthday, i_hometown, i_education
       , i_height, i_weight, decode(lower(i_bloodgroup),'a',1,'b',2,'o',3,'ab',4), i_marriage, i_favorite, i_webpage, i_description
       , 0, i_code
      );
    elsif(v_action = 'UPDATE')then
      update zxdbm_cms.castcdn
      set  castname          = nvl(i_castname,castname),
           persondisplayname = nvl(i_persondisplayname,persondisplayname),
           personsortname    = nvl(i_personsortname,personsortname),
           personsearchname  = nvl(i_personsearchname,personsearchname),
           firstname         = nvl(i_firstname,firstname),
           middlename        = nvl(i_middlename,middlename),
           lastname          = nvl(i_lastname,lastname),
           sex               = nvl(i_sex,sex),
           birthday          = nvl(i_birthday,birthday),
           hometown          = nvl(i_hometown,hometown),
           education         = nvl(i_education,education),
           height            = nvl(i_height,height),
           weight            = nvl(i_weight,weight),
           bloodgroup        = nvl(decode(lower(i_bloodgroup),'a',1,'b',2,'o',3,'ab',4),bloodgroup),
           marriage          = nvl(i_marriage,marriage),
           favorite          = nvl(i_favorite,favorite),
           webpage           = nvl(i_webpage,webpage),
           modtime           = to_char(sysdate,'yyyymmddhh24miss'),
           description       = nvl(i_description,description),
           status            = 0
      where castcode=i_code
      returning castindex, castid into o_objindex, o_objid;
    elsif (upper(i_action) = 'DELETE') then
      select castindex, castid into o_objindex, o_objid
      from zxdbm_cms.castcdn
      where castcode=i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'cast',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||'cast fail'||substr(sqlerrm,1,128);
  end sp_smg_cast;

  procedure sp_smg_castrolemap
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_castrole             in varchar2,
    i_castid               in varchar2,
    i_castcode             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  )
  as
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_action        varchar2(20);
    v_castindex     number(10);
    v_castid        varchar2(255);
    v_castrolemapid varchar2(32);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select count(*) into v_count from zxdbm_cms.castrolemap where castrolemapcode=i_code;
    if(v_count>0 and upper(i_action) = 'REGIST')then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'castrolemap not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'castrolemap not exists ';
      return;
    end if;

    --regist
    if (v_action = 'REGIST') then
      --insert into a new castrolemap
      begin
        select castindex,castid into v_castindex, v_castid
        from zxdbm_cms.castcdn
        where castcode=i_castcode;
        o_param1 := v_castid;
      exception
      when others then
        o_retvalue := 2;
        o_retstring := package_imp_icm.static_error||'castrolemap related cast not exists';
        return;
      end;

      zxdbm_umap.sp_getmaxvalue('castrolemap_index', 1, v_objindex);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --get castrolemapid
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'CARM', v_cspid, o_objid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objindex := v_objindex;
      insert into zxdbm_cms.castrolemap
      (
       castrolemapindex, castrolemapid, castindex, castid, castrole,roletype
       , status, castrolemapcode
      )
      values
      (
       v_objindex, o_objid, v_castindex, v_castid, i_castrole,decode(i_castrole,'导演',1,'演员',2,'歌手',3,1)
       , 0, i_code
      );
    elsif(v_action = 'UPDATE')then
      if (i_castcode is not null) then
        begin
          select castindex,castid
          into v_castindex,v_castid
          from zxdbm_cms.castcdn
          where castcode=i_castcode
          and rownum=1;
        exception
          when no_data_found then
            o_retvalue := 4;
            o_retstring := package_imp_icm.static_error||'castrolemap related cast not exists';
            return;
        end;
      end if;
      update zxdbm_cms.castrolemap
      set  castindex   = nvl(v_castindex,castindex),
           castid      = nvl(v_castid,castid),
           castrole    = nvl(i_castrole,castrole),
           roletype    = decode(i_castrole,null,roletype,'导演',1,'演员',2,'歌手',3,1),
           status      = 0
      where castrolemapcode=i_code
      returning castrolemapindex,castrolemapid,castid into o_objindex,o_objid,o_param1;
    elsif (upper(i_action) = 'DELETE') then
      select castrolemapindex,castrolemapid,castid into o_objindex,o_objid,o_param1
      from zxdbm_cms.castrolemap
      where castrolemapcode=i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'castrolemap',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/

  exception
    when others then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_castrolemap;

  procedure sp_smg_schedule
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_channelid    in varchar2,
    i_channelcode  in varchar2,
    i_programname  in varchar2,
    i_searchname   in varchar2,   --搜索名称供界面搜索
    i_genre        in varchar2,   --schedule的默认类别(genre)
    i_sourcetype   in varchar2,   --1-VOD   5-Advertisement
    i_startdate    in varchar2,
    i_starttime    in varchar2,
    i_duration     in varchar2,
    i_status       in varchar2,
    i_description  in varchar2,
    i_objecttype   in varchar2,   --关联的对象类型   1-LiveTV Program(直播频道用)  2-VOD Program(虚拟频道用)  3-LiveTV Channel(虚拟频道中引入的直播频道)
    i_objectcode   in varchar2,   --关联对象code  objecttype为1时，填programcode(对于live流，原来没有相关的program关联，需新增program)  objecttype为2时，填programcode(关联已有VOD)  objecttype为3时，填channelcode(关联已有livechannel)
    i_taskindex    in number,
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  )
  as
    v_action        varchar2(20);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_starttime     char(14);
    v_startdate     char(8);
    v_starttime1    char(6);
    v_duration      char(6);
    v_endtime       char(14);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_scheduleid    varchar2(32);  --该schedule 在CMS 内的唯一标识（根据规则自动生成）
    v_schedulerecordindex  number(10);
    v_schedulerecordid     varchar2(32);  --CMS内的唯一标识（根据规则自动生成）
    v_schedulerecordcode   varchar2(128);
    v_channelid     varchar2(32);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
    v_tmp_start		varchar2(20);
    v_opertime		number(10);
    v_domain        number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select count(*) into v_count from zxdbm_cms.cms_schedule where cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'schedule not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'schedule not exists ';
      return;
    end if;

    -- <20130320 lxp add 开始时间判断 单位：分钟 >
    begin
      select to_number(cfgvalue) into v_opertime
      from zxdbm_umap.usys_config
      where cfgkey = 'cms.schedule.cantoperate.time' and servicekey='CMS';
    exception
      when no_data_found then
        v_opertime := 0;
    end;

    v_tmp_start := i_startdate||i_starttime;
    if (v_opertime <> 0 and to_date(v_tmp_start, 'yyyymmddhh24miss') < sysdate + v_opertime/(24*60)) then
    	o_retvalue := 7;
      	o_retstring := package_imp_icm.static_error||'schedule need to be started '||v_opertime||' min before';
    	return;
	end if;
    -- <20130320 lxp add >

    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'schedule',null);
    --删除工作流
    zxdbm_cms.sp_clear_workflow_data
    (
     v_objecttype,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
     i_code,            --对象的文广code
     v_retcode,         --返回值 0-成功
     v_desc             --结果描述信息
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 2;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    --regist
    if v_action = 'REGIST' then
      --check channel
      begin
        select channelid into v_channelid from zxdbm_cms.cms_channel where cpcontentid = i_channelcode;
        o_param1 := v_channelid;
      exception
      when others then
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||'schedule related channel not exists ';
        return;
      end;

      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取schedule ID
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'SCHE', v_cspid, v_scheduleid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 4;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objid := v_scheduleid;

      --insert into a new schedule
      zxdbm_umap.sp_getmaxvalue('cms_schedule', 1, v_objindex);
      o_objindex := v_objindex;

      --status字段需要确认
      insert into zxdbm_cms.cms_schedule
      (
        scheduleindex, scheduleid, channelid, programname, startdate, starttime
        , duration, isvalid, cpcontentid, description, unicontentid
        , status, workflow, workflowlife, servicekey, entrysource,cpindex,cpid
      )
      values
      (
        v_objindex, v_scheduleid, v_channelid, i_programname, i_startdate, i_starttime
        , i_duration, to_number(i_status), i_code, f_byte_substr(i_description, 1, 1024), i_code
        , 0, 0, 0, 'CMS', 3,v_cpindex,v_cpcode
      );

      --新增一个插入语句，同时根据该频道下面物理频道的个数，插入schedulerecord表物理频道下面插入一条对应的schedulerecord
      for c in (select physicalchannelid,domain from zxdbm_cms.physicalchannel where channelid=v_channelid)
      loop
        --获取schedulerecord ID
        zxdbm_cms.sp_get_physicalcontentid('SCHERD',v_schedulerecordid);
        --获取schedulerecord code
        zxdbm_cms.sp_get_wgcodebyphysicalcntid(v_schedulerecordid,v_schedulerecordcode);

        zxdbm_umap.sp_getmaxvalue('cms_schedulerecord', 1, v_schedulerecordindex);
        insert into zxdbm_cms.cms_schedulerecord
        (
         schedulerecordindex, schedulerecordid, scheduleid, physicalchannelid
         , startdate, starttime, duration, cpcontentid, description, isarchive
         , domain, hotdegree, namecn, status, workflow, workflowlife, servicekey
         , entrysource
        )
        values
        (
         v_schedulerecordindex, v_schedulerecordid, v_scheduleid, c.physicalchannelid
         , i_startdate, i_starttime, i_duration, v_schedulerecordcode, i_description, 1
         , c.domain, 1, nvl(i_programname,i_code), 0, 0, 0, 'CMS'
         , 3
        );

      end loop;

      v_starttime := i_startdate || i_starttime;
      v_endtime := to_char(
                           (to_date(i_startdate || i_starttime,'yyyymmddhh24miss')
                            + to_number(substr(i_duration,1,2))/24
                            + to_number(substr(i_duration,3,2))/24/60
                            + to_number(substr(i_duration,5,2))/24/60/60
                           )
                           ,'yyyymmddhh24miss'
                           );
      --delete interface time
      delete from zxdbm_cms.cms_schedulerecord
      where scheduleid in
      (
       select scheduleid
       from zxdbm_cms.cms_schedule
       where channelid = v_channelid
       and startdate||starttime < v_endtime
       and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
       and cpcontentid <> i_code
      );

      --删除平台
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=6 and exists
      (
       select * from zxdbm_cms.cms_schedule
       where p.objectid=scheduleid and channelid = v_channelid
       and startdate||starttime < v_endtime
       and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
       and cpcontentid <> i_code
      );

      --网元发布数据
      delete from zxdbm_cms.cnt_target_sync t
      where t.objecttype=6 and exists
      (
       select * from zxdbm_cms.cms_schedule
       where t.objectid=scheduleid and channelid = v_channelid
       and startdate||starttime < v_endtime
       and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
       and cpcontentid <> i_code
      );

      --删除schedule对象
      delete from zxdbm_cms.cms_schedule
      where channelid = v_channelid
      and startdate||starttime < v_endtime
      and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
      and cpcontentid <> i_code;
    --update
    elsif v_action = 'UPDATE' then
      if (i_channelcode is not null) then
        select channelid into v_channelid from zxdbm_cms.cms_channel where cpcontentid = i_channelcode;
      end if;
      update zxdbm_cms.cms_schedule
      set channelid   = nvl(v_channelid, channelid),
          programname = nvl(i_programname, programname),
          startdate   = nvl(i_startdate, startdate),
          starttime   = nvl(i_starttime, starttime),
          duration    = nvl(i_duration,duration),
          isvalid     = nvl(to_number(i_status),isvalid),
          description = nvl(f_byte_substr(i_description, 1, 1024), description),
          unicontentid= nvl(i_code, unicontentid),
          status      = 0
      where cpcontentid = i_code
      returning startdate, starttime, duration, scheduleindex, scheduleid, channelid
      into v_startdate, v_starttime1, v_duration, o_objindex, o_objid, o_param1;

      -- 20140326 domain值允许更新
      begin
        select domain into v_domain from zxdbm_cms.physicalchannel a
        where exists
        (select b.physicalchannelid from zxdbm_cms.cms_schedulerecord b
        where scheduleid=o_objid and a.physicalchannelid=b.physicalchannelid);
      exception
        when no_data_found then
          v_domain := '';
      end;

      update zxdbm_cms.cms_schedulerecord
      set startdate   = nvl(i_startdate, startdate),
          starttime   = nvl(i_starttime, starttime),
          duration    = nvl(i_duration,duration),
          domain      = nvl(v_domain,domain),
          status      = 0
      where scheduleid=o_objid;

      --删除同一频道下时间冲突的计划
      if( (i_startdate is not null) or (i_starttime is not null) or (i_duration is not null) )then
        v_starttime := v_startdate||v_starttime1;
        v_endtime := to_char((to_date(v_startdate || v_starttime1,'yyyymmddhh24miss') + to_number(substr(v_duration,1,2))/24 + to_number(substr(v_duration,3,2))/24/60 + to_number(substr(v_duration,5,2))/24/60/60),'yyyymmddhh24miss');
        --delete interface time
        delete from zxdbm_cms.cms_schedulerecord
        where scheduleid in
        (
         select scheduleid
         from zxdbm_cms.cms_schedule where channelid = v_channelid
         and startdate||starttime < v_endtime and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime and cpcontentid <> i_code
        );
        --删除平台
        delete from zxdbm_cms.cnt_platform_sync p
        where p.objecttype=6 and exists
        (
         select * from zxdbm_cms.cms_schedule
         where p.objectid=scheduleid
         and channelid = v_channelid
         and startdate||starttime < v_endtime
         and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
         and cpcontentid <> i_code
        );

        --网元发布数据
        delete from zxdbm_cms.cnt_target_sync t
        where t.objecttype=6 and exists
        (
         select * from zxdbm_cms.cms_schedule
         where t.objectid=scheduleid
         and channelid = v_channelid
         and startdate||starttime < v_endtime
         and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime
         and cpcontentid <> i_code
        );

        delete from zxdbm_cms.cms_schedule where channelid = v_channelid
        and startdate||starttime < v_endtime and to_char((to_date(startdate||starttime,'yyyymmddhh24miss') + to_number(substr(duration,1,2))/24 + to_number(substr(duration,3,2))/24/60 + to_number(substr(duration,5,2))/24/60/60),'yyyymmddhh24miss') > v_starttime and cpcontentid <> i_code;
      end if;

    --delete
    elsif v_action = 'DELETE' then
      select scheduleindex, scheduleid, channelid into o_objindex, o_objid, o_param1
      from zxdbm_cms.cms_schedule
      where cpcontentid = i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_schedule;

  procedure sp_smg_picture
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_fileurl      in varchar2,
    i_description  in varchar2,
    i_taskindex    in number,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  )
  as
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_action        varchar2(20);
    v_pictureid     varchar2(32);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
    v_path			varchar2(256);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select count(*) into v_count from zxdbm_cms.picture where picturecode=i_code;
    if(v_count>0 and upper(i_action) = 'REGIST')then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'picture not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'picture not exists ';
      return;
    end if;

    --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    if i_workmode = 0 and (v_action = 'REGIST' or v_action = 'UPDATE') then
	  begin
	    select fileurl into o_param2 from zxdbm_cms.cut_full_picture_tmp
	    where picturecode=i_code and rownum=1;

	    --更新picture的路径，默认url只有文件名称
        zxdbm_cms.sp_cms_getpath(2, v_retcode, v_path);
        if(v_retcode = 0)then
          v_path := v_path||'/picture/'||o_param2;
        end if;

	  exception
	    when no_data_found then
	    o_retvalue := 2;
	    o_retstring := package_imp_icm.static_error||'cut full picture not exist:'||i_code;
	  end;
	end if;

    --regist
    if (v_action = 'REGIST') then
      --insert into a new picture
      zxdbm_umap.sp_getmaxvalue('cms_picture_index', 1, v_objindex);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --get pictureid
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'PICT', v_cspid, o_objid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 2;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objindex := v_objindex;
      insert into zxdbm_cms.picture
      (
       pictureindex, pictureid, pictureurl, description, status, picturecode
      )
      values
      (
       v_objindex, o_objid, decode(v_path,null,i_fileurl,v_path), i_description, 0, i_code
      );
    elsif(v_action = 'UPDATE')then
      update zxdbm_cms.picture
      set  description = nvl(i_description,description),
           status      = 0
      where picturecode=i_code
      returning pictureindex, pictureid into o_objindex, o_objid;
    elsif (upper(i_action) = 'DELETE') then
      select pictureindex, pictureid into o_objindex, o_objid
      from zxdbm_cms.picture
      where picturecode=i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'picture',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_picture;


  procedure sp_smg_column
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_parentcode    in varchar2,
    i_parentid      in varchar2,
    i_name          in varchar2,
    i_sequence      in varchar2,
    i_status        in varchar2,
    i_description   in varchar2,
    i_taskindex     in number,
    o_objindex      out number,
    o_objid         out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_action        varchar2(20);  -- REGIST, UPDATE, DELETE
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_elementindex  number(10);
    v_categoryid    varchar2(32);
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
    v_countvod      number(10);
    v_countseries   number(10);
    v_countchannel  number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --action
    select count(*) into v_count from zxdbm_cms.categorycdn where catagorycode = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'category not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'category not exists ';
      return;
    end if;

    --此处没有修改
    if v_action =  'REGIST' then
      select count(*) into v_count from zxdbm_cms.categorycdn t
      where catagorycode = i_parentcode;
      if(v_count = 0)then
        --父栏目不存在
        select count(*) into v_count from zxdbm_cms.icm_category_mapping t where t.categoryid = i_parentcode;
        if (v_count = 0) then
          rollback;
          o_retvalue := 2;
          o_retstring := package_imp_icm.static_error||'can not find parent column when regist category:' || i_code;
          return;
        else
          select a.categoryindex, a.categoryid into v_parentindex, v_categoryid
          from zxdbm_cms.categorycdn a, zxdbm_cms.icm_category_mapping b
          where a.categoryid = b.columncode
          and b.categoryid = i_parentcode and rownum = 1;
        end if;
      else
        select categoryindex, categoryid into v_parentindex, v_categoryid from zxdbm_cms.categorycdn where catagorycode = i_parentcode and rownum = 1;
      end if;

      --校验同父节点下的子栏目名称是否唯一
      select count(*) into v_count from zxdbm_cms.categorycdn
      where categoryname = i_name
      and parentindex = v_parentindex
      and catagorycode <> i_code;
      if v_count > 0 then
        rollback;
        o_retvalue := 3;
        o_retstring := package_imp_icm.static_error||'category can not same in the same parent category when regist';
        return;
      end if;

      -- 20140123 lxp 校验父栏目下是否有节目 若有 则报错
      select count(*) into v_countvod from zxdbm_cms.category_program_map
      where categoryindex=v_parentindex;
      select count(*) into v_countseries from zxdbm_cms.category_series_map
      where categoryindex=v_parentindex;
      select count(*) into v_countchannel from zxdbm_cms.category_channel_map
      where categoryindex=v_parentindex;
      if v_countvod<>0 or v_countseries<>0 or v_countchannel<>0 then
        rollback;
        o_retvalue := 11;
        o_retstring := package_imp_icm.static_error||'the parent column has some programs';
        return;
      end if;

      zxdbm_umap.sp_getmaxvalue('cms_category', 1, v_objindex);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --get categoryid
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'CATE', v_cspid, o_objid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 4;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      o_objindex := v_objindex;
      o_param1 := v_categoryid;
      insert into zxdbm_cms.categorycdn
      (
        categoryindex, categoryid, categoryname, parentindex, parentid
        , sequence, catagorycode, activestatus, description, status
      )
      values
      (
        v_objindex, o_objid, i_name, v_parentindex, v_categoryid
        , i_sequence, i_code, i_status, i_description, 0
      );

      --dgj 设置父栏目ischildexists字段为1，表示该父栏目下面已经有子栏目
	    update zxdbm_cms.categorycdn set ischildexists=1 where categoryindex=v_parentindex;
    --update
    elsif v_action =  'UPDATE' then
      if (i_parentcode is null) then
        select parentindex, parentid into v_parentindex, v_categoryid from zxdbm_cms.categorycdn where catagorycode = i_code;
      elsif (i_parentcode is not null) then
        select count(*) into v_count from zxdbm_cms.categorycdn where catagorycode = i_parentcode;
        if(v_count = 0)then
          --父栏目不存在
          select count(*) into v_count from zxdbm_cms.icm_category_mapping t where t.categoryid = i_parentcode;
          if (v_count = 0) then
            rollback;
            o_retvalue := 5;
            o_retstring := package_imp_icm.static_error||'can not find parent column when update category:' || i_code;
            return;
          else
            select a.categoryindex, a.categoryid into v_parentindex, v_categoryid
            from zxdbm_cms.categorycdn a, zxdbm_cms.icm_category_mapping b
            where a.categoryid = b.columncode
            and b.categoryid = i_parentcode and rownum = 1;
          end if;
        else
          select categoryindex, categoryid into v_parentindex, v_categoryid from zxdbm_cms.categorycdn where catagorycode = i_parentcode and rownum = 1;
        end if;
      end if;

      --检验同父节点下的栏目名称是否唯一
      select count(*) into v_count from zxdbm_cms.categorycdn where categoryname = i_name
      and parentindex = v_parentindex
      and catagorycode <> i_code;
      if v_count > 0 then
        rollback;
        o_retvalue := 7;
        o_retstring := package_imp_icm.static_error||'category can not same in the same parent category when update';
        return;
      end if;

      update zxdbm_cms.categorycdn
      set categoryname = nvl(i_name, categoryname),
          parentindex  = nvl(v_parentindex,parentindex),
          parentid     = nvl(v_categoryid,parentid),
          sequence     = nvl(i_sequence, sequence),
          activestatus = nvl(i_status,activestatus),
          description  = nvl(f_byte_substr(i_description, 1, 1024), description),
          status       = 0
      where catagorycode = i_code
      returning categoryindex, categoryid, parentid into o_objindex, o_objid, o_param1;
    --delete
    elsif v_action =  'DELETE' then
      select categoryindex, categoryid, parentid into o_objindex, o_objid, o_param1 from zxdbm_cms.categorycdn where catagorycode = i_code;

      select count(*) into v_count  from zxdbm_cms.categorycdn t where t.parentindex = o_objindex
      and exists
      (
       select * from zxdbm_cms.cnt_platform_sync p
       where t.categoryid=p.objectid and p.objecttype=2 and (p.isfiledelete<>-1 or p.status<>0)
      );
      if v_count > 0 then
        rollback;
        o_retvalue := 8;
        o_retstring := package_imp_icm.static_error||'sub category exist,delete fail';
        return;
      end if;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'category',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 9;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 10;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_column;

  procedure sp_smg_series
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_ordernumber          in varchar2,
    i_originalname         in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_orgairdate           in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision          in varchar2,
    i_price                in varchar2,
    i_volumncount          in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_type                 in varchar2,         --节目内容类型
    i_keywords             in varchar2,         --关键字
    i_tags                 in varchar2,         --关联标签
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  )
  as
    v_action        varchar2(20);
    v_nowtime       char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_count         number(2);
    v_cpindex       number(10);
    v_cpcode        varchar2(40);
    v_parentindex   number(10);
    v_objindex      number(10);
    v_columnid      varchar2(16);
    v_objcode       varchar2(40);
    v_cspid         varchar2(40);
    v_contentprice  number(20);
    v_autopackageindex number(9);--auto package index
    v_servicebindmapindex number(10);--pk servicebindmap
    v_checkactorresult number(1);
    v_elementindex  number(10);
    v_autopackageswitch number(1);   --autopackage kaiguan
    v_bindindex     number(10);   --cp牌照方主键
    v_lpid          varchar2(20); --牌照方ID
    v_seriesid      varchar2(40); --内容id（根据规则自动生成）
    v_actiontype    number(3);
    v_objecttype    number(10);
    v_retcode       number(10);
    v_desc          varchar2(255);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --find content from main table
    select count(*) into v_count from zxdbm_cms.cms_series where cpcontentid = i_code;
    if v_count > 0 and upper(i_action) = 'REGIST' then
      v_action := 'UPDATE';
    else
      v_action := upper(i_action);
    end if;

    --not exist
    if v_count = 0 and v_action = 'UPDATE' then
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'series not exists ';
      return;
    elsif v_count = 0 and v_action = 'DELETE' then
      o_retvalue := 0;
      o_retstring := package_imp_icm.static_success||'series not exists ';
      return;
    end if;

    if v_action = 'REGIST' then
      --get cp
      package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);
      --get cspid
      select cspid into v_cspid from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex and rownum=1;

      --获取series ID
      zxdbm_cms.sp_get_contentidbywgcode(i_code,'SERI', v_cspid, v_seriesid, v_retcode, v_desc);
      if v_retcode<>0 then
        rollback;
        o_retvalue := 2;
        o_retstring := package_imp_icm.static_error||v_desc;
        return;
      end if;

      --获取牌照方信息
      begin
        select bindindex, lpid into v_bindindex, v_lpid
        from zxdbm_cms.cms_cpbind
        where cpid=v_cpcode and rownum=1;
      exception
        when others then
          v_bindindex:=0;
          v_lpid:='0';
      end;

      zxdbm_umap.sp_getmaxvalue('cms_series_index', 1, v_objindex);
      o_objindex := v_objindex;
      o_objid := v_seriesid;
      o_param1 := v_cpcode;
      insert into zxdbm_cms.cms_series
      (
        seriesindex, seriesid, cpindex, cpid, cpcontentid, ordernumber, namecn
        , originalnamecn, sortname, searchname, orgairdate, licensingstart
        , licensingend, newcomedays, remainingdays, macrovision, pricetaxin
        , volumncount, isvalid, desccn, keywords, contenttags
        , servicekey, status, licenseindex, licenseid, countrytype, reserve1, reserve2
        , workflow, workflowlife, entrysource
      )
      values
      (
        v_objindex, v_seriesid, v_cpindex, v_cpcode, i_code, i_ordernumber, i_name
        , i_originalname, i_sortname, i_searchname, i_orgairdate, i_licensingwindowstart
        , i_licensingwindowend, i_displayasnew, i_displayaslastchance, i_macrovision, i_price
        , i_volumncount, i_status, f_byte_substr(i_description, 1, 1024), i_keywords, i_tags
        , 'CMS', 0, v_bindindex, v_lpid, 1, i_reserve1, i_reserve2
        , 0, 0, 3
      );

      --根据价格与service绑定
      sp_service_bind(v_seriesid,2,v_retcode,v_desc);

    --update
    elsif v_action = 'UPDATE' then
      update zxdbm_cms.cms_series
         set ordernumber   = nvl(i_ordernumber,ordernumber),
             namecn        = nvl(i_name, namecn),
             originalnamecn= nvl(i_originalname,originalnamecn),
             sortname      = nvl(i_sortname, sortname),
             searchname    = nvl(i_searchname,searchname),
             orgairdate    = nvl(i_orgairdate,orgairdate),
             licensingstart= nvl(i_licensingwindowstart,licensingstart),
             licensingend  = nvl(i_licensingwindowend,licensingend),
             newcomedays   = nvl(i_displayasnew,newcomedays),
             remainingdays = nvl(i_displayaslastchance,remainingdays),
             macrovision   = nvl(i_macrovision,macrovision),
             pricetaxin    = nvl(i_price,pricetaxin),
             volumncount   = nvl(i_volumncount,volumncount),
             isvalid       = nvl(i_status,isvalid),
             desccn        = nvl(f_byte_substr(i_description, 1, 1024), desccn),
             keywords      = nvl(i_keywords,keywords),
             contenttags   = nvl(i_tags,contenttags),
             status        = 0,
             licenseindex  = nvl(v_bindindex,licenseindex),
             licenseid     = nvl(v_lpid,licenseid),
             reserve1      = nvl(i_reserve1,reserve1),
             reserve2      = nvl(i_reserve2,reserve2)
      where cpcontentid = i_code
      returning seriesindex, seriesid, cpid into o_objindex, o_objid, o_param1;

      --根据价格与service绑定
      sp_service_bind(o_objid,2,v_retcode,v_desc);

    --delete
    elsif v_action = 'DELETE' then
      ---删演员关系，删单集关系，删服务关系，删节目关系
      select seriesindex, seriesid, cpid into o_objindex, o_objid, o_param1
      from zxdbm_cms.cms_series
      where cpcontentid = i_code;
    end if;
/*
    if (upper(i_action) = 'REGIST') then
      v_actiontype := 1;
    elsif (upper(i_action) = 'UPDATE') then
      v_actiontype := 2;
    elsif (upper(i_action) = 'DELETE') then
      v_actiontype := 3;
    end if;
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'series',null);

    sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;
*/
  exception
    when others then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_series;



-----------------deal xml  begin-------------------------


procedure sp_smg_sync_mapreg
  (
    i_correlateid in varchar2,
    i_mappingid   in varchar2,
    i_action      in varchar2,
    i_parenttype  in varchar2,
    i_elementtype in varchar2,
    i_parentid    in varchar2,
    i_elementid   in varchar2,
    i_parentcode  in varchar2,
    i_elementcode in varchar2,
    i_type        in varchar2,
    i_validstart  in varchar2,
    i_validend    in varchar2,
    i_sequence    in varchar2,
    i_taskindex   in number,
    o_objindex    out number,
    o_objid       out varchar2,
    o_param1      out varchar2,
    o_param2      out varchar2,
    o_retvalue    out number,
    o_retstring   out varchar2
  )
  as
    --variable
    v_cspid               varchar2(40);
    v_cpindex             number(10);
    v_cpcode              varchar2(40);
    v_parentindex         number(10);
    v_elementindex        number(10);
    v_count               number(3);
    v_objindex            number(10);
    v_objtelecode         varchar2(40);
    v_contentname         varchar2(128);
    v_programid           varchar2(22);
    v_programid_cdn       varchar2(32);
    v_pictureid           varchar2(32);
    v_contentprice        number(20);
    v_autopackageswitch   number(1);
    v_filetype            number(3);
    v_autopackageindex    number(10); --auto package index
    v_servicebindmapindex number(10); --pk servicebindmap
    v_checkactorresult    number(1);
    v_mapindex            number(10);
    v_seriesid            varchar2(32);
    v_categoryid          varchar2(32);
    v_serviceid           varchar2(32);
    v_channelid           varchar2(32);
    v_castrolemapid       varchar2(32);
    v_objecttype          number(10);
    v_retcode             number(10);     --返回值  0-成功 其他失败
    v_desc                varchar2(255);  --结果描述
    v_mappingid           varchar2(32);
    v_volumncount         number(10);
    v_castid              varchar2(32);
  begin

    --处理的所有mapping对象,共15个
    --program-movie
    --program-castrolemap
    --series-castrolemap
    --picture-program
    --picture-channel
    --picture-series
    --picture-category
    --category-program
    --category-series
    --category-channel
    --package-program
    --package-series
    --package-channel
    --series-program
    --picture-cast

    --没有处理的mapping对象，共3个
    --category-schedule
    --category-package
    --picture-package

    --init
    o_retvalue  := 0;
    o_retstring :='success';
    --o_retstring := package_imp_icm.static_success;

    --get cp
    package_imp_icm.sp_imp_getcp(i_taskindex, v_cpindex, v_cpcode);

    --one row
      --------------------------------------------------------------------------------------------------------
      ---------------------------- at first ,deal with program-movie mapping regist---------------------------
      --------------------------------------------------------------------------------------------------------
      if upper(i_action) = 'UPDATE' and upper(i_parenttype) = 'PROGRAM' and upper(i_elementtype) = 'MOVIE' then
          o_retvalue  := 55;
          o_retstring := package_imp_icm.static_error||'program-movie mapping does not support UPDATE action:' || i_elementcode;
          goto label2;
      end if;
      if upper(i_action) = 'REGIST' and upper(i_parenttype) = 'PROGRAM' and upper(i_elementtype) = 'MOVIE' then
        --regist success
        --check content obj in main table
        select count(*)
          into v_count
          from zxdbm_cms.cms_program ucnt
         where ucnt.cpcontentid = i_parentcode;
        --content exist
        if v_count <> 0 then
          select programindex,programid
          into v_parentindex,v_programid_cdn
          from zxdbm_cms.cms_program  ucnt
          where ucnt.cpcontentid = i_parentcode
          and rownum = 1;
        else
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'program not exist:' || i_parentcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 1;
          o_retstring := package_imp_icm.static_error||'program not exist:' || i_parentcode;
          goto label2;
        end if;
        --check file obj in main table
        select count(*) into v_count
        from zxdbm_cms.cms_movie t
        where t.cpcontentid = i_elementcode;
        --file exist
        if v_count <> 0 then
          select t.movieindex into v_elementindex
          from zxdbm_cms.cms_movie t
          where t.cpcontentid = i_elementcode and rownum = 1;

          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'movie','program');
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_elementindex, 30, '0');

          update zxdbm_cms.cms_movie a
          set a.programindex = v_parentindex,
              a.programid = v_programid_cdn,
              a.mappingid = v_mappingid
          where a.cpcontentid =i_elementcode
          returning movieid into o_param2;
          o_objindex := v_elementindex;
          o_objid := v_mappingid;
          o_param1 := v_programid_cdn;
        else
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'movie not exist:' || i_elementcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 2;
          o_retstring := package_imp_icm.static_error||'movie not exist:' || i_elementcode;
          goto label2;
        end if;
      end if;
      --------------------------------------------------------------------------------------------------------
      ---------------------------- at first ,deal with program-castrolemap mapping regist---------------------
      --------------------------------------------------------------------------------------------------------
      if upper(i_action) = 'UPDATE' and upper(i_parenttype) = 'PROGRAM' and upper(i_elementtype) = 'CASTROLEMAP' then
        o_retvalue  := 55;
        o_retstring := package_imp_icm.static_error||'program-castrolemap mapping does not support UPDATE action:' || i_elementcode;
        goto label2;
      end if;
      if upper(i_action) = 'REGIST' and upper(i_parenttype) = 'PROGRAM' and upper(i_elementtype) = 'CASTROLEMAP' then
        --regist success
        --check content obj in main table
        select count(*)
          into v_count
          from zxdbm_cms.cms_program ucnt
         where ucnt.cpcontentid = i_parentcode;
        --content exist
        if v_count <> 0 then
          select programindex,programid
          into v_parentindex,v_programid_cdn
          from zxdbm_cms.cms_program  ucnt
          where ucnt.cpcontentid = i_parentcode and rownum = 1;
          --contetn not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'program not exist:' || i_parentcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 3;
          o_retstring := package_imp_icm.static_error||'program not exist:' || i_parentcode;
          goto label2;
            --return;
            --data exist in cache table,insert main table
        end if;
        --check file obj in main table
        select count(*) into v_count
        from zxdbm_cms.castrolemap t
        where t.castrolemapcode = i_elementcode;

        --file exist
        if v_count <> 0 then
          select t.castrolemapindex,t.castrolemapid
          into v_elementindex,v_castrolemapid
          from zxdbm_cms.castrolemap t
          where t.castrolemapcode = i_elementcode and rownum = 1;
          --file not exist,find from cache table
        else
          --no data cache table, rollback
          --if v_count = 0 then
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'castrolemap not exist:' || i_elementcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 4;
          o_retstring := package_imp_icm.static_error||'castrolemap not exist:' || i_elementcode;
          goto label2;
        end if;
        --regist mapping
        select count(*) into v_count
        from zxdbm_cms.program_crm_map t
        where t.programindex = v_parentindex
        and t.castrolemapindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'castrolemap','program');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('program_crm_map', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          insert into zxdbm_cms.program_crm_map
                (mapindex,mappingid,programindex,programid,castrolemapindex,
                 castrolemapid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_programid_cdn,v_elementindex,
                 v_castrolemapid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          select mapindex,mappingid
          into   v_objindex,v_mappingid
          from zxdbm_cms.program_crm_map
          where programindex = v_parentindex
          and castrolemapindex = v_elementindex
          and rownum=1;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_programid_cdn;
        o_param2 := v_castrolemapid;
      end if;
      --------------------------------------------------------------------------------------------------------
      ---------------------------- at first ,deal with series-castrolemap mapping regist----------------------
      --------------------------------------------------------------------------------------------------------
      if upper(i_action) = 'UPDATE' and upper(i_parenttype) = 'SERIES' and upper(i_elementtype) = 'CASTROLEMAP' then
        o_retvalue  := 55;
        o_retstring := package_imp_icm.static_error||'series-castrolemap mapping does not support UPDATE action:' || i_elementcode;
        goto label2;
      end if;
      if upper(i_action) = 'REGIST' and upper(i_parenttype) = 'SERIES' and upper(i_elementtype) = 'CASTROLEMAP' then
        --regist success
        --check content obj in main table
        select count(*) into v_count
        from zxdbm_cms.cms_series ucnt
        where ucnt.cpcontentid = i_parentcode;
        --content exist
        if v_count <> 0 then
          select seriesindex,seriesid
          into v_parentindex,v_seriesid
          from zxdbm_cms.cms_series  ucnt
          where ucnt.cpcontentid = i_parentcode
          and rownum = 1;
        else
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'series not exist:' || i_parentcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 5;
          o_retstring := package_imp_icm.static_error||'series not exist:' || i_parentcode;
          goto label2;
            --return;
            --data exist in cache table,insert main table
        end if;
        --check file obj in main table
        select count(*) into v_count
        from zxdbm_cms.castrolemap t
        where t.castrolemapcode = i_elementcode;
           --and t.filetype <> 6;
        --file exist
        if v_count <> 0 then
          select t.castrolemapindex,t.castrolemapid
          into v_elementindex,v_castrolemapid
          from zxdbm_cms.castrolemap t
          where t.castrolemapcode = i_elementcode and rownum = 1;

          --file not exist,find from cache table
        else
          --no data cache table, rollback
          --if v_count = 0 then
          update zxdbm_cms.icm_smg_mapping t
          set t.errordesc = package_imp_icm.static_error||'castrolemap not exist:' || i_elementcode
          where t.parentcode = i_parentcode
          and t.elementcode = i_elementcode
          and t.correlateid = i_correlateid;
          o_retvalue  := 6;
          o_retstring := package_imp_icm.static_error||'castrolemap not exist:' || i_elementcode;
          goto label2;
        end if;
        --regist mapping
        select count(*) into v_count
        from zxdbm_cms.series_crm_map t
        where t.seriesindex = v_parentindex
        and t.castrolemapindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'castrolemap','series');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('series_crm_map', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          insert into zxdbm_cms.series_crm_map
                (mapindex,mappingid,seriesindex,seriesid,castrolemapindex,
                 castrolemapid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_seriesid,v_elementindex,
                 v_castrolemapid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          select mapindex,mappingid
          into v_objindex, v_mappingid
          from zxdbm_cms.series_crm_map
          where seriesindex = v_parentindex
          and castrolemapindex = v_elementindex
          and rownum=1;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_seriesid;
        o_param2 := v_castrolemapid;
      end if;
      -----------------------------------------------------------------------------------------------------------------------------
      -----------------------------------deal with picture-program mapping regist and update---------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'program' then
        --check content obj in main table
        select count(*) into v_count
        from zxdbm_cms.cms_program
        where cpcontentid = i_elementcode;
        --content exist
        if v_count > 0 then
        --需要注意一下，这里是elementcode，但是填到parentindex里面去了
          select programindex,programid
          into v_parentindex,v_programid_cdn
          from zxdbm_cms.cms_program ucnt
          where ucnt.cpcontentid = i_elementcode;
          --update content status
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find program when mapping with picture:' ||
                               i_elementcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 7;
          o_retstring := package_imp_icm.static_error||'can not find program when mapping with picture:' ||
                         i_elementcode;
          goto label2;
          --return;
          --data exist in cache table,insert main table
        end if;
       --检查海报是否存在
        --check file from main table
        select count(*)
          into v_count
          from zxdbm_cms.picture t
         where t.picturecode = i_parentcode
         and rownum = 1;
           --and t.posttype = nvl(i_type, 1);
        --file exist
        if v_count <> 0 then
          select pictureindex,pictureid
            into v_elementindex,v_pictureid
            from zxdbm_cms.picture t
           where picturecode = i_parentcode
             and rownum = 1;
          --file not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find picture when mapping with program:' ||
                               i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 8;
          o_retstring := package_imp_icm.static_error||'can not find picture when mapping with program:' ||
                         i_parentcode;
          goto label2;
          --data exist in cache table, insert main table
        end if;

        select count(*) into v_count
        from zxdbm_cms.program_picture_map t
        where t.programindex = v_parentindex
        and t.pictureindex = v_elementindex
        and rownum = 1;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','picture');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_program_picture_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          --需要修改，插入进去的初始状态status应该为多少
          insert into zxdbm_cms.program_picture_map
                (mapindex,mappingid,programindex,programid,pictureindex,
                 pictureid,maptype,status,sequence)
          values
                (v_objindex,v_mappingid, v_parentindex,v_programid_cdn, v_elementindex,
                 v_pictureid,i_type,0,nvl(i_sequence, 1));
        else
          update zxdbm_cms.program_picture_map t
          set  maptype=nvl(i_type, maptype),
               sequence=nvl(i_sequence,sequence)
          where t.programindex = v_parentindex
          and t.pictureindex = v_elementindex
          and rownum = 1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_pictureid;
        o_param2 := v_programid_cdn;
      end if;
      -----------------------------------------------------------------------------------------------------------------------------
      -----------------------------------deal with picture-channel mapping regist and update---------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'channel' then
        --check content obj in main table
        select count(*)
          into v_count
          from zxdbm_cms.cms_channel
         where cpcontentid = i_elementcode;
        --content exist
        if v_count > 0 then
        --需要注意一下，这里是elementcode，但是填到parentindex里面去了
          select channelindex,channelid
            into v_parentindex,v_channelid
          from zxdbm_cms.cms_channel ucnt
          where ucnt.cpcontentid = i_elementcode;
          --update content status
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find channel when mapping with picture:' ||
                               i_elementcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 9;
          o_retstring := package_imp_icm.static_error||'can not find channel when mapping with picture:' ||
                         i_elementcode;
          goto label2;
        end if;
       --检查海报是否存在
        --check file from main table
        select count(*)
          into v_count
          from zxdbm_cms.picture t
         where t.picturecode = i_parentcode
         and rownum = 1;
           --and t.posttype = nvl(i_type, 1);
        --file exist
        if v_count <> 0 then
          select pictureindex,pictureid
          into v_elementindex,v_pictureid
          from zxdbm_cms.picture t
          where picturecode = i_parentcode
          and rownum = 1;
          --file not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find picture when mapping with program:' ||
                               i_parentcode
          where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 10;
          o_retstring := package_imp_icm.static_error||'can not find picture when mapping with program:' ||
                         i_parentcode;
          goto label2;
          --data exist in cache table, insert main table
        end if;

        --find mapping info from main table
        select count(*) into v_count
        from zxdbm_cms.channel_picture_map t
        where t.channelindex = v_parentindex
        and t.pictureindex = v_elementindex
        and rownum = 1;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','picture');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_channel_picture_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          --需要修改，插入进去的初始状态status应该为多少
          insert into zxdbm_cms.channel_picture_map
               (mapindex,mappingid,channelindex,channelid,
                pictureindex,pictureid,maptype,status,sequence)
          values
              (v_objindex,v_mappingid,v_parentindex,v_channelid,
               v_elementindex,v_pictureid,i_type,0,nvl(i_sequence, 1));
        else
          update zxdbm_cms.channel_picture_map t
          set maptype=nvl(i_type, maptype),
              sequence=nvl(i_sequence,sequence)
          where t.channelindex = v_parentindex
          and t.pictureindex = v_elementindex
          and rownum = 1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_pictureid;
        o_param2 := v_channelid;
      end if;
      ----------------------------------------------------------------------------------------------------------------------------------------
      -------------------------------------------------deal with Picture-Series mapping regist------------------------------------------------
      ----------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'series' then
        select count(*) into v_count
        from zxdbm_cms.picture t
        where t.picturecode = i_parentcode
        and rownum = 1;
        --file exist
        if v_count <> 0 then
           select pictureindex,pictureid
           into v_elementindex,v_pictureid
           from zxdbm_cms.picture t
           where picturecode = i_parentcode
           and rownum = 1;
          --file not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'picture not exist:' || i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 11;
          o_retstring := package_imp_icm.static_error||'picture not exist:' || i_parentcode;
          goto label2;
          --data exist in cache table, insert main table
        end if;
        --检查series是否存在
        --find mapping from main table
        --check the content
        begin
          select seriesindex,seriesid
          into v_parentindex,v_seriesid
          from zxdbm_cms.cms_series
          where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
            set t.errordesc = package_imp_icm.static_error||'series not exist:' || i_elementcode
            where t.parentcode = i_parentcode
            and t.elementcode = i_elementcode
            and t.mappingid = i_mappingid;
            o_retvalue  := 12;
            o_retstring := package_imp_icm.static_error||'series not exist:' || i_elementcode;
            goto label2;
        end;

        --regist mapping
        select count(*) into v_count
        from zxdbm_cms.series_picture_map t
        where t.seriesindex = v_parentindex
        and t.pictureindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','picture');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_series_picture_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

          --状态需要修改为正确的status对应状态
          insert into zxdbm_cms.series_picture_map
                (mapindex,mappingid,seriesindex,seriesid,pictureindex,
                 pictureid,maptype,status,sequence)
          values(v_objindex,v_mappingid,v_parentindex,v_seriesid,v_elementindex,
                 v_pictureid,i_type,0,nvl(i_sequence, 1));
        else
          update zxdbm_cms.series_picture_map t
          set maptype=nvl(i_type,maptype),
              sequence=nvl(i_sequence,sequence)
          where t.seriesindex = v_parentindex
          and t.pictureindex = v_elementindex
          and rownum = 1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_pictureid;
        o_param2 := v_seriesid;
      end if;

      -----------------------------------------------------------------------------------------------------------------------------------
      --------------------------------------------deal with Picture-Category mapping regist----------------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'category'  then
        --check picture from main table
        select count(*) into v_count
        from zxdbm_cms.picture t
        where t.picturecode = i_parentcode and rownum = 1;
        --file exist
        if v_count <> 0 then
          select pictureindex,pictureid
            into v_elementindex,v_pictureid
            from zxdbm_cms.picture t
           where picturecode = i_parentcode
             and rownum = 1;
          --file not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'picture not exist:' || i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 13;
          o_retstring := package_imp_icm.static_error||'picture not exist:' || i_parentcode;
          goto label2;
          --data exist in cache table, insert main table
        end if;
        --find map from main table
        --检查picture存不存在
        --check column
        begin
          select categoryindex,categoryid
            into v_parentindex,v_categoryid
            from zxdbm_cms.categorycdn t
           where t.catagorycode = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'category not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 14;
            o_retstring := package_imp_icm.static_error||'category not exist:' || i_elementcode;
            goto label2;
        end;

        --check mapping
        select count(*) into v_count
          from zxdbm_cms.category_picture_map t
         where t.categoryindex = v_parentindex
           and t.pictureindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'category','picture');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_category_picture_map_index',1,v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

          insert into zxdbm_cms.category_picture_map
                (mapindex, mappingid, categoryindex, categoryid,
                 pictureindex,pictureid,maptype,status,sequence)
          values(v_objindex,v_mappingid,v_parentindex,v_categoryid,
                 v_elementindex,v_pictureid,i_type,0,nvl(i_sequence, 1));
        else
          update zxdbm_cms.category_picture_map t
          set maptype=nvl(i_type, maptype),
              sequence=nvl(i_sequence,sequence)
          where t.categoryindex = v_parentindex
          and t.pictureindex = v_elementindex
          and rownum = 1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_pictureid;
        o_param2 := v_categoryid;
      end if;

      ------------------------------------------------------------------------------------------------------------------------------------
      ----------------------------------------------deal with Category-Program mapping regist---------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'category' and
         lower(i_elementtype) = 'program' then
        --find indexs from main table
        --check the content
        begin
          select programindex,programid
            into v_elementindex,v_programid_cdn
            from zxdbm_cms.cms_program
           where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'content not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 15;
            o_retstring := package_imp_icm.static_error||'content not exist:' || i_elementcode;
            goto label2;
        end;
        --check the column
        begin
          select categoryindex,categoryid
            into v_parentindex,v_categoryid
            from zxdbm_cms.categorycdn
           where catagorycode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'category not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 16;
            o_retstring := package_imp_icm.static_error||'category not exist:' || i_parentcode;
            goto label2;
        end;

        --check the column have children column
        select count(*) into v_count
        from zxdbm_cms.categorycdn a
        where a.parentindex = v_parentindex;
        if v_count > 0 then
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'category have children column:' ||
                               i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 17;
          o_retstring := package_imp_icm.static_error||'category have children column:' ||
                         i_parentcode;
          goto label2;
        end if;

        --regist mapping
        select count(*) into v_count
        from zxdbm_cms.category_program_map t
        where t.categoryindex = v_parentindex
        and t.programindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','category');

        if v_count = 0 then
         zxdbm_umap.sp_getmaxvalue('category_program_map_index', 1, v_objindex);
         v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

         --mapping重复regist算更新吗？
         insert into zxdbm_cms.category_program_map
               (mapindex,mappingid,categoryindex,categoryid,
                programindex,programid,sequence,status,createtime)
         values(v_objindex,v_mappingid,v_parentindex,v_categoryid,
                v_elementindex,v_programid_cdn,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));

         update zxdbm_cms.categorycdn set ischildexists=0 where catagorycode=i_parentcode;
        else
          update zxdbm_cms.category_program_map
          set  sequence = nvl(i_sequence, sequence)
          where categoryindex = v_parentindex
            and programindex = v_elementindex
            and rownum=1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_categoryid;
        o_param2 := v_programid_cdn;
      end if;

      -----------------------------------------------------------------------------------------------------------------------------------------
      -------------------------------------------------deal with Category-Series mapping regist------------------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'category' and
         lower(i_elementtype) = 'series' then
        --delete success
        --find mapping from main table
        --check the content
        begin
          select seriesindex, namecn, seriesid
            into v_elementindex, v_contentname, v_seriesid
            from zxdbm_cms.cms_series
           where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'series not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 18;
            o_retstring := package_imp_icm.static_error||'series not exist:' || i_elementcode;
            goto label2;
        end;
        begin
          select categoryindex,categoryid
            into v_parentindex,v_categoryid
            from zxdbm_cms.categorycdn
           where catagorycode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'category not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 19;
            o_retstring := package_imp_icm.static_error||'category not exist:' || i_parentcode;
            goto label2;
        end;

        --check the column have children column
        select count(*) into v_count
        from zxdbm_cms.categorycdn a
        where a.parentindex = v_parentindex;
        if v_count > 0 then
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'category have children column:' ||
                               i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 20;
          o_retstring := package_imp_icm.static_error||'category have children column:' ||
                         i_parentcode;
          goto label2;
        end if;

        --regist mapping
        --mapping 表里面填的都不是文广code，都是经过转换的32位id
        select count(*) into v_count
          from zxdbm_cms.category_series_map t
         where t.categoryindex = v_parentindex
           and t.seriesindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','category');

        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('category_series_map', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          insert into zxdbm_cms.category_series_map
                (mapindex,mappingid,categoryindex,categoryid,
                 seriesindex,seriesid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_categoryid,
                 v_elementindex,v_seriesid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));

          update zxdbm_cms.categorycdn set ischildexists=0 where catagorycode=i_parentcode;
        else
          update zxdbm_cms.category_series_map
          set   sequence = nvl(i_sequence, sequence)
          where categoryindex = v_parentindex
            and seriesindex = v_elementindex
            and rownum=1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_categoryid;
        o_param2 := v_seriesid;
      end if;
      -----------------------------------------------------------------------------------------------------------------------------------------
      -------------------------------------------------deal with Category-channel mapping regist------------------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'category' and
         lower(i_elementtype) = 'channel' then
        --delete success
        --find mapping from main table
        --check the content
        begin
          select channelindex, channelid
            into v_elementindex, v_channelid
            from zxdbm_cms.cms_channel
           where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'channel not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 21;
            o_retstring := package_imp_icm.static_error||'channel not exist:' || i_elementcode;
            goto label2;
        end;

        begin
          select categoryindex,categoryid
            into v_parentindex,v_categoryid
            from zxdbm_cms.categorycdn
           where catagorycode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'category not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 22;
            o_retstring := package_imp_icm.static_error||'category not exist:' || i_parentcode;
            goto label2;
        end;

        --check the column have children column
        select count(*) into v_count
          from zxdbm_cms.categorycdn a
         where a.parentindex = v_parentindex;
        if v_count > 0 then
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'category have children column:' ||
                               i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 23;
          o_retstring := package_imp_icm.static_error||'category have children column:' ||
                         i_parentcode;
          goto label2;
        end if;

        --regist mapping
        --mapping 表里面填的都不是文广code，都是经过转换的32位id
        select count(*) into v_count
          from zxdbm_cms.category_channel_map t
         where t.categoryindex = v_parentindex
           and t.channelindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','category');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('channel_catagory_map', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          insert into zxdbm_cms.category_channel_map
                (mapindex,mappingid,categoryindex,categoryid,
                 channelindex,channelid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_categoryid,
                 v_elementindex,v_channelid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));

          update zxdbm_cms.categorycdn set ischildexists=0 where catagorycode=i_parentcode;
        else
          update zxdbm_cms.category_channel_map t
          set sequence=nvl(i_sequence,sequence)
          where t.categoryindex = v_parentindex
           and t.channelindex = v_elementindex
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_categoryid;
        o_param2 := v_channelid;
      end if;
      -----------------------------------------------------------------------------------------------------------------------------------------------
      ------------------------------------------------------deal with Package-Program mapping regist-------------------------------------------------
      -----------------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'package' and
         lower(i_elementtype) = 'program' then
        --find mapping from main table
        --check the content
        begin
          select programindex,programid
            into v_elementindex, v_programid_cdn
            from zxdbm_cms.cms_program
           where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'content not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 24;
            o_retstring := package_imp_icm.static_error||'content not exist:' || i_elementcode;
            goto label2;
        end;
        --check the service
        begin
          select serviceindex,serviceid
            into v_parentindex,v_serviceid
            from zxdbm_cms.service
           where servicecode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'package not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 25;
            o_retstring := package_imp_icm.static_error||'package not exist:' || i_parentcode;
            goto label2;
        end;
        --regist mapping
        --需要修改，这个是转换的32位的id，不是code
        select count(*)
          into v_count
          from zxdbm_cms.service_program_map t
         where t.serviceindex = v_parentindex
           and t.programindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','package');

        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_service_program_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

          insert into zxdbm_cms.service_program_map
                (mapindex,mappingid,serviceindex,serviceid,
                 programindex,programid,sequence,status,createtime)
          values
                (v_objindex,v_mappingid,v_parentindex,v_serviceid,
                 v_elementindex,v_programid_cdn,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          update zxdbm_cms.service_program_map t
          set sequence=nvl(i_sequence,sequence)
          where t.serviceindex = v_parentindex
           and t.programindex = v_elementindex
           and rownum=1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_serviceid;
        o_param2 := v_programid_cdn;
      end if;

      ------------------------------------------------------------------------------------------------------------------------------------------
      ----------------------------------------------------deal with Package-Series mapping regist-----------------------------------------------
      ------------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'package' and
         lower(i_elementtype) = 'series' then
        --find mapping from main table
        --check the content
        begin
          select seriesindex,seriesid
            into v_elementindex, v_seriesid
            from zxdbm_cms.cms_series
           where cpcontentid = i_elementcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'series not exist:' || i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 26;
            o_retstring := package_imp_icm.static_error||'series not exist:' || i_elementcode;
            goto label2;
        end;
        begin
          select serviceindex,serviceid
            into v_parentindex,v_serviceid
            from zxdbm_cms.service
           where servicecode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'package not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 27;
            o_retstring := package_imp_icm.static_error||'package not exist:' || i_parentcode;
            goto label2;
        end;
        --regist mapping
        --需要修改，这个是转换的32位的id，不是code
        select count(*)
          into v_count
          from zxdbm_cms.service_series_map t
         where t.serviceindex = v_parentindex
           and t.seriesindex = v_elementindex;
         v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','package');

        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_service_series_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

          insert into zxdbm_cms.service_series_map
                (mapindex,mappingid,serviceindex,serviceid,
                 seriesindex,seriesid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_serviceid,
                 v_elementindex,v_seriesid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          update zxdbm_cms.service_series_map t
          set sequence=nvl(i_sequence,sequence)
          where t.serviceindex = v_parentindex
           and t.seriesindex = v_elementindex
           and rownum=1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_serviceid;
        o_param2 := v_seriesid;
      end if;

      --------------------------------------------------------------------------------------------------------------------------------------------
      ---------------------------------------------------deal with Package-Channel mapping regist-------------------------------------------------
      --------------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'package' and
         lower(i_elementtype) = 'channel' then
        --find mapping from main table
        --check the channel
        begin
          select channelindex, channelid
            into v_elementindex, v_channelid from zxdbm_cms.cms_channel
            where cpcontentid = i_elementcode
            and rownum = 1;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'live channel not exist:' ||
                                 i_elementcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 28;
            o_retstring := package_imp_icm.static_error||'live channel not exist:' || i_elementcode;
            goto label2;
        end;
        --check the service
        begin
          select serviceindex,serviceid
            into v_parentindex,v_serviceid
            from zxdbm_cms.service
           where servicecode = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'package not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 29;
            o_retstring := package_imp_icm.static_error||'package not exist:' || i_parentcode;
            goto label2;
        end;
        --regist mapping
         --需要修改，这个是转换的32位的id，不是code
        select count(*)
          into v_count
          from zxdbm_cms.service_channel_map t
         where t.serviceindex = v_parentindex
           and t.channelindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','package');

        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_service_channel_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');

          insert into zxdbm_cms.service_channel_map
                (mapindex,mappingid,serviceindex,serviceid,
                 channelindex,channelid,sequence,status,createtime)
          values(v_objindex,v_mappingid,v_parentindex,v_serviceid,
                 v_elementindex,v_channelid,nvl(i_sequence, 1),0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          update zxdbm_cms.service_channel_map t
          set sequence=nvl(i_sequence,sequence)
          where t.serviceindex = v_parentindex
           and t.channelindex = v_elementindex
           and rownum=1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_serviceid;
        o_param2 := v_channelid;
      end if;

      --------------------------------------------------------------------------------------------------------------------------------------
      -------------------------------------------------deal with Series-Program mapping regist----------------------------------------------
      --------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'series' and lower(i_elementtype) = 'program' then
        --check v_elementindex
        v_elementindex := 0;
        begin
         select seriesindex,seriesid
            into v_parentindex,v_seriesid
            from zxdbm_cms.cms_series
           where cpcontentid = i_parentcode;
        exception
          when no_data_found then
            update zxdbm_cms.icm_smg_mapping t
               set t.errordesc = package_imp_icm.static_error||'series not exist:' || i_parentcode
             where t.parentcode = i_parentcode
               and t.elementcode = i_elementcode
               and t.mappingid = i_mappingid;
            o_retvalue  := 30;
            o_retstring := package_imp_icm.static_error||'series not exist:' || i_parentcode;
            goto label2;
        end;

        --验证sequence是否大于series的总集数
        --20140123 liuxp ott 放开总集数校验
/*
        select volumncount into v_volumncount
        from zxdbm_cms.cms_series
        where seriesindex=v_parentindex;
        if (i_sequence>v_volumncount) then
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'series number(i_sequnce) greater than volumn count'
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 31;
          o_retstring := package_imp_icm.static_error||'series number(i_sequnce) greater than volumn count';
          goto label2;
        end if;
*/
        select count(*)
          into v_count
          from zxdbm_cms.cms_program f
         where f.cpcontentid = i_elementcode;
        if v_count = 0 then
          --can not find the danji info,insert a new one
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'program not exist:' ||
                               i_elementcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 32;
          o_retstring := package_imp_icm.static_error||'program not exist:' ||
                         i_elementcode;
          goto label2;
        end if;
        --regist mapping
       --regist mapping
       select programindex,f.programid
          into v_elementindex,v_programid_cdn
          from zxdbm_cms.cms_program f
         where f.cpcontentid = i_elementcode;
        select count(*)
          into v_count
          from zxdbm_cms.series_program_map t
         where t.seriesindex = v_parentindex
           and t.programindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','series');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('series_program_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          insert into zxdbm_cms.series_program_map
                (mapindex,mappingid,seriesindex,seriesid,
                 programindex,programid,sequence,status,createtime)
          values
                (v_objindex,v_mappingid,v_parentindex,v_seriesid,
                 v_elementindex,v_programid_cdn,i_sequence,0,to_char(sysdate, 'yyyymmddhh24miss'));
        else
          update zxdbm_cms.series_program_map t
          set sequence=nvl(i_sequence,sequence)
          where t.seriesindex = v_parentindex
           and t.programindex = v_elementindex
           and rownum=1
          returning  mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_seriesid;
        o_param2 := v_programid_cdn;

        -- 20140123 lxp 在注入program-series的mapping时更新program的seriesflag字段 改为1-连续剧剧集
        update zxdbm_cms.cms_program set seriesflag=1 where programindex=v_elementindex and rownum=1;
      end if;

      --------------------------------------------------------------------------------------------------------------------------------------
      -------------------------------------------------deal with picture-cast mapping regist------------------------------------------------
      ----------------------------------------------------------(add by lsm)----------------------------------------------------------------
      --------------------------------------------------------------------------------------------------------------------------------------
      if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'cast' then
        --check content obj in main table
        select count(*) into v_count
        from zxdbm_cms.castcdn
        where castcode = i_elementcode;
        --content exist
        if v_count > 0 then
          select castindex,castid
          into v_elementindex,v_castid
          from zxdbm_cms.castcdn
          where castcode = i_elementcode;
          --update content status
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find cast when mapping with picture:' ||
                               i_elementcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 33;
          o_retstring := package_imp_icm.static_error||'can not find cast when mapping with picture:' ||
                         i_elementcode;
          goto label2;
          --return;
          --data exist in cache table,insert main table
        end if;
        --检查海报是否存在
        --check file from main table
        select count(*)
          into v_count
          from zxdbm_cms.picture t
         where t.picturecode = i_parentcode
         and rownum = 1;
           --and t.posttype = nvl(i_type, 1);
        --file exist
        if v_count <> 0 then
          select pictureindex,pictureid
            into v_parentindex,v_pictureid
            from zxdbm_cms.picture t
           where picturecode = i_parentcode
             and rownum = 1;
          --file not exist,find from cache table
        else
          update zxdbm_cms.icm_smg_mapping t
             set t.errordesc = package_imp_icm.static_error||'can not find picture when mapping with cast:' ||
                               i_parentcode
           where t.parentcode = i_parentcode
             and t.elementcode = i_elementcode
             and t.mappingid = i_mappingid;
          o_retvalue  := 34;
          o_retstring := package_imp_icm.static_error||'can not find picture when mapping with cast:' ||
                         i_parentcode;
          goto label2;
          --data exist in cache table, insert main table
        end if;

        select count(*) into v_count
        from zxdbm_cms.cast_picture_map t
        where t.pictureindex = v_parentindex
        and t.castindex = v_elementindex;
        v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'cast','picture');
        if v_count = 0 then
          zxdbm_umap.sp_getmaxvalue('cms_cast_picture_map_index', 1, v_objindex);
          v_mappingid := lpad(v_objecttype, 2, '0')||lpad(v_objindex, 30, '0');
          --需要修改，插入进去的初始状态status应该为多少
          insert into zxdbm_cms.cast_picture_map
                (mapindex,mappingid,castindex,castid,pictureindex,
                 pictureid,maptype,status,sequence,createtime)
          values
                (v_objindex,v_mappingid, v_elementindex,v_castid, v_parentindex,
                 v_pictureid,i_type,0,nvl(i_sequence, 1),to_char(sysdate,'yyyymmddhh24miss'));
        else
          update zxdbm_cms.cast_picture_map t
          set  maptype=nvl(i_type, maptype),
               sequence=nvl(i_sequence,sequence)
          where t.pictureindex = v_parentindex
          and t.castindex = v_elementindex
          and rownum = 1
          returning mapindex,mappingid
          into v_objindex,v_mappingid;
        end if;
        o_objindex := v_objindex;
        o_objid := v_mappingid;
        o_param1 := v_pictureid;
        o_param2 := v_castid;
      end if;
/*
      sp_object_cpcnt_record_insert
      (
       i_taskindex,    --任务主键
       i_correlateid,  --对象所属工单编号
       v_objecttype,   --对象类型
       1,              --同步类型:1-REGIST,2-UPDATE,3-DELETE
       o_param2,       --对象id,为mapping时对应elementid
       i_elementcode,  --对象code,为mapping时对应elementcode
       o_param1,       --文广parentid,对象为mapping时必填
       i_parentcode,   --文广parentcod,对象为mapping时必填
       v_retcode,      --返回值  0-成功 其他失败
       v_desc          --结果描述
      );
      if (v_retcode != 0) then
        update zxdbm_cms.icm_smg_mapping t
        set t.errordesc = package_imp_icm.static_error||'mapreg: sp_object_cpcnt_record_insert' || v_desc
        where t.parentcode = i_parentcode
        and t.elementcode = i_elementcode
        and t.correlateid = i_correlateid;
        o_retvalue  := 35;
        o_retstring := package_imp_icm.static_error||'mapreg: sp_object_cpcnt_record_insert' || v_desc;
      end if;
*/
      <<label2>>
      null;

  exception
    when others then
      rollback;
      o_retvalue  := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_sync_mapreg;

  procedure sp_smg_sync_mapdel
  (
      i_correlateid       in varchar2,
      i_mappingid         in varchar2,
      i_action            in varchar2,
      i_parenttype        in varchar2,
      i_elementtype       in varchar2,
      i_parentid          in varchar2,
      i_elementid         in varchar2,
      i_parentcode        in varchar2,
      i_elementcode       in varchar2,
      i_type              in varchar2,
      i_sequence          in varchar2,
      i_taskindex         in number,
      o_objindex          out number,
      o_objid             out varchar2,
      o_param1            out varchar2,
      o_param2            out varchar2,
      o_retvalue          out number,
      o_retstring         out varchar2
  )
  as
    --variable
    v_parentindex   number(10);
    v_elementindex  number(10);
    v_count         number(3);
    v_seriesid            varchar2(32);
    v_categoryid          varchar2(32);
    v_serviceid           varchar2(32);
    v_channelid           varchar2(32);
    v_programid           varchar2(32);
    v_movieid             varchar2(32);
    v_pictureid           varchar2(32);
    v_castrolemapid       varchar2(32);
    v_mappingid           varchar2(32);
    v_mapindex            number(10);
    v_castid              varchar2(32);
    v_objecttype		  number(10);
    v_retcode             number(10);     --返回值  0-成功 其他失败
    v_desc                varchar2(255);  --结果描述
   begin
     --有处理的mapping对象
     --program-movie
     --picture-program
     --Picture-Series
     --picture-channel
     --Category-Program
     --Category-Series
     --Category-channel
     --Package-Program
     --Package-Series
     --Package-Channel
     --Series-Program
     --series-castrolemap
     --program-castrolemap
     --Picture-Category
     --picture-cast

  --return inith
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

      -----------------------------------------------deal with program-movie mapping delete---------------------------------------------------
      begin
        if lower(i_parenttype) = 'program' and lower(i_elementtype) = 'movie' then
            --find program from main table
            begin
                select programindex,programid
                into v_parentindex,v_programid
                from zxdbm_cms.cms_program
                where cpcontentid = i_parentcode;
            exception when no_data_found then
                rollback;
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;

            --find movie from main table
            begin
              select count(*) into v_count from zxdbm_cms.cms_movie where cpcontentid = i_elementcode;
              if v_count = 0 then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
              end if;
            end;
            select movieindex,movieid,mappingid into v_elementindex,v_movieid,v_mappingid from zxdbm_cms.cms_movie where cpcontentid = i_elementcode;
            --find mapping from main table
            begin
              select count(*) into v_count from zxdbm_cms.cms_movie a where a.programindex =v_parentindex and a.movieindex=v_elementindex;
              if v_count = 0 then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
              end if;
            end;
            v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'movie','program');
            o_objindex := v_elementindex;
            o_objid := v_mappingid;
            o_param1 := v_programid;
            o_param2 := v_movieid;

        end if;
      exception
        when others then
           null;
      end;

      -----------------------------------------------deal with picture-program mapping delete------------------------------------------------
      begin
        if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'program' then
            begin
                select programindex,programid
                into v_elementindex,v_programid
                from zxdbm_cms.cms_program
                where cpcontentid = i_elementcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
           select pictureindex,pictureid
           into v_parentindex,v_pictureid
           from zxdbm_cms.picture t
          where t.picturecode = i_parentcode
            and rownum = 1;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
           --mapping
           --父子关系可能颠倒，要重点测试
           begin
             select mapindex,mappingid
             into v_mapindex,v_mappingid
             from zxdbm_cms.program_picture_map t
             where t.programindex = v_elementindex
             and t.pictureindex = v_parentindex
             and rownum = 1;
           exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program', 'picture');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_pictureid;
           o_param2 := v_programid;

        end if;
      exception
        when no_data_found then
           null;
      end;
      -----------------------------------------------deal with picture-series mapping delete------------------------------------------------
      begin
        if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'series' then
            begin
                select seriesindex,seriesid
                into v_elementindex,v_seriesid
                from zxdbm_cms.cms_series
                where cpcontentid = i_elementcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
           select pictureindex,pictureid
           into v_parentindex,v_pictureid
           from zxdbm_cms.picture t
          where t.picturecode = i_parentcode
            and rownum = 1;
            exception when no_data_found then
                rollback;
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
           --mapping
           --父子关系可能颠倒，要重点测试
           begin
             select mapindex,mappingid
             into v_mapindex,v_mappingid
             from zxdbm_cms.series_picture_map t
             where t.seriesindex = v_elementindex
             and t.pictureindex = v_parentindex
             and rownum = 1;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','picture');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_pictureid;
           o_param2 := v_seriesid;
        end if;
      exception
        when no_data_found then
           null;
      end;
      -----------------------------------------------deal with picture-channel mapping delete------------------------------------------------
      begin
        if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'channel' then
           begin
                select channelindex,channelid
                into v_elementindex,v_channelid
                from zxdbm_cms.cms_channel
                where cpcontentid = i_elementcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
           select pictureindex,pictureid
           into v_parentindex,v_pictureid
           from zxdbm_cms.picture t
          where t.picturecode = i_parentcode
            and rownum = 1;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
           --mapping
           --父子关系可能颠倒，要重点测试
           begin
             select mapindex,mappingid
             into v_mapindex,v_mappingid
             from zxdbm_cms.channel_picture_map t
             where t.channelindex = v_elementindex
             and t.pictureindex = v_parentindex
             and rownum = 1;
           exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','picture');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_pictureid;
           o_param2 := v_channelid;
        end if;
      exception
        when no_data_found then
           null;
      end;
      -----------------------------------------------deal with Category-Program mapping delete-------------------------------------------------
      begin
        if lower(i_parenttype) = 'category' and lower(i_elementtype) = 'program' then
           --delete success
           --category
            begin
                --select columnindex into v_parentindex from zxdbm_iptv.icm_column where catagorycode = i_parentcode;
                select categoryindex,categoryid
                into v_parentindex,v_categoryid
                from zxdbm_cms.categorycdn
                where catagorycode = i_parentcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
            select programindex,programid
               into v_elementindex,v_programid
            from zxdbm_cms.cms_program
           where cpcontentid = i_elementcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
              select mapindex,mappingid
              into v_mapindex,v_mappingid
              from zxdbm_cms.category_program_map t
              where t.categoryindex = v_parentindex
              and t.programindex = v_elementindex;
              --mapping
              --select count(*) into v_count from zxdbm_iptv.icm_program where contentindex = v_elementindex and columnindex = v_parentindex;
           exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end ;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','category');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_categoryid;
           o_param2 := v_programid;
        end if;
      exception
        when no_data_found then
           null;
      end;
          ------------------------------------------------deal with Category-Series mapping delete------------------------------------------------
      begin
        if lower(i_parenttype) = 'category' and lower(i_elementtype) = 'series' then
            begin
                select categoryindex,categoryid
                into v_parentindex,v_categoryid
                from zxdbm_cms.categorycdn
                where catagorycode = i_parentcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
            select seriesindex,seriesid
               into v_elementindex,v_seriesid
            from zxdbm_cms.cms_series
           where cpcontentid = i_elementcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            --mapping
            begin
              select mapindex,mappingid
              into v_mapindex,v_mappingid
              from zxdbm_cms.category_series_map
              where seriesindex = v_elementindex
              and categoryindex = v_parentindex
              and rownum=1;
            exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','category');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_categoryid;
           o_param2 := v_seriesid;
        end if;
      exception
        when no_data_found then
           null;
      end;
       -----------------------------------------------deal with Category-channel mapping delete-------------------------------------------------
      begin
        if lower(i_parenttype) = 'category' and lower(i_elementtype) = 'channel' then
           --delete success
           --category
            begin
                --select columnindex into v_parentindex from zxdbm_iptv.icm_column where catagorycode = i_parentcode;
                select categoryindex,categoryid
                into v_parentindex,v_categoryid
                from zxdbm_cms.categorycdn
                where catagorycode = i_parentcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            begin
            select channelindex,channelid
               into v_elementindex,v_channelid
            from zxdbm_cms.cms_channel
           where cpcontentid = i_elementcode;
            exception when no_data_found then
                rollback;
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
           begin
             select mapindex,mappingid
             into v_mapindex,v_mappingid
             from zxdbm_cms.category_channel_map t
             where t.categoryindex = v_parentindex
             and t.channelindex = v_elementindex;
            --mapping
            --select count(*) into v_count from zxdbm_iptv.icm_program where contentindex = v_elementindex and columnindex = v_parentindex;
           exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','category');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_categoryid;
           o_param2 := v_channelid;
        end if;
      exception
        when no_data_found then
           null;
      end;
      ---------------------------------------------deal with Package-Program mapping delete-------------------------------------------
      begin
        if lower(i_parenttype) = 'package' and lower(i_elementtype) = 'program' then
          begin
          select serviceindex,serviceid
           into v_parentindex,v_serviceid
           from zxdbm_cms.service
          where servicecode = i_parentcode;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
          end;

          begin
            select programindex,programid
            into v_elementindex,v_programid
            from zxdbm_cms.cms_program
            where cpcontentid = i_elementcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;

          begin
            select mapindex,mappingid
            into v_mapindex,v_mappingid
            from zxdbm_cms.service_program_map
            where programindex = v_elementindex
            and serviceindex = v_parentindex;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','package');
          o_objindex := v_mapindex;
          o_objid := v_mappingid;
          o_param1 := v_serviceid;
          o_param2 := v_programid;
        end if;
      exception
      when no_data_found then
           null;
      end;
      ----------------------------------------------deal with Package-Series mapping delete--------------------------------------------
      begin
        if lower(i_parenttype) = 'package' and lower(i_elementtype) = 'series' then
           begin
             select serviceindex,serviceid
             into v_parentindex,v_serviceid
             from zxdbm_cms.service
             where servicecode = i_parentcode;
           exception
             when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end;

           begin
             select seriesindex,seriesid
             into v_elementindex,v_seriesid
             from zxdbm_cms.cms_series
             where cpcontentid = i_elementcode;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
           end;
           --mapping
           begin
             select mapindex,mappingid
             into v_mapindex,v_mappingid
             from zxdbm_cms.service_series_map
             where seriesindex = v_elementindex
             and serviceindex = v_parentindex;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'series','package');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_serviceid;
           o_param2 := v_seriesid;
        end if;
      exception
        when no_data_found then
           null;
      end;
       --------------------------------------------deal with Package-channel mapping delete--------------------------------------------
      begin
        if lower(i_parenttype) = 'package' and lower(i_elementtype) = 'channel' then
          begin
            select serviceindex,serviceid
            into v_parentindex,v_serviceid
            from zxdbm_cms.service
            where servicecode = i_parentcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
          --channel
          begin
            select channelindex,channelid
            into v_elementindex,v_channelid
            from zxdbm_cms.cms_channel a
            where a.cpcontentid = i_elementcode
            and rownum = 1;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;

          --mapping
          begin
            select mapindex,mappingid
            into v_mapindex,v_mappingid
            from zxdbm_cms.service_channel_map
            where channelindex = v_elementindex
            and serviceindex = v_parentindex;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'channel','package');
          o_objindex := v_mapindex;
          o_objid := v_mappingid;
          o_param1 := v_serviceid;
          o_param2 := v_channelid;
        end if;
      exception
        when no_data_found then
           null;
      end;

      ----------------------------------------------deal with Series-Program mapping delete-------------------------------------------
      begin
        if lower(i_parenttype) = 'series' and lower(i_elementtype) = 'program' then
          --delete success
          --series
          begin
            select seriesindex,seriesid
            into v_parentindex,v_seriesid
            from zxdbm_cms.cms_series
            where cpcontentid = i_parentcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;

          begin
            select f.programindex,programid
            into v_elementindex,v_programid
            from zxdbm_cms.cms_program f
            where f.cpcontentid = i_elementcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
            --mapping
          begin
            select mapindex,mappingid
            into v_mapindex,v_mappingid
            from zxdbm_cms.series_program_map
            where seriesindex = v_parentindex
            and programindex = v_elementindex
            and rownum=1;
          exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
          end;
          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'program','series');
          o_objindex := v_mapindex;
          o_objid := v_mappingid;
          o_param1 := v_seriesid;
          o_param2 := v_programid;
        end if;
      exception
        when no_data_found then
          null;
      end;
      ----------------------------------------------deal with Series-CASTROLEMAP mapping delete-------------------------------------------
      begin
        if lower(i_parenttype) = 'series' and lower(i_elementtype) = 'castrolemap' then
          --delete success
           --series
            begin
                select seriesindex,seriesid
                into v_parentindex,v_seriesid
                from zxdbm_cms.cms_series
                where cpcontentid = i_parentcode;
            exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;

            begin
            select f.castrolemapindex,castrolemapid
              into v_elementindex,v_castrolemapid
            from zxdbm_cms.castrolemap f
            where f.castrolemapcode = i_elementcode;
              exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            --mapping
            begin
              select mapindex,mappingid
              into v_mapindex,v_mappingid
              from zxdbm_cms.series_crm_map
              where seriesindex = v_parentindex
              and castrolemapindex = v_elementindex
              and rownum=1;
            exception
              when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
           end;
           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'castrolemap','series');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_seriesid;
           o_param2 := v_castrolemapid;
       end if;
       exception
          when no_data_found then
             null;
       end;
      ----------------------------------------------deal with program-CASTROLEMAP mapping delete-------------------------------------------
      begin
        if lower(i_parenttype) = 'program' and lower(i_elementtype) = 'castrolemap' then
          --delete success
           --series
            begin
                select programindex,programid
                into v_parentindex,v_programid
                from zxdbm_cms.cms_program
                where cpcontentid = i_parentcode;
            exception
              when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;

            begin
            select f.castrolemapindex,castrolemapid
              into v_elementindex,v_castrolemapid
            from zxdbm_cms.castrolemap f
            where f.castrolemapcode = i_elementcode;
              exception when no_data_found then
                o_retvalue := 0;
                o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
                --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
                update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
                commit;
                return;
            end;
            --mapping
            begin
              select mapindex,mappingid
              into v_mapindex,v_mappingid
              from zxdbm_cms.program_crm_map
              where programindex = v_parentindex
              and castrolemapindex = v_elementindex
              and rownum=1;
            exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
                return;
           end;

           v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'castrolemap','program');
           o_objindex := v_mapindex;
           o_objid := v_mappingid;
           o_param1 := v_programid;
           o_param2 := v_castrolemapid;
       end if;
       exception
          when no_data_found then
             null;
       end;
       ------------------------------------------------deal with Picture-Category mapping delete-------------------------------------------
       begin
         if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'category'then
           begin
             select t.pictureindex,t.pictureid
             into v_parentindex,v_pictureid
             from zxdbm_cms.picture t
             where t.picturecode = i_parentcode
             and rownum = 1;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
          end;
           --category

          begin
            select t.categoryindex,t.categoryid
            into v_elementindex,v_categoryid
            from zxdbm_cms.categorycdn t
            where t.catagorycode = i_elementcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;

          --mapping
          begin
            select mapindex,mappingid
            into v_mapindex,v_mappingid
            from zxdbm_cms.category_picture_map t
            where t.pictureindex = v_parentindex
            and t.categoryindex = v_elementindex
            and rownum=1;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'category','picture');
          o_objindex := v_mapindex;
          o_objid := v_mappingid;
          o_param1 := v_pictureid;
          o_param2 := v_categoryid;
        end if;
      exception
        when no_data_found then
             null;
      end;

      ------------------------------------------------deal with Picture-cast mapping delete-------------------------------------------
       begin
         if lower(i_parenttype) = 'picture' and lower(i_elementtype) = 'cast'then
           begin
             select t.pictureindex,t.pictureid
             into v_parentindex,v_pictureid
             from zxdbm_cms.picture t
             where t.picturecode = i_parentcode
             and rownum = 1;
           exception
             when no_data_found then
               o_retvalue := 0;
               o_retstring := package_imp_icm.static_success||i_parenttype||' not exist:'||i_parentcode;
               --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
               update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
               commit;
               return;
          end;

          begin
            select t.castindex,t.castid
            into v_elementindex,v_castid
            from zxdbm_cms.castcdn t
            where t.castcode = i_elementcode;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||i_elementtype||' not exist:'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;

          --mapping
          begin
            select mapindex,mappingid
            into v_mapindex,v_mappingid
            from zxdbm_cms.cast_picture_map t
            where t.pictureindex = v_parentindex
            and t.castindex = v_elementindex
            and rownum=1;
          exception
            when no_data_found then
              o_retvalue := 0;
              o_retstring := package_imp_icm.static_success||'mapping not exist: '||i_parenttype||':'||i_parentcode||'-'||i_elementtype||':'||i_elementcode;
              --update icm_smg_mapping set result = o_retvalue, errordesc = o_retstring where mappingid = i_mappingid;
              update icm_smg_mapping set errordesc = o_retstring where mappingid = i_mappingid;
              commit;
              return;
          end;
          v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,'cast','picture');
          o_objindex := v_mapindex;
          o_objid := v_mappingid;
          o_param1 := v_pictureid;
          o_param2 := v_castid;
        end if;
      exception
        when no_data_found then
             null;
      end;
/*
	  -- insert cpcnt_record
	  sp_object_cpcnt_record_insert
      (
       i_taskindex,    --任务主键
       i_correlateid,  --对象所属工单编号
       v_objecttype,   --对象类型
       3,              --同步类型:1-REGIST,2-UPDATE,3-DELETE
       o_param2,       --对象id,为mapping时对应elementid
       i_elementcode,  --对象code,为mapping时对应elementcode
       o_param1,       --文广parentid,对象为mapping时必填
       i_parentcode,   --文广parentcod,对象为mapping时必填
       v_retcode,      --返回值  0-成功 其他失败
       v_desc          --结果描述
      );
      if (v_retcode != 0) then
        update zxdbm_cms.icm_smg_mapping t
        set t.errordesc = package_imp_icm.static_error||'mapdel: sp_object_cpcnt_record_insert' || v_desc
        where t.parentcode = i_parentcode
        and t.elementcode = i_elementcode
        and t.correlateid = i_correlateid;
        o_retvalue  := 36;
        o_retstring := package_imp_icm.static_error||'mapdel: sp_object_cpcnt_record_insert' || v_desc;
      end if;
*/
    --end
  exception
    when others then
      rollback;
      o_retvalue  := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm,1,128);
  end sp_smg_sync_mapdel;

-------------------------specific mapping end------------------------------------


----------------------------other begin------------------------------------------
  procedure sp_smg_sync_checkactor
  (
    i_actorname    in varchar2,
    i_actortype    in varchar2,
    i_contentindex in number,
    o_retvalue     out number
  )
  as
    v_count            number(6);
    v_actorindex       number(10);
    v_actortypename    varchar2(20);
    v_objindex         number(10);
    v_objcode          varchar2(40);
    v_castrolecode     varchar2(40);
    v_mapindex         number(10);

  begin
    --return init
    o_retvalue := 0;

    --check actortype
    if i_actortype = 'player' then
      v_actortypename := '演员';
    end if;

    if i_actortype = 'director' then
      v_actortypename := '导演';
    end if;

    select count(*) into v_count from zxdbm_umap.ucm_cnt_actor
    where actortypename = v_actortypename and actorname = i_actorname;

    --actor exist
    if v_count > 0 then
      select actorindex into v_actorindex from zxdbm_umap.ucm_cnt_actor
      where actortypename = v_actortypename and actorname = i_actorname and rownum = 1;

      select count(*) into v_count from zxdbm_umap.ucm_cnt_actor_map
      where contentindex = i_contentindex and actorindex = v_actorindex;

      if v_count > 0 then
        return;
      else
        --delete old actormap and actor
        for aindex in (select b.actorindex
                         from zxdbm_umap.ucm_cnt_actor b,zxdbm_umap.ucm_cnt_actor_map a
                        where b.actorindex = a.actorindex
                          and b.actortypename = v_actortypename
                          and a.contentindex = i_contentindex) loop
          delete from zxdbm_umap.ucm_cnt_actor_map where actorindex = aindex.actorindex and contentindex = i_contentindex;
          delete from zxdbm_umap.ucm_cnt_actor where actorindex = aindex.actorindex;
        end loop;

        --insert new actor map
        zxdbm_umap.sp_getmaxvalue('ucm_cnt_actor_map', 1, v_mapindex);
        insert into zxdbm_umap.ucm_cnt_actor_map
        (
          mapindex, contentindex, actorindex, status, syncresultstatus
          , publishtime, servicekey
        )
        values
        (
          v_mapindex, i_contentindex, v_actorindex, 22, 0
          , to_char(sysdate, 'yyyymmddhh24miss'), 'IPTV'
        );
      end if;
    --actor not exist
    else
      --insert new actor
      zxdbm_umap.sp_getmaxvalue('ucm_content', 1, v_objindex);
      v_objcode := '99999999' || '00000003' || lpad(v_objindex, 16, '0');
      v_castrolecode := '99999999' || '00000004' || lpad(v_objindex, 16, '0');
      insert into zxdbm_umap.ucm_cnt_actor
      (
        actorindex, actorid, actortypename, status, syncresultstatus
        , syncerrorcode, gender, actorname, namehead, castcode
        , telecomcode, castrolemapcode, castrolemapid, actorsource, servicekey
        , publishtime, catagoryid
      )
      values
      (
        v_objindex, v_objindex, v_actortypename, '22', '10'
        , '0', '', i_actorname, '', v_objcode
        , v_objcode, v_castrolecode, v_castrolecode, '2', 'IPTV'
        , to_char(sysdate, 'yyyymmddhh24miss'), v_objcode
      );

      --delete old actormap and actor
      for aindex in (select b.actorindex
                       from zxdbm_umap.ucm_cnt_actor b,zxdbm_umap.ucm_cnt_actor_map a
                      where b.actorindex = a.actorindex
                        and b.actortypename = v_actortypename
                        and a.contentindex = i_contentindex) loop
        delete from zxdbm_umap.ucm_cnt_actor_map where actorindex = aindex.actorindex and contentindex = i_contentindex;
        delete from zxdbm_umap.ucm_cnt_actor where actorindex = aindex.actorindex;
      end loop;

      --insert new actor map
      zxdbm_umap.sp_getmaxvalue('ucm_cnt_actor_map', 1, v_mapindex);
      insert into zxdbm_umap.ucm_cnt_actor_map
      (
        mapindex, contentindex, actorindex, status, syncresultstatus
        , publishtime, servicekey
      )
      values
      (
        v_mapindex, i_contentindex, v_objindex, 22, 0
        , to_char(sysdate, 'yyyymmddhh24miss'), 'IPTV'
      );
    end if;

    commit;
  exception
    when others then
      rollback;
      o_retvalue := 1;
      return;
  end sp_smg_sync_checkactor;

----------------------------other end---------------------------------------------

end package_icm_task;
/


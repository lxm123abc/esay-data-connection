create package           package_imp_icm is

  ----success
  static_success varchar2(40) := 'SUCCESS: success!';
  ----error_front
  static_error varchar2(40) := 'ERROR: ';

  ----get cpindex, cpcode
  -- 20140220 liuxp "i_correlateid    in varchar2" 修改为 "i_taskindex      in  number,"
  procedure sp_imp_getcp
  (
    i_taskindex      in  number,
    o_cpindex        out number,
    o_cpcode         out varchar2
  );

  -----get service index
  function sp_imp_getserverindex return number;

  -----更新上游任务表中的priority字段
  procedure sp_imp_priority
  (
      i_taskindex	   in	   number,    -- 对应imp_cms_synctask中的taskindex
      i_priority	   in	   number,	  -- 工单优先级
      o_retcode		   out	   number,	  -- 结果码
	  o_retdesc		   out	   varchar2	-- 结果描述
  );
  ----object 下游同步任务对象日志
  procedure sp_imp_objectlog
  (
	  i_correlateid		in		varchar2,	-- 对应目标系统任务流水号,需要转为数字
	  i_desttype		  in		number,	  -- 目标系统类型 0-IPTV20 1-IPTV30_BMS	 2-IPTV30_EPG 3-IPTV30_CDN
	  i_objtype			  in		varchar2,	-- 对象类型，取值object，mapping
	  i_action			  in		varchar2,	-- 操作类型，取值 REGIST,UPDATE,DELETE
	  i_elementtype		in		varchar2,	-- 对象类型，i_objtype 取值mapping时，为子对象类型
	  i_elementcode		in		varchar2,	-- 对象code，i_objtype 取值mapping时，为子对象code
	  i_parenttype		in		varchar2,	-- 父对象类型，i_objtype取值为mapping时有效
	  i_parentcode		in		varchar2,	-- 父对象code，i_objtype取值为mapping时有效
	  i_objectindex   in    number,   -- 对象主键
	  i_objectid      in    varchar2, -- 对象id
	  i_elementid     in    varchar2, -- mapping的elementid
	  i_parentid      in    varchar2, -- mapping的parentid
	  o_retcode			  out		number,	  -- 结果码
	  o_retdesc			  out		varchar2	-- 结果描述
  );

  --获取下游的correlateid
  --根据desttype类型查询该类型的目标系统是否存在，状态是否正常，如果正常则获取任务流水号(替代taskindex，避免任务阻塞导致下发任务混乱)并返回。
  procedure sp_imp_get_correlateid
  (
   i_desttype		  in		number,		-- 目标系统类型 0-2.0能力平台 1-BMS 2-EPG 3-CDN
   o_correlateid  out   varchar2, -- 流水号
	 o_retcode		  out		number,		-- 返回码 0-成功 1-网元不存在  2-状态不正常 3-获取correlateid失败
   o_retdesc		  out		varchar2  -- 错误描述信息
  );

  --插入下游任务，并更新对象日志状态
  procedure sp_imp_synctask_deal
  (
   i_taskindex        in    number,   -- 上游同步任务主键
	 i_status			      in		number,   -- 操作结果 0-成功 非0-失败
	 i_20_correlateid	  in		varchar2, -- iptv2.0 对象日志对应的流水号
	 i_cdn_correlateid  in		varchar2, -- cdn 对象日志对应的流水号
	 i_bms_correlateid  in		varchar2, -- bms 对象日志对应的流水号
	 i_epg_correlateid  in		varchar2, -- epg 对象日志对应的流水号
	 i_20_syncfilerul	  in		varchar2, -- iptv2.0 同步任务xml路径
	 i_cdn_syncfileurl	in		varchar2, -- cdn 同步任务xml路径
	 i_bms_syncfileurl	in		varchar2, -- bms 同步任务xml路径
	 i_epg_syncfileurl	in		varchar2, -- epg 同步任务xml路径
	 o_retcode			    out		number,   -- 结果码
	 o_retdesc			    out		varchar2  -- 结果描述信息
  );

  --program
  procedure sp_imp_program
  (
    i_correlateid    in varchar2,
    i_id             in varchar2,
    i_action         in varchar2,
    i_code           in varchar2,
    i_name           in varchar2,
    i_ordernumber    in varchar2,
    i_originalname   in varchar2,
    i_sortname       in varchar2,
    i_searchname     in varchar2,
    i_genre          in varchar2,
    i_actordisplay   in varchar2,
    i_writerdisplay  in varchar2,
    i_originalcountry in varchar2,
    i_language       in varchar2,
    i_releaseyear    in varchar2,
    i_orgairdate     in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision   in varchar2,
    i_description   in varchar2,
    i_pricetaxin    in varchar2,
    i_status        in varchar2,
    i_sourcetype    in varchar2,
    i_seriesflag    in varchar2,
    i_type          in varchar2,         --节目内容类型
    i_keywords      in varchar2,         --关键字
    i_tags          in varchar2,         --关联标签
    i_reserve1      in varchar2,
    i_reserve2      in varchar2,
    i_reserve3      in varchar2,
    i_reserve4      in varchar2,
    i_reserve5      in varchar2,
    i_storagetype   in varchar2,         --存储分发策略要求  0-厂商CDN可不要存储本节目（在海量存储中保存，具体视频路径在Movie.OCSURL）  1-厂商CDN存储本节目  >2-自定义策略（具体对应策略在厂商系统中定义，可以做到部分节目点覆盖，或者后拉视频文件）
    i_rmediacode    in varchar2,         --关联内容唯一标识
    i_taskindex     in number,
    o_objindex		  out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  --movie
  procedure sp_imp_movie
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_type          in varchar2,
    i_fileurl       in varchar2,
    i_sourcedrmtype in varchar2,
    i_destdrmtype   in varchar2,
    i_audiotype     in varchar2,
    i_screenformat  in varchar2,
    i_closedcaptioning  in varchar2,
    i_ocsurl        in varchar2,
    i_duration      in varchar2,
    i_filesize      in varchar2,
    i_bitratetype   in varchar2,
    i_videotype     in varchar2,
    i_audieotype    in varchar2,
    i_resolution    in varchar2,
    i_videoprofile  in varchar2,
    i_systemlayer   in varchar2,
    i_playstarttime in varchar2, --20140312 lxp ott局点需求 片头片尾时间 格式 hh:mm:ss
    i_playstoptime  in varchar2,
    i_taskindex     in number,
    i_status        in number,   --1-下载实体文件  0-不用下载实体文件
    i_domain		    in varchar2,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex      out number,
    o_objid	        out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,-- 补发工单时，存放全量数据库中的fileurl
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  --channel
  procedure sp_imp_channel
  (
    i_correlateid       in varchar2,
    i_id                in varchar2,
    i_action            in varchar2,
    i_code              in varchar2,
    i_channelnumber     in varchar2,
    i_channelname       in varchar2,
    i_callsign          in varchar2,
    i_timeshift         in varchar2,
    i_storageduration   in varchar2,
    i_timeshiftduration in varchar2,
    i_description       in varchar2,
    i_country           in varchar2,
    i_state             in varchar2,
    i_city              in varchar2,
    i_zipcode           in varchar2,
    i_type              in varchar2,
    i_subtype           in varchar2,
    i_language          in varchar2,
    i_status            in varchar2,
    i_starttime         in varchar2,
    i_endtime           in varchar2,
    i_macrovision       in varchar2,
    i_videotype         in varchar2,
    i_audiotype         in varchar2,
    i_streamtype        in varchar2,
    i_bilingual         in varchar2,
    i_url               in varchar2,    --Web频道入口地址，当type=2时，这个属性必填
    i_taskindex         in number,
    o_objindex          out number,
    o_objid             out varchar2,
    o_param1            out varchar2,
    o_param2            out varchar2,
    o_retvalue          out number,
    o_retstring         out varchar2
  );

  --physicalChannel
  procedure sp_imp_physicalChannel
  (
   i_correlateid      in varchar2,
   i_id               in varchar2,
   i_action           in varchar2,
   i_code             in varchar2,
   i_channelid        in varchar2,
   i_channelcode      in varchar2,
   i_bitratetype      in varchar2,
   i_multicastip      in varchar2,
   i_multicastport    in varchar2,
   i_taskindex        in number,
   i_domain		      in varchar2,
   o_objindex         out number,
   o_objid            out varchar2,
   o_param1           out varchar2,
   o_param2           out varchar2,
   o_retvalue         out number,
   o_retstring        out varchar2
  );

  --schedule
  procedure sp_imp_schedule
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_channelid    in varchar2,
    i_channelcode  in varchar2,
    i_programname  in varchar2,
    i_searchname   in varchar2,   --搜索名称供界面搜索
    i_genre        in varchar2,   --schedule的默认类别(genre)
    i_sourcetype   in varchar2,   --1-VOD   5-Advertisement
    i_startdate    in varchar2,
    i_starttime    in varchar2,
    i_duration     in varchar2,
    i_status       in varchar2,
    i_description  in varchar2,
    i_objecttype   in varchar2,   --关联的对象类型   1-LiveTV Program(直播频道用)  2-VOD Program(虚拟频道用)  3-LiveTV Channel(虚拟频道中引入的直播频道)
    i_objectcode   in varchar2,   --关联对象code  objecttype为1时，填programcode(对于live流，原来没有相关的program关联，需新增program)  objecttype为2时，填programcode(关联已有VOD)  objecttype为3时，填channelcode(关联已有livechannel)
    i_taskindex    in number,
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  );

  --picture
  procedure sp_imp_picture
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_fileurl      in varchar2,
    i_description  in varchar2,
    i_taskindex    in number,
    i_status       in number,   --1-下载实体文件  0-不用下载实体文件
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  );

  --category
  procedure sp_imp_category
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_parentcode    in varchar2,
    i_parentid      in varchar2,
    i_name          in varchar2,
    i_sequence      in varchar2,
    i_status        in varchar2,
    i_description   in varchar2,
    i_taskindex     in number,
    o_objindex      out number,
    o_objid         out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  );

  --series
  procedure sp_imp_series
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_ordernumber          in varchar2,
    i_originalname         in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_orgairdate           in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision          in varchar2,
    i_price                in varchar2,
    i_volumncount          in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_type                 in varchar2,         --节目内容类型
    i_keywords             in varchar2,         --关键字
    i_tags                 in varchar2,         --关联标签
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  );

  --package
  procedure sp_imp_package
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_type                 in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_rentalperiod         in varchar2,
    i_ordernumber          in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_price                in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_keywords             in varchar2,
    i_tags                 in varchar2,
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  );

  --cast
  procedure sp_imp_cast
  (
   i_correlateid          in varchar2,
   i_id                   in varchar2,
   i_action               in varchar2,
   i_code                 in varchar2,
   i_castname             in varchar2,
   i_persondisplayname    in varchar2,
   i_personsortname       in varchar2,
   i_personsearchname     in varchar2,
   i_firstname            in varchar2,
   i_middlename           in varchar2,
   i_lastname             in varchar2,
   i_sex                  in varchar2,
   i_birthday             in varchar2,
   i_hometown             in varchar2,
   i_education            in varchar2,
   i_height               in varchar2,
   i_weight               in varchar2,
   i_bloodgroup           in varchar2,
   i_marriage             in varchar2,
   i_favorite             in varchar2,
   i_webpage              in varchar2,
   i_description          in varchar2,
   i_taskindex            in number,
   o_objindex             out number,
   o_objid                out varchar2,
   o_param1               out varchar2,
   o_param2               out varchar2,
   o_retvalue             out number,
   o_retstring            out varchar2
  );

  --castrolemap
  procedure sp_imp_castrolemap
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_castrole             in varchar2,
    i_castid               in varchar2,
    i_castcode             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  );

  --mapping
  procedure sp_imp_mapping
  (
    i_correlateid in varchar2,
    i_id          in varchar2,
    i_action      in varchar2,
    i_parenttype  in varchar2,
    i_elementtype in varchar2,
    i_parentid    in varchar2,
    i_elementid   in varchar2,
    i_parentcode  in varchar2,
    i_elementcode in varchar2,
    i_type        in varchar2,
    i_validstart  in varchar2,
    i_validend    in varchar2,
    i_sequence    in varchar2,
    i_taskindex   in number,
    o_objindex    out number,
    o_objid       out varchar2,
    o_param1      out varchar2,
    o_param2      out varchar2,
    o_retvalue    out number,
    o_retstring   out varchar2
  );

  --339 to -v task. insert into zxdbm_cms.icm_smg_synctask
  procedure sp_imp_synctask_insert
  (
    i_correlateid    in varchar2,     -- 工单流水号
    i_cspid          in varchar2,     -- 工单对应的cspid
    i_lspid          in varchar2,     -- 工单对应的lspid
    i_fileurl        in varchar2,     -- 工单中xml指令文件ftp地址
    i_cpurl          in varchar2,		  -- 对应cp提供的回调url 对应表中的cpurl字段
    i_impcode        in varchar2,		  -- 接口机编号（接口机独立部署有关）对应表中的 impcode字段
    i_rulecode       in varchar2,		  -- 对应cp采用的接口规范 对应表中的rulecode字段
    i_retrytimes     in number,       -- 重发次数
    o_retvalue       out number,      -- 结果码
    o_retstring      out varchar2     -- 结果描述信息
  );

  --339 to -v task. update zxdbm_cms.imp_cms_synctask
  procedure sp_imp_synctask_update
  (
    i_taskindex        in number,   -- 任务index
    i_status           in number,   -- 状态值 10-待执行   20-执行中  30-执行成功  40-执行失败
    i_localreqfileurl  in varchar2, -- 下载xml文件的本地FTP路径
    i_localrspfileurl  in varchar2, -- 存放应答文件的FTP路径
    i_errdesc	         in varchar2, -- 结果描述信息
    o_retvalue         out number,
    o_retstring        out varchar2
  );

  --339 to -v task detail. insert into zxdbm_cms.icm_smg_synctask_detail
  procedure sp_imp_synctask_detail_insert
  (
    i_taskindex      in number,
    i_correlateid    in varchar2,
    i_code           in varchar2,
    i_codetype       in varchar2,
    i_status         in number,
    i_endtime        in varchar2,
    o_retvalue       out number,
    o_retstring      out varchar2
  );

  --339 to -v task detail. update zxdbm_cms.icm_smg_synctask_detail status
  procedure sp_imp_synctask_detail_update
  (
    i_taskindex      in number,
    i_code           in varchar2,
    i_status         in number,
    i_newurl         in varchar2,
    i_filesize		 in varchar2,
    o_retvalue       out number,
    o_retstring      out varchar2
  );

  --335 to ability task. update zxdbm_umap.usync_task status = 50
  procedure sp_imp_usync_update
  (
    i_taskindex      in number,    --taskindex
    i_lspid          in varchar2,  --reserve07
    i_cmdresult      in varchar2,  --reserve08
    i_resultfileurl  in varchar2,  --reserve09
    i_errordescription  in varchar2, --reserve10
    o_retvalue       out number,
    o_retstring      out varchar2
  );

  --335 to ability task. update zxdbm_umap.usync_task = 20,30,40
  procedure sp_querytask
  (
      i_oper          in  number,    --0 need to publish, 1 publishing
      i_taskindex     in  number,
      i_status        in  number,    --20 success, 40 fail
      o_retval        out number     --return value : 0 - success, other - fail
  );

  -- 接口机重启，修改执行中的任务为待执行
  procedure sp_imp_restartprotect
  (
    i_oper          in  varchar2,    --0 need to publish, 1 publishing
    o_retvalue      out number,
    o_retstring     out varchar2     --return value : 0 - success, other - fail
  );

  -- 定时查询是否有回执消息
  procedure sp_imp_get_notify_info
  (
   i_ifwait                in   number,   --0-不需要等待下游回执   1-需要等待下游回执
   i_impcode               in   varchar2,
   o_taskindex             out  number,
   o_correlateid           out  varchar2,
   o_cspid                 out  varchar2,
   o_lspid                 out  varchar2,
   o_cpurl                 out  varchar2,
   o_status				   out  number,   --41-cms失败 31-等待下游反馈 33-向cp反馈中
   o_result                out  number,   --0-成功 -1-cms失败或者都失败 -2-2.0失败 -3-3.0失败
   o_description           out  varchar2,
   o_localrspfileurl       out  varchar2,
   o_fileurl			   out  varchar2, --请求xml
   o_retcode               out  number,   --0-成功   1-失败 2-没有记录
   o_retdesc               out  varchar2  --返回结果描述
  );

  -- 文广反馈后续处理
  procedure sp_imp_finish_notify_task
  (
   i_taskindex   in  number,   -- taskindex
   i_result      in  number,   -- result
   i_iffeedback  in  number,   -- 反馈结果,0-已反馈 1-未反馈 2-无需反馈
   i_ifwait      in  number,   -- 0-不需要等待下游回执   1-需要等待下游回执
   i_impcode     in  varchar2,
   i_rspfileurl  in  varchar2,
   o_retcode     out number,   -- 0-成功   1-失败
   o_retdesc     out varchar2  -- 返回结果描述
  );

end package_imp_icm;
/


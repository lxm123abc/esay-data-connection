create package body           package_imp_icm is

  ----get cpindex, cpcode
  -- 20140220 liuxp "i_correlateid    in varchar2" 修改为 "i_taskindex      in  number,"
  procedure sp_imp_getcp
  (
    i_taskindex      in  number,
    o_cpindex        out number,
    o_cpcode         out varchar2
  )
  as
    v_cspid    zxdbm_cms.imp_cms_synctask.cspid%type;
  begin
    select a.cspid into v_cspid from zxdbm_cms.imp_cms_synctask a where a.taskindex = i_taskindex and rownum=1;
    select cpindex into o_cpindex from zxdbm_cms.icm_sync_cp_map t where t.cpid = v_cspid and rownum=1;
    select cpid into o_cpcode from zxdbm_umap.ucp_basic t where t.cpindex = o_cpindex and servicekey='CMS' and rownum=1;
  exception
    when others then
      o_cpindex := 9;
      o_cpcode := '9';
  end sp_imp_getcp;

  ----get serviceindex
  function sp_imp_getserverindex
  return number is
    v_serviceindex number(10);
  begin
    select serverindex into v_serviceindex from zxdbm_umap.ucm_server where servertype = 5;
    return v_serviceindex;
  exception
    when others then
      return 9;
  end sp_imp_getserverindex;

  --by lxp 20130709
  -----更新上游任务表中的priority字段
  procedure sp_imp_priority
  (
      i_taskindex	   in	   number,    -- 对应imp_cms_synctask中的taskindex
      i_priority	   in	   number,	  -- 工单优先级
      o_retcode		   out	   number,	  -- 结果码
	  o_retdesc		   out	   varchar2	-- 结果描述
  )
  as

  begin
  	--init
  	o_retcode := 0;
    o_retdesc := package_imp_icm.static_success;

    update zxdbm_cms.imp_cms_synctask set priority = nvl(i_priority,priority) where taskindex = i_taskindex;

  exception
    when others then
    o_retcode := 1;
    o_retdesc := package_imp_icm.static_error||substr(sqlerrm, 1, 100);
  end sp_imp_priority;

  --根据desttype类型生成该网元的发布数据（zxdbm_cms.cnt_platform_sync，zxdbm_cms.cnt_target_sync）+对象日志记录（zxdbm_cms.object_sync_record）
  --其中，如果update/delete操作时，如果发布数据已存在则直接生成对象日志记录，如果发布数据不存在则生成发布数据，状态为发布成功
  --by lsm 2013.01.14
  procedure sp_imp_objectlog
  (
	  i_correlateid		in		varchar2,	-- 对应目标系统任务流水号,需要转为数字
	  i_desttype		  in		number,	  -- 目标系统类型 0-IPTV20 1-IPTV30_BMS	 2-IPTV30_EPG 3-IPTV30_CDN
	  i_objtype			  in		varchar2,	-- 对象类型，取值object，mapping
	  i_action			  in		varchar2,	-- 操作类型，取值 REGIST,UPDATE,DELETE
	  i_elementtype		in		varchar2,	-- 对象类型，i_objtype 取值mapping时，为子对象类型
	  i_elementcode		in		varchar2,	-- 对象code，i_objtype 取值mapping时，为子对象code
	  i_parenttype		in		varchar2,	-- 父对象类型，i_objtype取值为mapping时有效
	  i_parentcode		in		varchar2,	-- 父对象code，i_objtype取值为mapping时有效
	  i_objectindex   in    number,   -- 对象主键
	  i_objectid      in    varchar2, -- 对象id
	  i_elementid     in    varchar2, -- mapping的elementid
	  i_parentid      in    varchar2, -- mapping的parentid
	  o_retcode			  out		number,	  -- 结果码
	  o_retdesc			  out		varchar2	-- 结果描述
  )
  as
    v_targetindex    number(10);      --目标系统index
    v_platform       number(3);       --平台类型：1-2.0平台，2-3.0平台
    v_platformindex  number(10);      --对象与发布平台绑定关系表主键
    v_tarsyncindex   number(10);      --对象与发布网元绑定关系表主键
    v_objecttype     number(3);       --对象类型：1-Service，2-Category，3-Program，4-Series......
    v_objectindex    number(10);      --对象index
    v_retcode        number(10);
    v_desc           varchar2(255);
    v_actiontype     number(3);
  begin
    --初始化
    o_retcode:=0;
    o_retdesc:='';

    --获取目标系统信息
    begin
      select targetindex, platform into v_targetindex, v_platform
      from
      (
       select targetindex, platform
       from zxdbm_cms.targetsystem
       where targettype=i_desttype and status=0
       order by targetindex
      )
      where rownum=1;
    exception
      when no_data_found then
        o_retcode:=1;
        o_retdesc:='get target sytem info failed';
        return;
    end;

    --获取对象类型
    if('object'=lower(i_objtype))then
      v_objecttype:=zxdbm_cms.package_icm_task.f_get_objecttype(0,i_elementtype,null);
    else
      v_objecttype:=zxdbm_cms.package_icm_task.f_get_objecttype(1,i_elementtype,i_parenttype);
    end if;
    if (v_objecttype = -1) then
      o_retcode:=3;
      o_retdesc:='get object type failed';
      return;
    end if;

    if ('REGIST' = upper(i_action) or 'UPDATE' = upper(i_action)) then
      if ('REGIST' = upper(i_action)) then
        v_actiontype := 1;
      else
        v_actiontype := 2;
      end if;


      --只有部分对象需要插入这一步
      --1-package 2-category 3-program 4-series 5-channel 6-schedule
      --11-cast 12-castrolemap 21-package-program 22-package-series
      --23-package-channel 25-picture-package 26-category-program
      --27category-series 28-category-channel 29-category-schedule
      --31-picture-category 34-program-castrolemap 35-series-program
      --36-series-program 37-series-castrolemap 38-picture-series
      --39-picture-channel 41-picture-cast
      --20131029 by lxp  29-category-schedule 不转发3.0 仅入接口机缓存表 不生成发布数据
      if (v_objecttype in (1,2,3,4,5,6,11,12,21,22,23,25,26,27,28,/*29,*/31,34,35,36,37,38,39,41)) then

        --插入对象与发布平台绑定关系表
        begin
          select syncindex into v_platformindex
          from zxdbm_cms.cnt_platform_sync
          where objectid=i_objectid
          and platform=v_platform
          and rownum=1;

          update zxdbm_cms.cnt_platform_sync
          set isfiledelete=0
          where objectid=i_objectid
          and platform=v_platform;
        exception
          when no_data_found then
            --获取发布平台绑定关系表index
            zxdbm_umap.sp_getmaxvalue('cnt_platform_sync_index', 1, v_platformindex);
            if (v_platformindex = 0) then
              o_retcode:=2;
              o_retdesc:='get platform sync index failed';
              return;
            end if;
            insert into zxdbm_cms.cnt_platform_sync
                 (syncindex,objecttype,objectindex,objectid,elementid,parentid,platform,status,isfiledelete)
            values(v_platformindex,v_objecttype,i_objectindex,i_objectid,i_elementid,i_parentid,v_platform,0,0);
        end;

        --获取发布网元绑定关系表index
        zxdbm_umap.sp_getmaxvalue('cnt_target_sync_index', 1, v_tarsyncindex);
        if (v_tarsyncindex = 0) then
          o_retcode := 4;
          o_retdesc := 'get target sync index failed';
          return;
        end if;

        --插入对象与发布网元绑定关系表
        merge into zxdbm_cms.cnt_target_sync c
        using (
               select
                      i_objectid as objectid,
                      v_targetindex as targetindex
               from dual
              ) t
        on (c.objectid=t.objectid and c.targetindex=t.targetindex)
        when not matched then
        insert
              (syncindex,relateindex,objecttype,objectindex,objectid,elementid,parentid,targetindex,status,operresult)
        values(v_tarsyncindex,v_platformindex,v_objecttype,i_objectindex,i_objectid,i_elementid,i_parentid,v_targetindex,0,0);
      end if;
    elsif ('DELETE' = upper(i_action)) then
      v_actiontype := 3;
      --更新对象关联平台的状态为已删除
      update zxdbm_cms.cnt_platform_sync
      set isfiledelete=-1
      where objectid=i_objectid and platform=v_platform;
      if (sql%rowcount = 0) then
        o_retcode := 0;
        o_retdesc := 'the cnt_platform_sync record('||v_platform||') do not exists when '||lower(i_action);
        -- 仍需生成日志记录
--        rollback;
--        return;
      end if;
    end if;

    --插入schedulerecord 对象日志
    if (v_objecttype = 6 and i_desttype = 3) then
      --当对象为6-schedule时 3-cdn网元需要插入9-schedulerecord
      for n in (
                select schedulerecordindex,schedulerecordid,cpcontentid,9 objecttype
                from zxdbm_cms.cms_schedulerecord
                where scheduleid=i_objectid
               )
      loop
        --生成对象日志
        zxdbm_cms.package_icm_task.sp_object_sync_record_insert
        (
         to_number(i_correlateid),n.schedulerecordindex,n.schedulerecordid,n.cpcontentid,n.objecttype,
         null,null,null,null,v_actiontype,v_targetindex,i_objtype,v_retcode,v_desc
        );
        if (v_retcode != 0) then
          o_retcode := 5;
          o_retdesc := 'insert schedulerecord '||n.schedulerecordindex||' object log failed when '||lower(i_action)||'-'||v_desc;
          rollback;
          return;
        end if;
      end loop;
    elsif (v_objecttype = 6 and i_desttype = 2) then
      --当对象为6-schedule时，而发往2-epg网元需要插入schedule和schedulerecord对象日志
      for n in (
                select schedulerecordindex,schedulerecordid,cpcontentid,9 objecttype
                from zxdbm_cms.cms_schedulerecord
                where scheduleid=i_objectid
               )
      loop
        --生成对象日志
        zxdbm_cms.package_icm_task.sp_object_sync_record_insert
        (
         to_number(i_correlateid),n.schedulerecordindex,n.schedulerecordid,n.cpcontentid,n.objecttype,
         null,null,null,null,v_actiontype,v_targetindex,i_objtype,v_retcode,v_desc
        );
        if (v_retcode != 0) then
          o_retcode := 6;
          o_retdesc := 'insert schedulerecord '||n.schedulerecordindex||' object log failed when '||lower(i_action)||'-'||v_desc;
          rollback;
          return;
        end if;
      end loop;

      --插入schedule 对象日志
      zxdbm_cms.package_icm_task.sp_object_sync_record_insert
      (
       to_number(i_correlateid),i_objectindex,i_objectid,i_elementcode,v_objecttype,
       i_elementid,i_elementcode,i_parentid,i_parentcode,v_actiontype,v_targetindex,i_objtype,v_retcode,v_desc
      );
      if (v_retcode != 0) then
        o_retcode := 7;
        o_retdesc := 'insert schedule '||i_objectindex||' object log failed when '||lower(i_action)||'-'||v_desc;
        rollback;
        return;
      end if;
    elsif(not(v_objecttype in (3,5) and i_desttype = 3)) then
      --当program和channel时如果发往cdn则不需要插入下游对象日志
      --除了以上对象特殊处理外其他对象都按下面过程插入下游对象日志
      --生成对象日志
      zxdbm_cms.package_icm_task.sp_object_sync_record_insert
      (
       to_number(i_correlateid),i_objectindex,i_objectid,i_elementcode,v_objecttype,
       i_elementid,i_elementcode,i_parentid,i_parentcode,v_actiontype,v_targetindex,i_objtype,v_retcode,v_desc
      );
      if (v_retcode != 0) then
        o_retcode := 8;
        o_retdesc := 'insert object log failed when '||lower(i_action)||'-'||v_desc;
        rollback;
        return;
      end if;
    end if;

  exception
    when others then
      o_retcode := 9;
      o_retdesc := substr(sqlerrm,1,255);
      rollback;
  end sp_imp_objectlog;

  --获取下游的correlateid
  --根据desttype类型查询该类型的目标系统是否存在，状态是否正常，如果正常则获取任务流水号(替代taskindex，避免任务阻塞导致下发任务混乱)并返回。
  procedure sp_imp_get_correlateid
  (
   i_desttype		  in		number,		-- 目标系统类型 0-2.0能力平台 1-BMS 2-EPG 3-CDN
   o_correlateid  out   varchar2, -- 流水号
	 o_retcode		  out		number,		-- 返回码 0-成功 1-状态不正常 2-网元不存在 3-获取correlateid失败
   o_retdesc		  out		varchar2  -- 错误描述信息
  )
  as
    v_status     number(3);       --目标系统状态 0-正常 1-暂停 2-已注销
  begin
    --初始化
    o_correlateid := -1;
    o_retcode := 0;
    o_retdesc := package_imp_icm.static_success;

    --判断目标系统状态是否正常
    begin
      select status into v_status from zxdbm_cms.targetsystem where targettype=i_desttype and status=0 and rownum=1;
    exception
      when no_data_found then
        o_retcode := 1;
        o_retdesc := 'target system that status is normal do not existed';
        return;
    end;

    zxdbm_umap.sp_getmaxvalue('ucdn_task_correlate_id', 1, o_correlateid);
  exception
    when others then
      o_retcode := 2;
      o_retdesc := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_get_correlateid;


  --插入下游任务，并更新对象日志状态
  procedure sp_imp_synctask_deal
  (
   i_taskindex        in    number,   -- 上游同步任务主键
	 i_status			      in		number,   -- 操作结果 0-成功 非0-失败
	 i_20_correlateid	  in		varchar2, -- iptv2.0 对象日志对应的流水号
	 i_cdn_correlateid  in		varchar2, -- cdn 对象日志对应的流水号
	 i_bms_correlateid  in		varchar2, -- bms 对象日志对应的流水号
	 i_epg_correlateid  in		varchar2, -- epg 对象日志对应的流水号
	 i_20_syncfilerul	  in		varchar2, -- iptv2.0 同步任务xml路径
	 i_cdn_syncfileurl	in		varchar2, -- cdn 同步任务xml路径
	 i_bms_syncfileurl	in		varchar2, -- bms 同步任务xml路径
	 i_epg_syncfileurl	in		varchar2, -- epg 同步任务xml路径
	 o_retcode			    out		number,   -- 结果码
	 o_retdesc			    out		varchar2  -- 结果描述信息
  )
  as
    v_taskindex      number(10);   --内容相关对象同步任务表主键
    v_systime        char(14);     --当前系统时间  yyyymmddhh24miss
    v_targetindex    number(10);   --目标系统表主键
    v_actontype      number(3);    --1-REGIST，2-UPDATE，3-DELETE
    v_operresult     number(3);    --操作结果：0-待发布 10-新增同步中 20-新增同步成功 30-新增同步失败 40-修改同步中 50-修改同步成功 60-修改同步失败 70-取消同步中 80-取消同步成功 90-取消同步失败
    v_retcode        number(10);
    v_desc           varchar2(255);
    v_lockindex      number(10);
    v_priority		   number(10);
    v_task20_batchid   number(10);
    v_task30_batchid   number(10);
    v_iptv20_status    number(3);
    v_cdn_status    number(3);
    v_bms_status    number(3);
    v_epg_status    number(3);
    v_iptv20_taskindex number(10);
    v_cdn_taskindex number(10);
    v_bms_taskindex number(10);
    v_epg_taskindex number(10);
    v_flag          number(10);
  begin
    --初始化
    o_retcode := 0;
    o_retdesc := package_imp_icm.static_success;
    v_actontype := 0;
    v_cdn_status := 0;
    v_bms_status := 0;
    v_epg_status := 0;
    v_flag := 0;

    v_systime := to_char(sysdate,'yyyymmddhh24miss');

    if (i_status = 0) then
      v_taskindex := zxdbm_cms.package_icm_task.f_synctask_search(i_taskindex);
      if (v_taskindex = i_taskindex) then

        --删除detail对象
        delete from zxdbm_cms.icm_smg_synctask_detail where taskindex=i_taskindex;

        --更新上游任务状态为等待下游反馈
        update zxdbm_cms.imp_cms_synctask
        set status=31
        where taskindex=i_taskindex
        returning priority into v_priority;

        --将上游任务移到历史表
        /*
        insert into zxdbm_cms.imp_cms_synctask_his
              (taskindex,correlateid,impcode,cspid,lspid,cpindex,cpurl,cptype,cpsynctype,fileurl,rulecode,
               starttime,endtime,status,localreqfileurl,localrspfileurl,priority,result,description)
        select taskindex,correlateid,impcode,cspid,lspid,cpindex,cpurl,cptype,cpsynctype,fileurl,rulecode,
               starttime,endtime,status,localreqfileurl,localrspfileurl,priority,result,description
        from zxdbm_cms.imp_cms_synctask
        where taskindex=i_taskindex;
        delete from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex
        returning priority into v_priority;
        */

        --2.0平台网元
        if (i_20_correlateid is not null) then
          zxdbm_umap.sp_getmaxvalue('ucdn_task_batch_id', 1, v_task20_batchid);
          zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_iptv20_taskindex);
          v_iptv20_status := 1;
          zxdbm_cms.package_icm_task.sp_synctask_deal_forne
          (
           0,
           i_20_correlateid,
           i_20_syncfilerul,
           v_priority,
           i_taskindex,
           v_task20_batchid,
           v_iptv20_status,
           v_iptv20_taskindex,
           v_retcode,
           v_desc
          );
          if (v_retcode != 0) then
            o_retcode := 1;
            o_retdesc := v_desc;
            rollback;
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_20_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_bms_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_epg_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_cdn_correlateid));
            return;
          end if;
        end if;

        --3.0平台当该工单中有对象为delete操作则按epg->bms->cdn的顺序下发对象，否则按cdn->bms->epg的顺序下发对象
        for n in (select actiontype from zxdbm_cms.object_cpcnt_record where taskindex=i_taskindex group by actiontype having count(*)>0)
        loop
          if (n.actiontype = 3) then
            v_actontype := 3;
            exit;
          else
            v_actontype := 1;
          end if;
        end loop;

        if (v_actontype = 1) then
          if (i_cdn_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_cdn_taskindex);

            if (i_bms_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_bms_taskindex);
            end if;

            if (i_epg_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_epg_taskindex);
            end if;

            v_cdn_status := 1;
          elsif (i_bms_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_bms_taskindex);

            if (i_epg_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_epg_taskindex);
            end if;

            v_bms_status := 1;
          elsif (i_epg_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_epg_taskindex);

            v_epg_status := 1;
          end if;
        elsif (v_actontype = 3) then
          if (i_epg_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_epg_taskindex);

            if (i_bms_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_bms_taskindex);
            end if;

            if (i_cdn_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_cdn_taskindex);
            end if;

            v_epg_status := 1;
          elsif (i_bms_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_bms_taskindex);

            if (i_cdn_correlateid is not null) then
              zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_cdn_taskindex);
            end if;

            v_bms_status := 1;
          elsif (i_cdn_correlateid is not null) then
            zxdbm_umap.sp_getmaxvalue('cnt_sync_task', 1, v_cdn_taskindex);

            v_cdn_status := 1;
          end if;
        end if;

        zxdbm_umap.sp_getmaxvalue('ucdn_task_batch_id', 1, v_task30_batchid);

        --目标系统类型 3-CDN
        --<20130215 顺序由第4调至第2 与C代码一致>
        if (i_cdn_correlateid is not null) then
          zxdbm_cms.package_icm_task.sp_synctask_deal_forne
          (
           3,
           i_cdn_correlateid,
           i_cdn_syncfileurl,
           v_priority,
           i_taskindex,
           v_task30_batchid,
           v_cdn_status,
           v_cdn_taskindex,
           v_retcode,
           v_desc
          );
          if (v_retcode != 0) then
            o_retcode := 2;
            o_retdesc := v_desc;
            rollback;
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_20_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_bms_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_epg_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_cdn_correlateid));
            return;
          end if;
        end if;

        --目标系统类型 1-BMS
        if (i_bms_correlateid is not null) then
          zxdbm_cms.package_icm_task.sp_synctask_deal_forne
          (
           1,
           i_bms_correlateid,
           i_bms_syncfileurl,
           v_priority,
           i_taskindex,
           v_task30_batchid,
           v_bms_status,
           v_bms_taskindex,
           v_retcode,
           v_desc
          );
          if (v_retcode != 0) then
            o_retcode := 3;
            o_retdesc := v_desc;
            rollback;
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_20_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_bms_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_epg_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_cdn_correlateid));
            return;
          end if;
        end if;

        --目标系统类型 2-EPG
        if (i_epg_correlateid is not null) then
          zxdbm_cms.package_icm_task.sp_synctask_deal_forne
          (
           2,
           i_epg_correlateid,
           i_epg_syncfileurl,
           v_priority,
           i_taskindex,
           v_task30_batchid,
           v_epg_status,
           v_epg_taskindex,
           v_retcode,
           v_desc
          );
          if (v_retcode != 0) then
            o_retcode := 4;
            o_retdesc := v_desc;
            rollback;
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_20_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_bms_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_epg_correlateid));
            zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_cdn_correlateid));
            return;
          end if;
        end if;

      else
        --更新上游任务为被锁状态
        update zxdbm_cms.imp_cms_synctask
        set status=32
        where taskindex=i_taskindex;

        v_flag := 0;

        if (i_20_correlateid is not null) then
          zxdbm_umap.sp_getmaxvalue('imp_sh_lockedtaskindex', 1, v_lockindex);
          insert into zxdbm_cms.imp_sh_locked_task_tmp
                (lockindex,wg_taskindex,correlateid,syncxmlurl,desttype,starttime,status,lockflag)
          values(v_lockindex,i_taskindex,i_20_correlateid,i_20_syncfilerul,0,v_systime,1,0);
          v_flag := v_flag + 1;
        end if;

        if (i_bms_correlateid is not null) then
          zxdbm_umap.sp_getmaxvalue('imp_sh_lockedtaskindex', 1, v_lockindex);
          insert into zxdbm_cms.imp_sh_locked_task_tmp
                (lockindex,wg_taskindex,correlateid,syncxmlurl,desttype,starttime,status,lockflag)
          values(v_lockindex,i_taskindex,i_bms_correlateid,i_bms_syncfileurl,1,v_systime,1,0);
          v_flag := v_flag + 1;
        end if;

        if (i_epg_correlateid is not null) then
          zxdbm_umap.sp_getmaxvalue('imp_sh_lockedtaskindex', 1, v_lockindex);
          insert into zxdbm_cms.imp_sh_locked_task_tmp
                (lockindex,wg_taskindex,correlateid,syncxmlurl,desttype,starttime,status,lockflag)
          values(v_lockindex,i_taskindex,i_epg_correlateid,i_epg_syncfileurl,2,v_systime,1,0);
          v_flag := v_flag + 1;
        end if;

        if (i_cdn_correlateid is not null) then
          zxdbm_umap.sp_getmaxvalue('imp_sh_lockedtaskindex', 1, v_lockindex);
          insert into zxdbm_cms.imp_sh_locked_task_tmp
                (lockindex,wg_taskindex,correlateid,syncxmlurl,desttype,starttime,status,lockflag)
          values(v_lockindex,i_taskindex,i_cdn_correlateid,i_cdn_syncfileurl,3,v_systime,1,0);
          v_flag := v_flag + 1;
        end if;

        -- 20140126 liuxp 在lock时，如果没有lock记录 则不锁定工单
        if (v_flag <> 0) then
          o_retdesc := 'the task '||i_taskindex||' was locked';
        else
          update zxdbm_cms.imp_cms_synctask
          set status=31
          where taskindex=i_taskindex;
          o_retdesc := 'unlock';
        end if;

      end if;

    else
      --删除detail对象
      delete from zxdbm_cms.icm_smg_synctask_detail where taskindex=i_taskindex;

      --更新上游任务状态为CMS失败
      update zxdbm_cms.imp_cms_synctask
      set status=41
      where taskindex=i_taskindex;
      --将上游任务移到历史表
      /*
      insert into zxdbm_cms.imp_cms_synctask_his
            (taskindex,correlateid,impcode,cspid,lspid,cpindex,cpurl,cptype,cpsynctype,fileurl,rulecode,
             starttime,endtime,status,localreqfileurl,localrspfileurl,priority,result,description)
      select taskindex,correlateid,impcode,cspid,lspid,cpindex,cpurl,cptype,cpsynctype,fileurl,rulecode,
             starttime,endtime,status,localreqfileurl,localrspfileurl,priority,result,description
      from zxdbm_cms.imp_cms_synctask
      where taskindex=i_taskindex;
      delete from zxdbm_cms.imp_cms_synctask where taskindex=i_taskindex;
      */

      --回滚下游的对象记录和注册的发布数据
      zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_20_correlateid));
      zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_cdn_correlateid));
      zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_bms_correlateid));
      zxdbm_cms.package_icm_task.sp_synctask_deal_rollback(to_number(i_epg_correlateid));

    end if;

  exception
    when others then
      rollback;
      o_retcode := 5;
      o_retdesc := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_synctask_deal;



----------------xml object begin------------------------------
  ----object
  --program
  procedure sp_imp_program
  (
    i_correlateid    in varchar2,
    i_id             in varchar2,       --接口中的唯一标识
    i_action         in varchar2,       --操作类型 REGIST  UPDATE DELETE
    i_code           in varchar2,       --全局唯一标识
    i_name           in varchar2,       --节目名称
    i_ordernumber    in varchar2,       --节目订购编号
    i_originalname   in varchar2,       --原名
    i_sortname       in varchar2,       --索引名称供界面排序
    i_searchname     in varchar2,       --搜索名称供界面搜索
    i_genre          in varchar2,       --program的默认类别
    i_actordisplay   in varchar2,       --演员列表
    i_writerdisplay  in varchar2,       --作者列表
    i_originalcountry in varchar2,      --国家地区
    i_language       in varchar2,       --语言
    i_releaseyear    in varchar2,       --上演年份 yyyy
    i_orgairdate     in varchar2,       --首播日期  yyyymmdd
    i_licensingwindowstart in varchar2, --有效开始时间 yyyymmddhh24miss
    i_licensingwindowend   in varchar2, --有效结束时间 yyyymmddhh24miss
    i_displayasnew         in varchar2, --新到天数
    i_displayaslastchance  in varchar2, --剩余天数
    i_macrovision   in varchar2,        --拷贝保护标志 0-无拷贝保护  1-有拷贝保护
    i_description   in varchar2,        --节目描述
    i_pricetaxin    in varchar2,        --列表定价
    i_status        in varchar2,        --状态标志 0-失效 1-生效
    i_sourcetype    in varchar2,        --1-vod  5-advertisement
    i_seriesflag    in varchar2,        --0-普通vod  1-连续剧剧集
    i_type          in varchar2,        --节目内容类型
    i_keywords      in varchar2,        --关键字
    i_tags          in varchar2,        --关联标签
    i_reserve1      in varchar2,
    i_reserve2      in varchar2,
    i_reserve3      in varchar2,
    i_reserve4      in varchar2,
    i_reserve5      in varchar2,
    i_storagetype   in varchar2,         --存储分发策略要求  0-厂商CDN可不要存储本节目（在海量存储中保存，具体视频路径在Movie.OCSURL）  1-厂商CDN存储本节目  >2-自定义策略（具体对应策略在厂商系统中定义，可以做到部分节目点覆盖，或者后拉视频文件）
    i_rmediacode    in varchar2,         --关联内容唯一标识
    i_taskindex     in number,
    o_objindex		out	number,
    o_objid			    out	varchar2,
    o_param1			  out	varchar2,
    o_param2			  out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_codetype       varchar(20) := 'PROGRAM';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_result         number(3) := 0;
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode	     number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_program
    (
      i_correlateid    ,
      i_id             ,
      i_action         ,
      i_code           ,
      i_name           ,
      i_ordernumber    ,
      i_originalname   ,
      i_sortname       ,
      i_searchname     ,
      i_genre          ,
      i_actordisplay   ,
      i_writerdisplay  ,
      i_originalcountry,
      i_language       ,
      i_releaseyear    ,
      i_orgairdate     ,
      i_licensingwindowstart ,
      i_licensingwindowend   ,
      i_displayasnew         ,
      i_displayaslastchance  ,
      i_macrovision   ,
      i_description   ,
      i_pricetaxin    ,
      i_status        ,
      i_sourcetype    ,
      i_seriesflag    ,
      i_type          ,         --节目内容类型
      i_keywords      ,         --关键字
      i_tags          ,         --关联标签
      i_reserve1      ,
      i_reserve2      ,
      i_reserve3      ,
      i_reserve4      ,
      i_reserve5      ,
      i_storagetype   ,         --存储分发策略要求  0-厂商CDN可不要存储本节目（在海量存储中保存，具体视频路径在Movie.OCSURL）  1-厂商CDN存储本节目  >2-自定义策略（具体对应策略在厂商系统中定义，可以做到部分节目点覆盖，或者后拉视频文件）
      i_rmediacode    ,         --关联内容唯一标识
      i_taskindex     ,
      o_objindex	  ,
      o_objid			    ,
      o_param1			  ,
      o_param2			  ,
      o_retvalue      ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_program where correlateid = i_correlateid and programcode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_program
    (
      correlateid, programid, action, programcode, programname
      , ordernumber, originalname, sortname, searchname, actordisplay
      , writerdisplay, originalcountry, language, releaseyear, orgairdate
      , licensingstart, licensingend, displayasnew, displayaslastchance, macrovision
      , description, price, status, sourcetype, seriesflag, type, keywords, tags
      , reserve1, reserve2, reserve3, reserve4, reserve5
      , storagetype, rmediacode, result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_name
      , i_ordernumber, i_originalname, i_sortname, i_searchname, i_actordisplay
      , i_writerdisplay, i_originalcountry, i_language, i_releaseyear, i_orgairdate
      , i_licensingwindowstart, i_licensingwindowend, to_number(i_displayasnew), to_number(i_displayaslastchance), to_number(i_macrovision)
      , i_description, to_number(i_pricetaxin), to_number(i_status), i_sourcetype, i_seriesflag, i_type, i_keywords, i_tags
      , i_reserve1, i_reserve2, i_reserve3, i_reserve4, i_reserve5
      , to_number(i_storagetype), i_rmediacode, o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into icm_smg_program
      (
        correlateid, programid, action, programcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'program',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,		 --返回值  0-成功 其他失败
     v_desc			 --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_program;

  --movie
  --20130806 liuxp add 新增i_domain入参
  procedure sp_imp_movie
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_type          in varchar2,
    i_fileurl       in varchar2,
    i_sourcedrmtype in varchar2,
    i_destdrmtype   in varchar2,
    i_audiotype     in varchar2,
    i_screenformat  in varchar2,
    i_closedcaptioning  in varchar2,
    i_ocsurl        in varchar2,
    i_duration      in varchar2,
    i_filesize      in varchar2,
    i_bitratetype   in varchar2,
    i_videotype     in varchar2,
    i_audieotype    in varchar2,
    i_resolution    in varchar2,
    i_videoprofile  in varchar2,
    i_systemlayer   in varchar2,
    i_playstarttime in varchar2, --20140312 lxp ott局点需求 片头片尾时间 格式 hh:mm:ss
    i_playstoptime  in varchar2,
    i_taskindex     in number,
    i_status        in number,   --1-下载实体文件  0-不用下载实体文件
    i_domain		in varchar2,
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex      out number,
    o_objid	        out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_codetype       varchar(20) := 'MOVIE';
    v_endtime        char(14) := '';
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_movie
    (
      i_correlateid   ,
      i_id            ,
      i_action        ,
      i_code          ,
      i_type          ,
      i_fileurl       ,
      i_sourcedrmtype ,
      i_destdrmtype   ,
      i_audiotype     ,
      i_screenformat  ,
      i_closedcaptioning  ,
      i_ocsurl        ,
      i_duration      ,
      i_filesize      ,
      i_bitratetype   ,
      i_videotype     ,
      i_audieotype    ,
      i_resolution    ,
      i_videoprofile  ,
      i_systemlayer   ,
      i_taskindex     ,
      i_domain		  ,
      i_workmode      ,
      o_objindex      ,
      o_objid         ,
      o_param1        ,
      o_param2        ,
      o_retvalue      ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_movie where correlateid = i_correlateid and moviecode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_movie
    (
      correlateid, movieid, action, moviecode, type
      , fileurl, sourcedrmtype, destdrmtype, audiotype, screenformat
      , closedcaptioning, ocsurl, duration, filesize, bitratetype
      , videotype, audieotype, resolution, videoprofile
      , systemlayer, result, errordescription,playstarttime,playstoptime
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_type
      , i_fileurl, i_sourcedrmtype, i_destdrmtype, i_audiotype, i_screenformat
      , i_closedcaptioning, i_ocsurl, i_duration, nvl(to_number(i_filesize),0), to_number(i_bitratetype)
      , to_number(i_videotype), to_number(i_audieotype), to_number(i_resolution), to_number(i_videoprofile)
      , to_number(i_systemlayer), o_retvalue, o_retstring,i_playstarttime,i_playstoptime
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_movie
      (
        correlateid, movieid, action, moviecode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;
    commit;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'movie',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 4;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if (upper(i_action) = 'REGIST' or upper(i_action) = 'UPDATE') and o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        i_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_movie;

  --channel
  procedure sp_imp_channel
  (
   i_correlateid       in varchar2,
   i_id                in varchar2,
   i_action            in varchar2,
   i_code              in varchar2,
   i_channelnumber     in varchar2,
   i_channelname       in varchar2,
   i_callsign          in varchar2,
   i_timeshift         in varchar2,
   i_storageduration   in varchar2,
   i_timeshiftduration in varchar2,
   i_description       in varchar2,
   i_country           in varchar2,
   i_state             in varchar2,
   i_city              in varchar2,
   i_zipcode           in varchar2,
   i_type              in varchar2,
   i_subtype           in varchar2,
   i_language          in varchar2,
   i_status            in varchar2,
   i_starttime         in varchar2,
   i_endtime           in varchar2,
   i_macrovision       in varchar2,
   i_videotype         in varchar2,
   i_audiotype         in varchar2,
   i_streamtype        in varchar2,
   i_bilingual         in varchar2,
   i_url               in varchar2,    --Web频道入口地址，当type=2时，这个属性必填
   i_taskindex         in number,
   o_objindex          out number,
   o_objid             out varchar2,
   o_param1            out varchar2,
   o_param2            out varchar2,
   o_retvalue          out number,
   o_retstring         out varchar2
  )
  as
    v_codetype       varchar(20) := 'CHANNEL';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode          number(10);
    v_desc             varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_channel
    (
      i_correlateid       ,
      i_id                ,
      i_action            ,
      i_code              ,
      i_channelnumber     ,
      i_channelname       ,
      i_callsign          ,
      i_timeshift         ,
      i_storageduration   ,
      i_timeshiftduration ,
      i_description       ,
      i_country           ,
      i_state             ,
      i_city              ,
      i_zipcode           ,
      i_type              ,
      i_subtype           ,
      i_language          ,
      i_status            ,
      i_starttime         ,
      i_endtime           ,
      i_macrovision       ,
      i_videotype         ,
      i_audiotype         ,
      i_streamtype        ,
      i_bilingual         ,
      i_url               ,
      i_taskindex         ,
      o_objindex          ,
      o_objid             ,
      o_param1            ,
      o_param2            ,
      o_retvalue          ,
      o_retstring
    );

    begin
      --delete from same  correlateid and code
      delete from zxdbm_cms.icm_smg_channel where correlateid = i_correlateid and channelcode = i_code;

      --insert into
      insert into zxdbm_cms.icm_smg_channel
      (
        correlateid, channelid, action, channelcode, channelnumber
        , channelname, callsign, timeshift, storageduration, timeshiftduration
        , description, country, state, city, zipcode
        , type, subtype, language, status, starttime
        , endtime, macrovision, videotype, audiotype, streamtype
        , bilingual,url,result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, trim(i_channelnumber)
        , i_channelname, i_callsign, i_timeshift, i_storageduration, i_timeshiftduration
        , i_description, i_country, i_state, i_city, i_zipcode
        , i_type, i_subtype, i_language, i_status, i_starttime
        , i_endtime, i_macrovision, i_videotype, i_audiotype, i_streamtype
        , i_bilingual,i_url,o_retvalue, o_retstring
      );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_channel
      (
        correlateid, channelid, action, channelcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
      commit;
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'channel',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_channel;

  --physicalChannel
  procedure sp_imp_physicalchannel
  (
   i_correlateid      in varchar2,
   i_id               in varchar2,
   i_action           in varchar2,
   i_code             in varchar2,
   i_channelid        in varchar2,
   i_channelcode      in varchar2,
   i_bitratetype      in varchar2,
   i_multicastip      in varchar2,
   i_multicastport    in varchar2,
   i_taskindex        in number,
   i_domain		      in varchar2,
   o_objindex         out number,
   o_objid            out varchar2,
   o_param1           out varchar2,
   o_param2           out varchar2,
   o_retvalue         out number,
   o_retstring        out varchar2
  )
  as
    v_codetype       varchar(20) := 'PHYSICALCHANNEL';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_physicalChannel
    (
      i_correlateid ,
      i_id,
      i_action,
      i_code,
      i_channelid,
      i_channelcode,
      i_bitratetype,
      i_multicastip,
      i_multicastport,
      i_taskindex,
      i_domain,
      o_objindex,
      o_objid,
      o_param1,
      o_param2,
      o_retvalue,
      o_retstring
    );

    null;

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_physicalchannel where correlateid = i_correlateid and physicalchannelcode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_physicalChannel
    (
      correlateid, physicalchannelid, action, physicalchannelcode, channelcode
      , channelid, bitratetype, multicastip, multicastport
      , result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_channelcode
      , i_channelid, i_bitratetype, i_multicastip, i_multicastport
      , o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_physicalChannel
      (
        correlateid, physicalchannelid, action, physicalchannelcode, channelcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, i_channelcode, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'physicalchannel',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

    commit;
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_physicalchannel;

  --schedule
  procedure sp_imp_schedule
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_channelid    in varchar2,
    i_channelcode  in varchar2,
    i_programname  in varchar2,
    i_searchname   in varchar2,   --搜索名称供界面搜索
    i_genre        in varchar2,   --schedule的默认类别(genre)
    i_sourcetype   in varchar2,   --1-VOD   5-Advertisement
    i_startdate    in varchar2,
    i_starttime    in varchar2,
    i_duration     in varchar2,
    i_status       in varchar2,
    i_description  in varchar2,
    i_objecttype   in varchar2,   --关联的对象类型   1-LiveTV Program(直播频道用)  2-VOD Program(虚拟频道用)  3-LiveTV Channel(虚拟频道中引入的直播频道)
    i_objectcode   in varchar2,   --关联对象code  objecttype为1时，填programcode(对于live流，原来没有相关的program关联，需新增program)  objecttype为2时，填programcode(关联已有VOD)  objecttype为3时，填channelcode(关联已有livechannel)
    i_taskindex    in number,
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  )
  as
    v_codetype       varchar(20) := 'SCHEDULE';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_schedule
    (
      i_correlateid  ,
      i_id           ,
      i_action       ,
      i_code         ,
      i_channelid    ,
      i_channelcode  ,
      i_programname  ,
      i_searchname   ,   --搜索名称供界面搜索
      i_genre        ,   --schedule的默认类别(genre)
      i_sourcetype   ,   --1-VOD   5-Advertisement
      i_startdate    ,
      i_starttime    ,
      i_duration     ,
      i_status       ,
      i_description  ,
      i_objecttype   ,   --关联的对象类型   1-LiveTV Program(直播频道用)  2-VOD Program(虚拟频道用)  3-LiveTV Channel(虚拟频道中引入的直播频道)
      i_objectcode   ,   --关联对象code  objecttype为1时，填programcode(对于live流，原来没有相关的program关联，需新增program)  objecttype为2时，填programcode(关联已有VOD)  objecttype为3时，填channelcode(关联已有livechannel)
      i_taskindex    ,
      o_objindex     ,
      o_objid        ,
      o_param1       ,
      o_param2       ,
      o_retvalue     ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_schedule where correlateid = i_correlateid and schedulecode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_schedule
    (
      correlateid, scheduleid, action, schedulecode, channelcode
      , channelid, programname, searchname, genre, sourcetype
      , startdate, starttime, duration, status, description
      , objecttype, objectcode, result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_channelcode
      , i_channelid, i_programname, i_searchname, i_genre, i_sourcetype
      , i_startdate, i_starttime, i_duration, i_status, i_description
      , i_objecttype, i_objectcode, o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into icm_smg_schedule
      (
        correlateid, scheduleid, action, schedulecode, channelcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, i_channelcode, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'schedule',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_schedule;

  --picture
  procedure sp_imp_picture
  (
    i_correlateid  in varchar2,
    i_id           in varchar2,
    i_action       in varchar2,
    i_code         in varchar2,
    i_fileurl      in varchar2,
    i_description  in varchar2,
    i_taskindex    in number,
    i_status       in number,   --1-下载实体文件  0-不用下载实体文件
    i_workmode		in number,   --20131010 0-补发工单 返回全量数据库中的fileurl 1-正式上线 无操作
    o_objindex     out number,
    o_objid        out varchar2,
    o_param1       out varchar2,
    o_param2       out varchar2,
    o_retvalue     out number,
    o_retstring    out varchar2
  )
  as
    v_codetype       varchar(20) := 'PICTURE';
    v_endtime        char(14) := '';
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
  package_icm_task.sp_smg_picture
  (
    i_correlateid  ,
    i_id           ,
    i_action       ,
    i_code         ,
    i_fileurl      ,
    i_description  ,
    i_taskindex    ,
    i_workmode     ,
    o_objindex     ,
    o_objid        ,
    o_param1       ,
    o_param2       ,
    o_retvalue     ,
    o_retstring
  );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_picture where correlateid = i_correlateid and picturecode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_picture
    (
      correlateid, pictureid, action, picturecode, fileurl, description
      , result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_fileurl, i_description
      , o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_picture
      (
        correlateid, pictureid, action, picturecode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'picture',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if (upper(i_action) = 'REGIST' or upper(i_action) = 'UPDATE') and o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        i_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4006';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_picture;

  --category
  procedure sp_imp_category
  (
    i_correlateid   in varchar2,
    i_id            in varchar2,
    i_action        in varchar2,
    i_code          in varchar2,
    i_parentcode    in varchar2,
    i_parentid      in varchar2,
    i_name          in varchar2,
    i_sequence      in varchar2,
    i_status        in varchar2,
    i_description   in varchar2,
    i_taskindex     in number,
    o_objindex      out number,
    o_objid         out varchar2,
    o_param1        out varchar2,
    o_param2        out varchar2,
    o_retvalue      out number,
    o_retstring     out varchar2
  )
  as
    v_codetype       varchar(20) := 'CATEGORY';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_column
    (
      i_correlateid   ,
      i_id            ,
      i_action        ,
      i_code          ,
      i_parentcode    ,
      i_parentid      ,
      i_name          ,
      i_sequence      ,
      i_status        ,
      i_description   ,
      i_taskindex     ,
      o_objindex      ,
      o_objid         ,
      o_param1        ,
      o_param2        ,
      o_retvalue      ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_category where correlateid = i_correlateid and categorycode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_category
    (
      correlateid, categoryid, action, categorycode, parentcode
      , parentid, name, sequence, status, description
      , result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_parentcode
      , i_parentid, i_name, i_sequence, i_status, i_description
      , o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into icm_smg_category
      (
        correlateid, categoryid, action, categorycode, parentcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, i_parentcode, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'category',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 9;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

    commit;
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_category;

  --series
  procedure sp_imp_series
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_ordernumber          in varchar2,
    i_originalname         in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_orgairdate           in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_displayasnew         in varchar2,
    i_displayaslastchance  in varchar2,
    i_macrovision          in varchar2,
    i_price                in varchar2,
    i_volumncount          in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_type                 in varchar2,         --节目内容类型
    i_keywords             in varchar2,         --关键字
    i_tags                 in varchar2,         --关联标签
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  )
  as
    v_codetype       varchar(20) := 'SERIES';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_series
    (
      i_correlateid          ,
      i_id                   ,
      i_action               ,
      i_code                 ,
      i_name                 ,
      i_ordernumber          ,
      i_originalname         ,
      i_sortname             ,
      i_searchname           ,
      i_orgairdate           ,
      i_licensingwindowstart ,
      i_licensingwindowend   ,
      i_displayasnew         ,
      i_displayaslastchance  ,
      i_macrovision          ,
      i_price                ,
      i_volumncount          ,
      i_status               ,
      i_description          ,
      i_type                 ,         --节目内容类型
      i_keywords             ,         --关键字
      i_tags                 ,         --关联标签
      i_reserve1             ,
      i_reserve2             ,
      i_reserve3             ,
      i_reserve4             ,
      i_reserve5             ,
      i_taskindex            ,
      o_objindex             ,
      o_objid                ,
      o_param1               ,
      o_param2               ,
      o_retvalue             ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_series where correlateid = i_correlateid and seriescode = i_code;
    commit;

    --insert into
    insert into zxdbm_cms.icm_smg_series
    (
      correlateid, seriesid, action, seriescode, name
      , ordernumber, originalname, sortname, searchname, orgairdate
      , licensingwindowstart, licensingwindowend, displayasnew, displayaslastchance, macrovision
      , price, volumncount, status, description, type
      , keywords, tags, reserve1, reserve2, reserve3
      , reserve4, reserve5, result, errordescription
    )
    values
    (
      i_correlateid, i_id, i_action, i_code, i_name
      , i_ordernumber, i_originalname, i_sortname, i_searchname, i_orgairdate
      , i_licensingwindowstart, i_licensingwindowend, i_displayasnew, i_displayaslastchance, i_macrovision
      , i_price, i_volumncount, i_status, i_description, i_type
      , i_keywords, i_tags, i_reserve1, i_reserve2, i_reserve3
      , i_reserve4, i_reserve5, o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_series
      (
        correlateid, seriesid, action, seriescode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'series',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

    commit;
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_series;

  --cast
  procedure sp_imp_cast
  (
   i_correlateid          in varchar2,
   i_id                   in varchar2,
   i_action               in varchar2,
   i_code                 in varchar2,
   i_castname             in varchar2,
   i_persondisplayname    in varchar2,
   i_personsortname       in varchar2,
   i_personsearchname     in varchar2,
   i_firstname            in varchar2,
   i_middlename           in varchar2,
   i_lastname             in varchar2,
   i_sex                  in varchar2,
   i_birthday             in varchar2,
   i_hometown             in varchar2,
   i_education            in varchar2,
   i_height               in varchar2,
   i_weight               in varchar2,
   i_bloodgroup           in varchar2,
   i_marriage             in varchar2,
   i_favorite             in varchar2,
   i_webpage              in varchar2,
   i_description          in varchar2,
   i_taskindex            in number,
   o_objindex             out number,
   o_objid                out varchar2,
   o_param1               out varchar2,
   o_param2               out varchar2,
   o_retvalue             out number,
   o_retstring            out varchar2
  )
  as
    v_codetype       varchar(20) := 'CAST';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(1024);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_cast
    (
      i_correlateid          ,
      i_id                   ,
      i_action               ,
      i_code                 ,
      i_castname             ,
      i_persondisplayname    ,
      i_personsortname       ,
      i_personsearchname     ,
      i_firstname            ,
      i_middlename           ,
      i_lastname             ,
      i_sex                  ,
      i_birthday             ,
      i_hometown             ,
      i_education            ,
      i_height               ,
      i_weight               ,
      i_bloodgroup           ,
      i_marriage             ,
      i_favorite             ,
      i_webpage              ,
      i_description          ,
      i_taskindex            ,
      o_objindex             ,
      o_objid                ,
      o_param1               ,
      o_param2               ,
      o_retvalue             ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_cast where correlateid = i_correlateid and castcode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_cast
    (
      castid, castcode, castname, persondisplayname, personsortname
      , personsearchname, firstname, middlename, lastname, sex
      , birthday, hometown, education, height, weight, bloodgroup
      , marriage, favorite, webpage, description, action
      , correlateid, result, errordescription
    )
    values
    (
      i_id, i_code, i_castname, i_persondisplayname, i_personsortname
      , i_personsearchname, i_firstname, i_middlename, i_lastname, i_sex
      , i_birthday, i_hometown, i_education, i_height, i_weight, i_bloodgroup
      , i_marriage, i_favorite, i_webpage, i_description, i_action
      , i_correlateid, o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_cast
      (
        correlateid, castid, action, castcode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'cast',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 3;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

    commit;
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_cast;




  --castrolemap
  procedure sp_imp_castrolemap
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_castrole             in varchar2,
    i_castid               in varchar2,
    i_castcode             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  )
  as
    v_codetype       varchar(20) := 'CASTROLEMAP';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(1024);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_castrolemap
    (
     i_correlateid ,
     i_id          ,
     i_action      ,
     i_code        ,
     i_castrole    ,
     i_castid      ,
     i_castcode    ,
     i_taskindex   ,
     o_objindex    ,
     o_objid       ,
     o_param1      ,
     o_param2      ,
     o_retvalue    ,
     o_retstring
    );

     begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_castrole where correlateid = i_correlateid and castrolecode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_castrole
    (
      castroleid, castrolecode, castrole, castid, castcode
      , correlateid, errordescription, result, action
    )
    values
    (
      i_id, i_code, i_castrole, i_castid, i_castcode
      , i_correlateid, o_retstring, o_retvalue, i_action
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_castrole
      (
        correlateid, castroleid, action, castrolecode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
      commit;
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'castrolemap',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 5;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);


  end sp_imp_castrolemap;

  --package
  procedure sp_imp_package
  (
    i_correlateid          in varchar2,
    i_id                   in varchar2,
    i_action               in varchar2,
    i_code                 in varchar2,
    i_name                 in varchar2,
    i_type                 in varchar2,
    i_sortname             in varchar2,
    i_searchname           in varchar2,
    i_rentalperiod         in varchar2,
    i_ordernumber          in varchar2,
    i_licensingwindowstart in varchar2,
    i_licensingwindowend   in varchar2,
    i_price                in varchar2,
    i_status               in varchar2,
    i_description          in varchar2,
    i_keywords             in varchar2,
    i_tags                 in varchar2,
    i_reserve1             in varchar2,
    i_reserve2             in varchar2,
    i_reserve3             in varchar2,
    i_reserve4             in varchar2,
    i_reserve5             in varchar2,
    i_taskindex            in number,
    o_objindex             out number,
    o_objid                out varchar2,
    o_param1               out varchar2,
    o_param2               out varchar2,
    o_retvalue             out number,
    o_retstring            out varchar2
  )
  as
    v_codetype       varchar(20) := 'PACKAGE';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --insert into main table
    package_icm_task.sp_smg_service
    (
      i_correlateid          ,
      i_id                   ,
      i_action               ,
      i_code                 ,
      i_name                 ,
      i_type                 ,
      i_sortname             ,
      i_searchname           ,
      i_rentalperiod         ,
      i_ordernumber          ,
      i_licensingwindowstart ,
      i_licensingwindowend   ,
      i_price                ,
      i_status               ,
      i_description          ,
      i_keywords             ,
      i_tags                 ,
      i_reserve1             ,
      i_reserve2             ,
      i_reserve3             ,
      i_reserve4             ,
      i_reserve5             ,
      i_taskindex            ,
      o_objindex             ,
      o_objid                ,
      o_param1               ,
      o_param2               ,
      o_retvalue             ,
      o_retstring
    );

    begin
    --delete from same  correlateid and code
    delete from zxdbm_cms.icm_smg_package where correlateid = i_correlateid and packagecode = i_code;

    --insert into
    insert into zxdbm_cms.icm_smg_package
    (
      packageid,correlateid, action, packagecode, name
      , type, sortname, searchname, rentalperiod, ordernumber
      , licensingwindowstart, licensingwindowend, price, status, description,keywords
      ,tags,reserve1,reserve2,reserve3,reserve4,reserve5
      , result, errordescription
    )
    values
    (
      i_id, i_correlateid, i_action, i_code, i_name
      , i_type, i_sortname, i_searchname, i_rentalperiod, i_ordernumber
      , i_licensingwindowstart, i_licensingwindowend, i_price, i_status, i_description,i_keywords
      , i_tags,i_reserve1,i_reserve2,i_reserve3,i_reserve4,i_reserve5,o_retvalue, o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into icm_smg_package
      (
        correlateid, packageid, action, packagecode, result, errordescription
      )
      values
      (
        i_correlateid, i_id, i_action, i_code, decode(o_retvalue,0,0,1), o_retstring
      );
    end;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(0,'package',null);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_objid,        --对象id,为mapping时对应elementid
     i_code,         --对象code,为mapping时对应elementcode
     null,           --文广parentid,对象为mapping时必填
     null,           --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      rollback;
      o_retvalue := 6;
      o_retstring := package_imp_icm.static_error||v_desc;
      return;
    end if;

    if o_retvalue = 0 then
      --insert into task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_code          ,
        v_codetype      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;

    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_package;


----------------xml object end------------------------------


----------------xml mapping begin------------------------------
  --mapping
  procedure sp_imp_mapping
  (
    i_correlateid in varchar2,
    i_id          in varchar2,
    i_action      in varchar2,
    i_parenttype  in varchar2,
    i_elementtype in varchar2,
    i_parentid    in varchar2,
    i_elementid   in varchar2,
    i_parentcode  in varchar2,
    i_elementcode in varchar2,
    i_type        in varchar2,
    i_validstart  in varchar2,
    i_validend    in varchar2,
    i_sequence    in varchar2,
    i_taskindex   in number,
    o_objindex    out number,
    o_objid       out varchar2,
    o_param1      out varchar2,
    o_param2      out varchar2,
    o_retvalue    out number,
    o_retstring   out varchar2
  )
  as
    v_id   number(10);
    v_codetype       varchar(20) := 'MAPPING';
    v_status         number(3) := 0;
    v_endtime        char(14) := to_char(sysdate, 'yyyymmddhh24miss');
    v_actiontype     number(3);
    v_objecttype     number(10);
    v_retcode        number(10);
    v_desc           varchar2(255);
    o_retvalue2      number(10);
    o_retstring2     varchar2(128);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    begin
    --insert into
    zxdbm_umap.sp_getmaxvalue('icm_smg_mappingindex', 1, v_id);

    insert into zxdbm_cms.icm_smg_mapping
    (
      correlateid, action, parenttype, elementtype, parentid
      , elementid, parentcode, elementcode, type, validstart
      , validend, sequence, mappingid, errordesc
    )
    values
    (
      i_correlateid, i_action, i_parenttype, i_elementtype, i_parentid
      , i_elementid, i_parentcode, i_elementcode, i_type, i_validstart
      , i_validend, i_sequence, v_id,o_retstring
    );
    exception when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
      insert into zxdbm_cms.icm_smg_mapping
      (
        correlateid, action, parenttype, elementtype, parentid
        , elementid, parentcode, elementcode, mappingid,errordesc
      )
      values
      (
        i_correlateid, i_action, i_parenttype, i_elementtype, i_parentid
      , i_elementid, i_parentcode, i_elementcode, v_id,o_retstring
      );
    end;
    --为了防止后面异常回滚
    commit;

    ----insert into main table
    if upper(i_action) = 'REGIST' or upper(i_action) = 'UPDATE' then
      package_icm_task.sp_smg_sync_mapreg
      (
        i_correlateid ,
        v_id          ,
        i_action      ,
        i_parenttype  ,
        i_elementtype ,
        i_parentid    ,
        i_elementid   ,
        i_parentcode  ,
        i_elementcode ,
        i_type        ,
        i_validstart  ,
        i_validend    ,
        i_sequence    ,
        i_taskindex   ,
        o_objindex    ,
        o_objid       ,
        o_param1      ,
        o_param2      ,
        o_retvalue    ,
        o_retstring
      );
    --DELETE
    else
      package_icm_task.sp_smg_sync_mapdel
      (
        i_correlateid ,
        v_id          ,
        i_action      ,
        i_parenttype  ,
        i_elementtype ,
        i_parentid    ,
        i_elementid   ,
        i_parentcode  ,
        i_elementcode ,
        i_type        ,
        i_sequence    ,
        i_taskindex   ,
        o_objindex    ,
        o_objid       ,
        o_param1      ,
        o_param2      ,
        o_retvalue    ,
        o_retstring
      );
    end if;

    -- 20131021 Liuxp 生成上游对象日志信息
    v_actiontype := zxdbm_cms.package_icm_task.f_get_actionttype(i_action);
    v_objecttype := zxdbm_cms.package_icm_task.f_get_objecttype(1,i_elementtype,i_parenttype);

    zxdbm_cms.package_icm_task.sp_object_cpcnt_record_insert
    (
     i_taskindex,    --任务主键
     i_correlateid,  --对象所属工单编号
     v_objecttype,   --对象类型
     v_actiontype,   --同步类型:1-REGIST,2-UPDATE,3-DELETE
     o_param2,       --对象id,为mapping时对应elementid
     i_elementcode,  --对象code,为mapping时对应elementcode
     o_param1,       --文广parentid,对象为mapping时必填
     i_parentcode,   --文广parentcod,对象为mapping时必填
     o_retvalue,     --内容入库结果  0-成功 其他失败
     o_retstring,    --内容入库结果描述
     v_retcode,      --返回值  0-成功 其他失败
     v_desc          --结果描述
    );
    if (v_retcode != 0) then
      update zxdbm_cms.icm_smg_mapping t
      set t.errordesc = package_imp_icm.static_error||'mapreg: sp_object_cpcnt_record_insert' || v_desc
      where t.parentcode = i_parentcode
      and t.elementcode = i_elementcode
      and t.correlateid = i_correlateid;
      o_retvalue  := 35;
      o_retstring := package_imp_icm.static_error||'mapreg: sp_object_cpcnt_record_insert' || v_desc;
    end if;

    if o_retvalue = 0 then
      --insert into parent task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_parentcode          ,
        upper(i_parenttype)      ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;

      --insert into element task_detail
      sp_imp_synctask_detail_insert
      (
        i_taskindex     ,
        i_correlateid   ,
        i_elementcode          ,
        upper(i_elementtype)   ,
        v_status        ,
        v_endtime       ,
        o_retvalue2     ,
        o_retstring2
      );
      if o_retvalue2 <> 0 then
        o_retvalue := '4002';
        o_retstring := package_imp_icm.static_error||' '||o_retvalue2||'-'||o_retstring2;
        return;
      end if;
    end if;
    ----update iptv task result
    --package_icm_task.sp_synctask_update(i_correlateid , o_retvalue);

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_mapping;
----------------xml mapping end------------------------------



----------------task begin------------------------------
  --insert into task
  procedure sp_imp_synctask_insert
  (
    i_correlateid    in varchar2,     -- 工单流水号
    i_cspid          in varchar2,     -- 工单对应的cspid
    i_lspid          in varchar2,     -- 工单对应的lspid
    i_fileurl        in varchar2,     -- 工单中xml指令文件ftp地址
    i_cpurl          in varchar2,		  -- 对应cp提供的回调url 对应表中的cpurl字段
    i_impcode        in varchar2,		  -- 接口机编号（接口机独立部署有关）对应表中的 impcode字段
    i_rulecode       in varchar2,		  -- 对应cp采用的接口规范 对应表中的rulecode字段
    i_retrytimes     in number,       -- 重发次数
    o_retvalue       out number,      -- 结果码
    o_retstring      out varchar2     -- 结果描述信息
  )
  as
    v_taskindex   zxdbm_cms.imp_cms_synctask.taskindex%type;
    v_nowtime char(14) := to_char(sysdate,'yyyymmddhh24miss');
    v_status  number(3):= 10; --10-待执行 20-执行中 30-成功 31-待下游反馈 32-待解锁 40-失败 41-cms失败
    v_cpindex  number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    --get index
    zxdbm_umap.sp_getmaxvalue('imp_cms_synctask_index', 1, v_taskindex);

    --cpindex
    begin
      select cpindex into v_cpindex from zxdbm_cms.icm_sync_cp_map where cpid = i_cspid and rownum = 1;
    exception when others then
      v_cpindex := 9;
    end;

    --insert into
    insert into zxdbm_cms.imp_cms_synctask
    (
      taskindex, correlateid, impcode, cspid, lspid
      , cpindex, cpurl, cptype, cpsynctype, fileurl
      , rulecode, starttime, status, retrytimes, wg_reply
    )
    values
    (
      v_taskindex, i_correlateid, i_impcode, i_cspid, i_lspid
      , v_cpindex, i_cpurl, 1, 1, i_fileurl
      , i_rulecode, v_nowtime, v_status, i_retrytimes, 0
    );

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_synctask_insert;

  --update task
  procedure sp_imp_synctask_update
  (
    i_taskindex        in number,   -- 任务index
    i_status           in number,   -- 状态值 10-待执行 20-执行中 30-成功 31-待下游反馈 32-待解锁 40-失败 41-cms失败
    i_localreqfileurl  in varchar2, -- 下载xml文件的本地FTP路径
    i_localrspfileurl  in varchar2, -- 存放应答文件的FTP路径
    i_errdesc	         in varchar2, -- 结果描述信息
    o_retvalue         out number,
    o_retstring        out varchar2
  )
  as
    v_nowtime char(14) := to_char(sysdate,'yyyymmddhh24miss');
    v_taskindex  number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    if i_status = 20 then
      update zxdbm_cms.imp_cms_synctask
      set status = i_status,
          starttime = v_nowtime
      where taskindex = i_taskindex;
    elsif i_status = 32 or i_status = 41 then
      --update status by index
      -- 20131128 liuxp 状态保持执行中不变
      update zxdbm_cms.imp_cms_synctask
      set endtime = v_nowtime,
          status = status,
--          status = decode(i_status,41,status,i_status),
          localreqfileurl = i_localreqfileurl,
          localrspfileurl = i_localrspfileurl,
          description = decode(i_status,41,i_errdesc,description)
      where taskindex = i_taskindex;

      --not exist
      if sql%rowcount = 0 then
        rollback;
        o_retvalue := 1;
        o_retstring := 'not exists imp_cms_synctask record -'||i_taskindex;
        return;
      end if;
      -- 20131023 liuxp 仅更新结束时间
      --更新
      update zxdbm_cms.object_cpcnt_record
      set endtime=v_nowtime
--          resultcode = decode(i_status, 32, 2, 3),
--          resultdesc=i_errdesc
      where taskindex = i_taskindex;
      /*
      if i_status = 40 then
        --delete detail
        delete from zxdbm_cms.icm_smg_synctask_detail where taskindex = i_taskindex;
        --insert into history
        insert into zxdbm_cms.imp_cms_synctask_his
        select * from zxdbm_cms.imp_cms_synctask where taskindex = i_taskindex;
        delete from zxdbm_cms.imp_cms_synctask where taskindex = i_taskindex;

      --当i_status为30成功时，该任务在生成下游的同步任务时再移到历史表中
      end if;
      */
    end if;

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_synctask_update;

  --insert into detail task
  procedure sp_imp_synctask_detail_insert
  (
    i_taskindex      in number,
    i_correlateid    in varchar2,
    i_code           in varchar2,
    i_codetype       in varchar2,
    i_status         in number,  --status:0-ready;1-not ready
    i_endtime        in varchar2,
    o_retvalue       out number,
    o_retstring      out varchar2
  )
  as
    v_oldurl     zxdbm_cms.imp_cms_synctask.fileurl%type;
    v_detailindex  number(10);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select fileurl into v_oldurl
    from zxdbm_cms.imp_cms_synctask
    where taskindex = i_taskindex;

    --get detail index
    zxdbm_umap.sp_getmaxvalue('icm_smg_synctaskdetailindex', 1, v_detailindex);

    --insert into
    insert into zxdbm_cms.icm_smg_synctask_detail
    (
      detailindex, taskindex, correlateid, code, codetype
      , oldurl, starttime, endtime, status
    )
    values
    (
      v_detailindex, i_taskindex, i_correlateid, i_code, i_codetype
      , v_oldurl, to_char(sysdate, 'yyyymmddhh24miss'), i_endtime, i_status
    );

  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 64);
  end sp_imp_synctask_detail_insert;

  --update task detail
  procedure sp_imp_synctask_detail_update
  (
    i_taskindex      in number,
    i_code           in varchar2,
    i_status         in number,
    i_newurl         in varchar2,
    i_filesize		 in varchar2,
    o_retvalue       out number,
    o_retstring      out varchar2
  )
  as
    v_nowtime char(14) := to_char(sysdate,'yyyymmddhh24miss');
    v_correlateid zxdbm_cms.icm_smg_synctask_detail.correlateid%type;
    v_codetype  zxdbm_cms.icm_smg_synctask_detail.codetype%type;
    v_newurl    zxdbm_cms.icm_smg_synctask_detail.newurl%type;
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;
    -- 0 - ok, 1 - fail,
    -- 10010 - download success, 10011 - download fail, 10012  --  ftp find file error
    -- 10020 - upload success, 10021 - upload fail,
    --update status by index
    -- 20131128 liuxp 为什么 newurl 取 oldurl（来自task表中的fileurl） 修改为直接是传入的值
    update zxdbm_cms.icm_smg_synctask_detail
    set
        status = i_status,
        newurl = i_newurl,
--        newurl = decode(i_status, 0, i_newurl, 10010, i_newurl, 10020, i_newurl, oldurl),
        endtime = v_nowtime
    where taskindex = i_taskindex
    and code = i_code
    and status = 1
    and rownum = 1
    returning correlateid, codetype, newurl
    into v_correlateid, v_codetype, v_newurl;

    --not exist
    if sql%rowcount = 0 then
      rollback;
      return;
    end if;

    -- 20131023 liuxp 更新对象日志信息
    update zxdbm_cms.object_cpcnt_record
    set resultcode=decode(i_status,10010,2,10020,2,3),
    resultdesc=decode(i_status,
    						10011,'cms:Fail to download the xml file.',
    						10012,'cms:Fail to ftp find file error.',
    						10021,'cms:Fail to upload the xml file.',
    						10040,'cms:Fail to parse ftpurl.',
    						resultdesc)
    where taskindex=i_taskindex and objectcode=i_code;

    --if codetype in ('MOVIE', 'PICTURE') then errordescription is ftp url in IPTV manager
    if i_status = 10011 then
      update zxdbm_cms.imp_cms_synctask set result = 1, description = package_imp_icm.static_error||'Fail to download the xml file.' where taskindex = i_taskindex;
      if upper(v_codetype) = 'MOVIE' then
        update zxdbm_cms.icm_smg_movie set result = 1, errordescription = package_imp_icm.static_error||'Fail to download the xml file.' where correlateid = v_correlateid and moviecode = i_code;
      elsif upper(v_codetype) = 'PICTURE' then
        update zxdbm_cms.icm_smg_picture set result = 1, errordescription = package_imp_icm.static_error||'Fail to download the xml file.' where correlateid = v_correlateid and picturecode = i_code;
      end if;
    elsif i_status = 10012 then
      update zxdbm_cms.imp_cms_synctask set result = 1, description = package_imp_icm.static_error||'Fail to ftp find file error.' where taskindex = i_taskindex;
      if upper(v_codetype) = 'MOVIE' then
        update zxdbm_cms.icm_smg_movie set result = 1, errordescription = package_imp_icm.static_error||'Fail to ftp find file error.' where correlateid = v_correlateid and moviecode = i_code;
      elsif upper(v_codetype) = 'PICTURE' then
        update zxdbm_cms.icm_smg_picture set result = 1, errordescription = package_imp_icm.static_error||'Fail to ftp find file error.' where correlateid = v_correlateid and picturecode = i_code;
      end if;
    elsif i_status = 10021 then
      update zxdbm_cms.imp_cms_synctask set result = 1, description = package_imp_icm.static_error||'Fail to upload the xml file.' where taskindex = i_taskindex;
      if upper(v_codetype) = 'MOVIE' then
        update zxdbm_cms.icm_smg_movie set result = 1, errordescription = package_imp_icm.static_error||'Fail to upload the xml file.' where correlateid = v_correlateid and moviecode = i_code;
      elsif upper(v_codetype) = 'PICTURE' then
        update zxdbm_cms.icm_smg_picture set result = 1, errordescription = package_imp_icm.static_error||'Fail to upload the xml file.' where correlateid = v_correlateid and picturecode = i_code;
      end if;
    elsif i_status = 10040 then
      update zxdbm_cms.imp_cms_synctask set result = 1, description = package_imp_icm.static_error||'Fail to parse ftpurl.' where taskindex = i_taskindex;
      if upper(v_codetype) = 'MOVIE' then
        update zxdbm_cms.icm_smg_movie set result = 1, errordescription = package_imp_icm.static_error||'Fail to parse ftpurl.' where correlateid = v_correlateid and moviecode = i_code;
      elsif upper(v_codetype) = 'PICTURE' then
        update zxdbm_cms.icm_smg_picture set result = 1, errordescription = package_imp_icm.static_error||'Fail to parse ftpurl.' where correlateid = v_correlateid and picturecode = i_code;
      end if;
    else
      if upper(v_codetype) = 'MOVIE' then
        update zxdbm_cms.cms_movie m
        set m.fileurl=nvl(v_newurl,m.fileurl),
            m.filesize=decode(to_number(i_filesize),m.filesize,m.filesize,to_number(i_filesize))
        where m.cpcontentid=i_code;

        update zxdbm_cms.icm_smg_movie
        set result = 0, newfileurl = v_newurl,
            filesize=decode(to_number(i_filesize),filesize,filesize,to_number(i_filesize))
        where correlateid = v_correlateid and moviecode = i_code;
      elsif upper(v_codetype) = 'PICTURE' then
        update zxdbm_cms.picture p set p.pictureurl=nvl(v_newurl,p.pictureurl) where p.picturecode=i_code;
        update zxdbm_cms.icm_smg_picture set result = 0, newfileurl = v_newurl where correlateid = v_correlateid and picturecode = i_code;
      end if;
    end if;

    commit;
  exception
    when others then
      rollback;
      o_retvalue := sqlcode;
      o_retstring := package_imp_icm.static_error||substr(sqlerrm, 1, 128);
  end sp_imp_synctask_detail_update;


----------------task end------------------------------

  procedure sp_imp_usync_update
  (
    i_taskindex      in number,    --taskindex
    i_lspid          in varchar2,  --reserve07
    i_cmdresult      in varchar2,  --reserve08 30,40
    i_resultfileurl  in varchar2,  --reserve09
    i_errordescription  in varchar2, --reserve10
    o_retvalue       out number,
    o_retstring      out varchar2
  )
  as
    v_count   number(3);
  begin
    --init
    o_retvalue := 0;
    o_retstring := package_imp_icm.static_success;

    select count(*) into v_count from zxdbm_umap.usync_task where taskindex = i_taskindex and reserve07 = i_lspid;
    if v_count > 0 then
      update zxdbm_umap.usync_task
      set reserve09 = decode(to_number(i_cmdresult), 30, 0, 1), reserve10 = i_resultfileurl, reserve11 = i_errordescription
      , status = decode(to_number(i_cmdresult), 30, 30, 40), endtime = to_char(sysdate, 'yyyymmddhh24miss')
      where taskindex = i_taskindex and reserve07 = i_lspid;

      insert into zxdbm_umap.usync_task_result select * from zxdbm_umap.usync_task where taskindex = i_taskindex and reserve07 = i_lspid;
      delete from zxdbm_umap.usync_task where taskindex = i_taskindex and reserve07 = i_lspid;
    else
      o_retvalue := 1;
      o_retstring := package_imp_icm.static_error||'taskindex not exist, update fail!';
    end if;

    commit;
  exception
    when others then
      null;
  end sp_imp_usync_update;

  procedure sp_querytask
  (
    i_oper          in  number,    --0 need to publish, 1 publishing
    i_taskindex     in  number,
    i_status        in  number,    --20 success, 40 fail
    o_retval        out number     --return value : 0 - success, other - fail
  )
  is
  begin
    --shao miao renwu,status 11
    if i_oper = 1 then
      -- not in task
      update zxdbm_umap.usync_task set status = i_status where taskindex = i_taskindex;
    --ack req
    elsif i_oper = 0 then
      --overtime, assembled information failure, send failure
      if  i_status = 40 then
        --if retrytimes > 0 then status = 10 else retrytimes = 0 then status = 40
        update zxdbm_umap.usync_task set status = decode(sign(retrytimes), 1, 10, 40), endtime = decode(sign(retrytimes), 1, endtime, to_char(sysdate, 'yyyymmddhh24miss')), retrytimes = decode(sign(retrytimes), 1, retrytimes-1, retrytimes) where taskindex = i_taskindex;
      else
        -- success
        update zxdbm_umap.usync_task set status = i_status where taskindex = i_taskindex;
      end if;
    end if;

    if sql%rowcount = 0 then
      rollback;
      o_retval := -1;
      return;
    end if;

    commit;
    o_retval := 0;
  exception
    when others then
      rollback;
      o_retval := -1;
  end sp_querytask;

  -- 接口机重启，修改执行中的任务为待执行
  procedure sp_imp_restartprotect
  (
    i_oper          in  varchar2,    --0 need to publish, 1 publishing
    o_retvalue      out number,      --return value : 0 - success, other - fail
    o_retstring     out varchar2     --return string
  )
  is
  begin
    o_retvalue := 0;

    update zxdbm_cms.imp_cms_synctask set status = 10 where status = 20;
    update zxdbm_cms.imp_cms_synctask
    set retrytimes = retrytimes+1,
        wg_reply=0
    where status = 33 and wg_reply=1;
    commit;
  exception
    when others then
      rollback;
      o_retvalue := 1;
  end sp_imp_restartprotect;

  -- 20140409 lxp 性能调优 查询过滤条件 not exists 改为 0=count(*)
  -- 定时查询是否有回执消息
  procedure sp_imp_get_notify_info
  (
   i_ifwait                in   number,   --0-不需要等待下游回执   1-需要等待下游回执
   i_impcode               in   varchar2,
   o_taskindex             out  number,
   o_correlateid           out  varchar2,
   o_cspid                 out  varchar2,
   o_lspid                 out  varchar2,
   o_cpurl                 out  varchar2,
   o_status				   out  number,   --41-cms失败 31-等待下游反馈 33-向cp反馈中
   o_result                out  number,   --0-成功 -1-cms失败或者都失败 -2-2.0失败 -3-3.0失败
   o_description           out  varchar2,
   o_localrspfileurl       out  varchar2,
   o_fileurl			   out  varchar2, --请求xml
   o_retcode               out  number,   --0-成功   1-失败 2-没有记录
   o_retdesc               out  varchar2  --返回结果描述
  )
  as
   v_status           number(3);
   v_result           number(10);
   v_taskindex        number(10);
   v_result_30        number(10);
   v_result_20        number(10);
   v_retrytimes       number(3);
   v_correlateid      varchar2(32);
   v_cspid            varchar2(32);
   v_lspid            varchar2(32);
   v_cpurl            varchar(256);
   v_description      varchar(1024);
   v_localrspfileurl  varchar2(256);
   v_ifplat20         number(3);
   v_cpcntdelete_switch number(3);
  begin
   v_taskindex := null;
   v_description := '';
   o_localrspfileurl := null;
   v_ifplat20 := 1;
   v_cpcntdelete_switch := 1;
   o_retcode := 0;
   o_retdesc := 'success';
    -- 是否需要等待下游回执 0不需要
    if(i_ifwait = 0)then
      select taskindex,status,retrytimes,result
      into v_taskindex,v_status,v_retrytimes,v_result
      from (select * from zxdbm_cms.imp_cms_synctask
            where status in (31,41,33) and retrytimes>0 and wg_reply=0
            and impcode=i_impcode order by taskindex
       ) p1 where rownum=1;
      if(v_status = 31)then
        v_result := 0;
        v_description := 'success.';
      elsif (v_status = 41) then
        v_result := -1;
        v_description := 'cms failed.';
      else
        v_result := v_result;
      end if;
    else
      -- 是否有2.0平台 0没有 1有
      begin
        -- 是否有2.0平台 0没有 1有 默认存在
        select to_number(cfgvalue) into v_ifplat20
        from zxdbm_umap.usys_config
        where cfgkey = 'cms.imp.ifplatform20' and servicekey='CMS';
      exception when no_data_found then
        v_ifplat20 := 1;
      end;
      if(v_ifplat20 = 0)then
        select p1.taskindex,p1.status,nvl(p1.result_30,0),p1.retrytimes,p1.result
        into v_taskindex,v_status,v_result_30,v_retrytimes,v_result
        from (select * from zxdbm_cms.imp_cms_synctask p
             where (p.status=41 or p.status=33 or (p.status=31 and result_30 is not null) or
             (p.status=31 and 0= --not exists
               (
                 select count(*) from zxdbm_cms.cnt_sync_task t, zxdbm_cms.targetsystem s
                 where t.wg_taskindex=p.taskindex and t.destindex=s.targetindex and s.platform=2
               )
             ))
             and p.retrytimes>0 and wg_reply=0 and impcode=i_impcode order by p.taskindex
        ) p1 where rownum=1 ;
        if(v_status in (31,41))then
          -- 28-3.0 fail 29-2.0 fail
          select decode(v_status+v_result_30,31,0,28,-3,-1),
              decode(v_status+v_result_30,31,'success.',28,'','cms failed.')
          into v_result,v_description
          from dual;
        else
          v_result := v_result;
        end if;
      else
        select p1.taskindex,p1.status,nvl(p1.result_30,0),p1.result_20,p1.retrytimes,p1.result
        into v_taskindex,v_status,v_result_30,v_result_20,v_retrytimes,v_result
        from (select * from zxdbm_cms.imp_cms_synctask p
              where (p.status=41 or p.status=33 or (p.status=31 and result_30 is not null and result_20 is not null) or
             (p.status=31 and 0= --not exists
               (
                 select count(*) from zxdbm_cms.cnt_sync_task t, zxdbm_cms.targetsystem s
                 where t.wg_taskindex=p.taskindex and t.destindex=s.targetindex and s.platform=2
               ) and result_20 is not null
             ))
             and p.retrytimes>0 and wg_reply=0 and impcode=i_impcode order by p.taskindex
        ) p1 where rownum=1;
        if(v_status in (31,41))then
          -- 28-3.0 fail 29-2.0 fail
          select decode(v_status+v_result_30+v_result_20,31,0,28,-3,29,-2,-1),
              decode(v_status+v_result_30+v_result_20,31,'success.',28,'',29,'',26,'all publish failed.','cms failed.')
          into v_result,v_description
          from dual;
        else
          v_result := v_result;
        end if;
      end if;
    end if;

    if v_taskindex is not null then
      update zxdbm_cms.imp_cms_synctask
      set wg_reply=1,retrytimes=retrytimes-1,result=v_result,status=33,description=v_description||description
      where taskindex = v_taskindex and wg_reply=0
      returning correlateid,cspid,lspid,cpurl,description,localrspfileurl,fileurl
      into v_correlateid,v_cspid,v_lspid,v_cpurl,v_description,v_localrspfileurl,o_fileurl;
      -- 20131128 liuxp 添加异常保护，update添加wg_reply=0条件过滤
      if sql%rowcount = 0 then
        rollback;
        o_retcode := 2;
        o_retdesc := 'not exists imp_cms_synctask record to notify';
        return;
      end if;

      if v_result = 0 then
        -- 20140108 liuxp 如果是movie delete成功 则将缓存表中newfileurl清空 movie重新上线 重新拉取实体文件
        update zxdbm_cms.icm_smg_movie a set newfileurl=null
        where newfileurl is not null and exists
        (select * from zxdbm_cms.object_cpcnt_record b
        where b.taskindex=v_taskindex and b.objecttype=7 and b.actiontype=3 and a.moviecode=b.objectcode);

        update zxdbm_cms.icm_smg_picture a set newfileurl=null
        where newfileurl is not null and exists
        (select * from zxdbm_cms.object_cpcnt_record b
        where b.taskindex=v_taskindex and b.objecttype=10 and b.actiontype=3 and a.picturecode=b.objectcode);
      else
        --20140324 liuxp 如果movie regist失败 则将缓存表中newfileurl清空 movie重新注册 重新拉取实体文件
        update zxdbm_cms.icm_smg_movie a set newfileurl=null
        where newfileurl is not null and exists
        (select * from zxdbm_cms.object_cpcnt_record b
        where b.taskindex=v_taskindex and b.objecttype=7 and b.actiontype=1 and a.moviecode=b.objectcode
        and (nvl(retcode_20,0)<>0 or nvl(retcode_30,0)<>0));

        update zxdbm_cms.icm_smg_picture a set newfileurl=null
        where newfileurl is not null and exists
        (select * from zxdbm_cms.object_cpcnt_record b
        where b.taskindex=v_taskindex and b.objecttype=10 and b.actiontype=1 and a.picturecode=b.objectcode
        and (nvl(retcode_20,0)<>0 or nvl(retcode_30,0)<>0));
      end if;

      -- 立即删除开关
      begin
      select to_number(cfgvalue) into v_cpcntdelete_switch
        from zxdbm_umap.usys_config
        where cfgkey = 'cms.imp.cpcntdelete.switch' and servicekey='CMS';
      exception when no_data_found then
        v_cpcntdelete_switch := 1;
      end;

      if v_cpcntdelete_switch = 1 then
        -- 20140213 liuxp 立即删除cp下发的delete内容 （根据cpcnt对象日志记录及发布状态删除）
        zxdbm_cms.sp_imp329_object_delete_timely(v_taskindex);
      end if;

      -- 获取v_result
      if(v_status = 41 or v_status = 33)then   -- 41 -cms失败
        o_localrspfileurl := v_localrspfileurl;
      end if;
      o_taskindex := v_taskindex;
      o_correlateid := v_correlateid;
      o_cspid := v_cspid;
      o_lspid := v_lspid;
      o_cpurl := v_cpurl;
      o_status := v_status;
      o_result := v_result;
      o_description := v_description;
    end if;
    commit;
  exception
    when no_data_found then
      o_retcode := 2;   -- 没有符合条件的记录
      o_retdesc := 'there is no record';
    when others then
      rollback;
      o_retcode := 1;
      o_retdesc := 'failed:'||substr(sqlerrm,1,128);
  end sp_imp_get_notify_info;

  -- 文广反馈后续处理
  procedure sp_imp_finish_notify_task
  (
   i_taskindex   in  number,   -- taskindex
   i_result      in  number,   -- result
   i_iffeedback  in  number,   -- 反馈结果,0-已反馈 1-未反馈 2-无需反馈
   i_ifwait      in  number,   -- 0-不需要等待下游回执   1-需要等待下游回执
   i_impcode     in  varchar2,
   i_rspfileurl  in  varchar2,
   o_retcode     out number,   -- 0-成功   1-失败
   o_retdesc     out varchar2  -- 返回结果描述
  )
  as
   v_status           number(3);
   v_taskindex        number(10);
   v_retrytimes       number(3);
   v_description      varchar2(1024);
   v_taskindexlist    type_number;
   v_ifplat20         number(3);
   v_curtime		  varchar2(20);
  begin
  v_taskindex := null;
  v_description := '';
  v_ifplat20 := 1;
  o_retcode := 0;
  o_retdesc := 'suceess';
  v_curtime := to_char(sysdate,'yyyymmddhh24miss');
    -- 反馈结果
    if(i_iffeedback = 0)then
      if(i_result = 0)then
        v_status := 30;
      else
        v_status := 40;
      end if;
      v_taskindex := i_taskindex;
    elsif (i_iffeedback = 2) then  -- 无需反馈
      -- 是否需要等待下游回执 0不需要
      if(i_ifwait = 0)then
        select taskindex bulk collect into v_taskindexlist
        from zxdbm_cms.imp_cms_synctask
        where status in (31,41) and retrytimes=0 and impcode=i_impcode and wg_reply=0 order by taskindex;
        for i in 1..v_taskindexlist.count
        loop
          update zxdbm_cms.imp_cms_synctask
          set status=decode(status,31,30,40),result = decode(status,31,0,-1),endtime=v_curtime,
              description = decode(status,31,'success.','cms failed.')||description
          where taskindex = v_taskindexlist(i);
          insert into zxdbm_cms.imp_cms_synctask_his
          select * from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(i);
          delete from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(i);
          delete from zxdbm_cms.icm_smg_synctask_detail where taskindex = v_taskindexlist(i);
        end loop;
      else
        -- 是否有2.0平台 0-没有 1-有 默认是有的
        begin
          select to_number(cfgvalue)
          into v_ifplat20
          from zxdbm_umap.usys_config where cfgkey = 'cms.imp.ifplatform20' and servicekey='CMS';
        exception when no_data_found then
          v_ifplat20 := 1;
        end;

        if(v_ifplat20 = 0)then
          select taskindex bulk collect into v_taskindexlist
          from zxdbm_cms.imp_cms_synctask p
          where ((status=31 and result_30 is not null) or status=41 or
             (p.status=31 and not exists
               (
                 select * from zxdbm_cms.cnt_sync_task t, zxdbm_cms.targetsystem s
                 where t.wg_taskindex=p.taskindex and t.destindex=s.targetindex and s.platform=2
               )
             ))
          and retrytimes=0 and impcode=i_impcode and wg_reply=0 order by taskindex;

          for j in 1..v_taskindexlist.count
          loop
            update zxdbm_cms.imp_cms_synctask
            set status=decode(status+nvl(result_30,0),31,30,40),
                result = decode(status+nvl(result_30,0),31,0,28,-3,-1),endtime=v_curtime,
                description = decode(status+nvl(result_30,0),31,'success .',28,'3.0 publish failed .','cms failed .')||description
                where taskindex = v_taskindexlist(j);
            insert into zxdbm_cms.imp_cms_synctask_his
            select * from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(j);
            delete from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(j);
            delete from zxdbm_cms.icm_smg_synctask_detail where taskindex = v_taskindexlist(j);
          end loop;
        else
          select taskindex bulk collect into v_taskindexlist
          from zxdbm_cms.imp_cms_synctask p
          where ((status=31 and result_30 is not null and result_20 is not null) or status=41 or
             (p.status=31 and not exists
               (
                 select * from zxdbm_cms.cnt_sync_task t, zxdbm_cms.targetsystem s
                 where t.wg_taskindex=p.taskindex and t.destindex=s.targetindex and s.platform=2
               ) and result_20 is not null
             ))
          and retrytimes=0 and impcode=i_impcode and wg_reply=0 order by taskindex;

          for m in 1..v_taskindexlist.count
          loop
            update zxdbm_cms.imp_cms_synctask
            set status=decode(status+result_20+nvl(result_30,0),31,30,40),
                result = decode(status+result_20+nvl(result_30,0),31,0,28,-3,29,-2,-1),endtime=v_curtime,
                description = decode(status+result_20+nvl(result_30,0),31,'success.',28,'3.0 publish failed.',29,'2.0 publish failed.',26,'publish failed.','cms failed.')||description
                 where taskindex = v_taskindexlist(m);
            insert into zxdbm_cms.imp_cms_synctask_his
            select * from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(m);
            delete from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindexlist(m);
            delete from zxdbm_cms.icm_smg_synctask_detail where taskindex = v_taskindexlist(m);
          end loop;
        end if;
      end if;

    else
      -- 更新
      update zxdbm_cms.imp_cms_synctask set wg_reply=0,localrspfileurl=nvl(localrspfileurl,i_rspfileurl)
      where taskindex=i_taskindex
      returning retrytimes into v_retrytimes;
      if(v_retrytimes = 0 or v_retrytimes < 0)then
        if(i_result = 0)then
          v_status := 30;
        else
          v_status := 40;
        end if;
        v_taskindex := i_taskindex;
        v_description := 'feedback overtime :';
      end if;
    end if;

    if v_taskindex is not null then
      update zxdbm_cms.imp_cms_synctask
      set status=v_status,result=i_result,endtime=v_curtime,description=v_description||description,
      localrspfileurl=nvl(localrspfileurl,i_rspfileurl)
      where taskindex = v_taskindex;
      insert into zxdbm_cms.imp_cms_synctask_his
      select * from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindex;
      delete from zxdbm_cms.imp_cms_synctask where taskindex = v_taskindex;
      delete from zxdbm_cms.icm_smg_synctask_detail where taskindex = v_taskindex;
    end if;
    commit;
  exception
    when others then
      rollback;
      o_retcode := 1;
      o_retdesc := 'failed:'||substr(sqlerrm,1,128);

  end sp_imp_finish_notify_task;

end package_imp_icm;
/


create procedure           cms_gensubcont_distribute
(
  i_action      in   number,     --任务类型 1，收录任务 2，转码任务
  i_taskindex   in   number,     --任务index
  o_retcode     out  number     --错误码，0：成功，其它：失败
) as
  v_org_subcontentindex   number;         --任务表里的子内容索引  (转码任务时才需要)
  v_destfilelength        number;         --大洋生成文件的时间长度
  v_org_contentindex      number;         --任务表里的内容索引
  v_destfilesize          number;         --任务表里文件大小
  v_destfilepath          varchar2(256);  --任务表里的文件路径
  v_destfilephyfilename   varchar2(256);  --任务表里的文件名称
  v_fileverifycode        varchar2(64);   --任务表里的文件生效码
  v_templateindex         number;         --任务表里的模板索引
  v_sourcetype            number;         --任务来源类型 1：订单；2：分发策略；3：粗编策略；4：粗编任务
  v_sourceindex           number;         --任务来源的索引

  v_subcontentname        varchar2(100);  --生成的子内容名称

  v_org_subcontentid      varchar2(40);   --原子内容id  (转码任务才用到)

  v_servicetype           number;         --子内容应用类型
  v_posttype              number;         --子内容的组类型

  v_framerate             number;         --模板的速率
  v_frameheight           number;         --帧高
  v_framewidth            number;         --帧款
  v_videocodec            varchar2(10);   --视频编码格式
  v_audiocodec            varchar2(10);   --音频编码格式

  e_sucontentindex_error  exception;      --生成子内容index错误   100
  e_taskindex_empty       exception;      --任务index为空  102
  e_action_error          exception;      --任务类型错误   101
  e_task_not_exist        exception;      --任务不存在     103
  e_template_not_exist    exception;      --模板不存在     104
  e_subcontent_not_exist  exception;      --子内容不存在   106
  e_insert_subcon_error   exception;      --生成子内容错误   107

  v_fileindex   zxdbm_cms.icm_sourcefile.fileindex%type;
  v_cpindex     zxdbm_cms.icm_sourcefile.cpindex%type;
  v_cpid        zxdbm_cms.icm_sourcefile.cpid%type;
  v_namecn      zxdbm_cms.icm_sourcefile.namecn%type;
  v_formatindex zxdbm_cms.icm_sourcefile.formatindex%type;
  v_seriesno    zxdbm_cms.icm_sourcefile.seriesno%type;
  v_status      zxdbm_cms.icm_sourcefile.status%type;
  v_uploadtype  zxdbm_cms.icm_sourcefile.uploadtype%type;
  v_ssourcetype zxdbm_cms.icm_sourcefile.sourcetype%type;
  v_filetype    zxdbm_cms.icm_sourcefile.filetype%type;
  v_encodingformat zxdbm_cms.icm_sourcefile.encodingformat%type;

  v_grouptype   zxdbm_cms.cms_avtemplateinfo.grouptype%type;
  v_videobitrate zxdbm_cms.cms_avtemplateinfo.videobitrate%type;
  v_taskstatus   zxdbm_cms.cms_EMBtask.status%type;
  v_type    char(4) := 'MOVI';
  o_telecomcode varchar2(32);
  v_time     number(10);

begin
  --init
  o_retcode := 0;

  if i_taskindex is null then
    raise e_taskindex_empty;
  end if;

  if i_action != 2 and i_action != 1  then
    raise e_action_error;
  end if;

  if i_action = 1 then  --录制的处理，暂时不做
     null;
  else  --转码任务返回的处理

    --从任务表获取必要的参数
    begin
      select contentindex, subcontentindex, destfilesize, destfilepath, destfilephyfilename
      , destfilelength, fileverifycode, templateindex, sourcetype, sourceindex, status
      into   v_org_contentindex, v_org_subcontentindex, v_destfilesize, v_destfilepath, v_destfilephyfilename
      , v_destfilelength, v_fileverifycode, v_templateindex, v_sourcetype, v_sourceindex, v_taskstatus
      from   zxdbm_cms.cms_EMBtask
      where  taskindex = i_taskindex;
      --only status=3 can continue
      if v_taskstatus <> 3 then
        return;
      end if;
    exception
      when others then
        raise e_task_not_exist;
    end;

    --获取原子内容的相关字段信息
    begin
      select cpindex, cpid, namecn, filename, formatindex, filetype, seriesno, encodingformat
      into   v_cpindex, v_cpid, v_namecn, v_subcontentname, v_formatindex, v_filetype, v_seriesno, v_encodingformat
      from   zxdbm_cms.icm_sourcefile
      where  fileindex = v_org_subcontentindex;
    exception
      when others then
        raise e_subcontent_not_exist;
    end;

    zxdbm_cms.sp_get_contentcode('99999999',v_cpid,v_type,o_telecomcode);
    if o_telecomcode = 0  then
      raise e_sucontentindex_error;
    end if;

    --根据模板index获取相关的模板信息
    --if  v_subcontentformat in (1, 8, 9) then --转码文件为视频文件, 现阶段都是视频转码
      begin
        --grouptype: 2-低码流;3-高清;4-标清
        --videobitrate 是码流: 0-150kbps;2-50kbps;1-300kbps
        select framerate, videobitrate, framehight, framewidth, videotype, audiotype, servicetype, grouptype
        into   v_framerate, v_videobitrate, v_frameheight, v_framewidth, v_videocodec, v_audiocodec, v_servicetype, v_grouptype
        from   zxdbm_cms.cms_avtemplateinfo
        where  templateindex = v_templateindex;
      exception
        when others then
          raise e_template_not_exist;
      end;
    --end if;

    zxdbm_umap.sp_getmaxvalue('cms_file', 1, v_fileindex);
    if v_fileindex = 0 then
      raise e_sucontentindex_error;
    end if;

    --生成子内容，入库
    begin
      v_time := ROUND(v_destfilelength/v_framerate, 0);
      v_status := 12;
      v_uploadtype := 1;
      v_ssourcetype := 2;
      insert into zxdbm_cms.icm_sourcefile
      (
        fileindex            ,          --文件index
        cpindex              ,          --cpindex
        cpid                 ,          --cpcode
        namecn               ,          --母片名称
        filename             ,          --文件名称
        formatindex          ,          --封装格式1.TS 2.3GP
        status               ,          --10初始 11上传中 12正常 上传失败后状态改为10
        filetype             ,          --1:正片 2:预览片
        addresspath          ,          --文件在存储区的相对路径(临时区或者在线区)
        --cachepath          ,          --文件在近线区的相对路径
        --addressfile        ,          --
        filesize             ,          --
        --sourceurl          ,          --下载地址DownloadURL
        uploadtype           ,          --上传类型：0-http 1-已上载
        seriesno             ,
        definition           ,          --码流分档:2:标清视频 3：超高清视频 4：高清视频
        sourcetype           ,          --1.母片 2.子文件
        --fileindex,
        parentindex,
        --contentid,
        --fileid,
        --filesize,
        --fileformat,
        --addresspath,
        --filetype,
        encryptedfilename,
        --md5info,
        --mimetype,
        previewtag,
        --formatindex,
        --status,
        posttype,
        cmsid,
        servicekey,
        catagorycode,
        duration,
        bitrate,
        numberofframes,
        frameheight,
        framewidth,
        framerate,
        videocodec,
        audiocodec,
        bitratecode,
        programname,
        encodingformat
      )
      values
      (
        v_fileindex            ,          --文件index
        v_cpindex              ,          --cpindex
        v_cpid                 ,          --cpcode
        v_namecn               ,          --取母片名称作为子片文件名称
        v_destfilephyfilename  ,          --实际文件名称
        v_formatindex          ,          --封装格式1.TS 2.3GP
        v_status               ,          --10初始 11上传中 12正常 上传失败后状态改为10
        v_filetype             ,          --1:正片 2:预览片
        v_destfilepath || '/' || v_destfilephyfilename          ,          --文件在存储区的相对路径(临时区或者在线区)
        --cachepath            ,          --文件在近线区的相对路径
        --addressfile          ,          --
        v_destfilesize         ,          --
        --sourceurl            ,          --下载地址DownloadURL
        v_uploadtype           ,          --上传类型：0-http 1-已上载
        v_seriesno             ,
        v_grouptype            ,          --码流分档:2:标清视频 3：超高清视频 4：高清视频
        v_ssourcetype          ,          --1.母片 2.子文件
        --v_subcontentindex    ,
        v_org_subcontentindex  ,
        --v_contentid ,
        --v_subcontentid,
        --v_destfilesize,
        --v_subcontentformat,
        --v_destfilepath || '/' || v_destfilephyfilename,
        --v_subcontenttype,
        v_org_subcontentid,
        --v_fileverifycode,
        --v_mimetype,
        v_servicetype,
        --v_templateindex,
        --12,
        v_posttype,
        3,
        'CMS',
        o_telecomcode,
        --func_formate_time(v_time),   --play time:hour+minute+second+''
        v_time,
        decode(v_videobitrate, 2, '50000', 0, '150000', 1, '300000', '150000'),  --bitrate number
        v_destfilelength,
        v_frameheight,
        v_framewidth,
        v_framerate,
        v_videocodec,
        v_audiocodec,
        1,
        v_subcontentname,
        v_encodingformat
      );
      commit;
    exception
      when others then
        raise e_insert_subcon_error;
    end;

  end if;

  commit;
exception
  when e_sucontentindex_error then
    rollback;
    o_retcode := 100;
    return;
  when e_action_error then
    rollback;
    o_retcode := 101;
    return;
  when e_taskindex_empty then
    rollback;
    o_retcode := 102;
    return;
  when e_task_not_exist then
    rollback;
    o_retcode := 103;
    return;
  when e_template_not_exist then
    rollback;
    o_retcode := 104;
    return;
  when e_subcontent_not_exist then
    rollback;
    o_retcode := 106;
    return;
  when e_insert_subcon_error then
    rollback;
    o_retcode := 107;
    return;
  when others then
    rollback;
    o_retcode := 222;
    return;
end cms_gensubcont_distribute;
/


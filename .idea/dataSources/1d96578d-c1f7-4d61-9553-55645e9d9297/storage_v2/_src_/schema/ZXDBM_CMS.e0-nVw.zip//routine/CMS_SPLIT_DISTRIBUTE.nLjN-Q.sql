create procedure           cms_split_distribute
(
  i_taskindex   in   number,     --zxdbm_cms.cms_splittask.taskindex
  i_filename    in   varchar2,   --file name
  o_retcode     out  number      --error code:0-success;1-fail
) as
  v_cpid            zxdbm_cms.cms_splittask.cpid%type;
  v_destaddress     zxdbm_cms.cms_splittask.destaddress%type;
  v_tasktype        zxdbm_cms.cms_splittask.tasktype%type;
  v_taskstatus      zxdbm_cms.cms_splittask.status%type;
  v_cpindex         zxdbm_umap.ucp_basic.cpindex%type;
  v_fileindex       zxdbm_cms.cms_tasksource_map.fileindex%type;
  v_formatindex     number(10,0);
  v_filetype        number(3,0);
  v_definition      number(3,0);
  v_bitrate         varchar2(10);
  v_encodingformat  number(3,0);
  v_status          number(3,0);
  v_uploadtype      number(3,0);
  v_sourcetype      number(3,0);
  v_cmsid           number(3,0);
  v_servicekey      varchar2(20);
  v_duration        varchar2(10);
  v_namecn          varchar2(60);

  e_task_not_exist        exception;      --cms_splittask任务不存在     103
  e_cp_not_exist          exception;      --cp不存在                    104
  e_tasksource_not_exist  exception;      --tasksource任务不存在        105
  e_fileindex_not_exist   exception;      --子内容不存在                106
  e_getcontentindex_error exception;      --获取index失败               108
  e_insert_source_error   exception;      --生成子内容错误              107

  --zxdbm_cms.cms_splittask,zxdbm_cms.cms_splittask_his,zxdbm_cms.cms_tasksource_map -> zxdbm_cms.icm_sourcefile
begin
  --init
  o_retcode := 0;

  --从任务表获取必要的参数
  begin
    ----tasktype 任务类型（1表示拆条，2表示合并)
    ----status 任务状态：1待执行 2执行中3 成功结束 4失败结束
    select cpid, func_path_exchange(destaddress, 2), tasktype, status
    into   v_cpid, v_destaddress, v_tasktype, v_taskstatus
    from   zxdbm_cms.cms_splittask_his
    where  taskindex = i_taskindex;
    if v_taskstatus <> 3 then
      return;
    end if;
  exception
    when others then
      raise e_task_not_exist;
  end;

  --find cpindex
  begin
    select cpindex into v_cpindex from zxdbm_umap.ucp_basic where cpid = v_cpid and cptype = 1;
  exception
    when others then
      raise e_cp_not_exist;
  end;

  --查找 fileindex
  begin
    select fileindex
    into   v_fileindex
    from   zxdbm_cms.cms_tasksource_map
    where  taskindex = i_taskindex and rownum = 1;
  exception
    when others then
      raise e_tasksource_not_exist;
  end;

  --icm_file
  begin
    select formatindex, filetype, definition, bitrate, encodingformat, sourcetype, namecn
    into v_formatindex, v_filetype, v_definition, v_bitrate, v_encodingformat, v_sourcetype, v_namecn
    from zxdbm_cms.icm_sourcefile
    where fileindex = v_fileindex;
  exception
    when others then
      raise e_fileindex_not_exist;
  end;


  zxdbm_umap.sp_getmaxvalue('cms_file', 1, v_fileindex);
  if v_fileindex = 0 then
    raise e_getcontentindex_error;
  end if;

  --生成子内容，入库
  begin
    v_status := 12;
    v_uploadtype := 1;
    --1.母片 2.子文件
    if v_tasktype = 2 then
      v_sourcetype := 1;
    end if;
    ----来源：1门户录入，2门户导入,3接口机转码,4接口机收录，5接口机拆条
    v_cmsid := 5;
    v_servicekey := 'CMS';

    insert into zxdbm_cms.icm_sourcefile
    (
      fileindex            ,          --文件index
      cpindex              ,          --cpindex
      cpid                 ,          --cpcode
      namecn               ,          --母片名称
      filename             ,          --文件名称
      formatindex          ,          --封装格式1.TS 2.3GP
      status               ,          --10初始 11上传中 12正常 上传失败后状态改为10
      filetype             ,          --1:正片 2:预览片
      addresspath          ,          --文件在存储区的相对路径(临时区或者在线区)
      --cachepath          ,          --文件在近线区的相对路径
      --addressfile        ,          --
      --filesize           ,          --
      --sourceurl          ,          --下载地址DownloadURL
      uploadtype           ,          --上传类型：0-http 1-已上载
      --seriesno           ,
      definition           ,          --码流分档:2:标清视频 3：超高清视频 4：高清视频
      sourcetype           ,          --1.母片 2.子文件
      cmsid                ,
      servicekey           ,
      bitrate              ,
      --duration             ,
      encodingformat
    )
    values
    (
      v_fileindex            ,          --文件index
      v_cpindex              ,          --cpindex
      v_cpid                 ,          --cpcode
      i_filename             ,          --多个合成一个如何填写?
      i_filename             ,          --实际文件名称,哪来的
      v_formatindex          ,          --封装格式1.TS 2.3GP
      v_status               ,          --10初始 11上传中 12正常 上传失败后状态改为10
      v_filetype             ,          --1:正片 2:预览片
      v_destaddress || '/' || i_taskindex ||'/'||i_filename          ,          --文件在存储区的相对路径(临时区或者在线区)
      --cachepath            ,          --文件在近线区的相对路径
      --addressfile          ,          --
      --v_destfilesize       ,          --文件大小.如何填写?
      --sourceurl            ,          --下载地址DownloadURL
      v_uploadtype           ,          --上传类型：0-http 1-已上载
      --v_seriesno           ,
      v_definition           ,          --码流分档:2:标清视频 3：超高清视频 4：高清视频
      v_sourcetype           ,          --1.母片 2.子文件
      v_cmsid                ,
      v_servicekey           ,
      v_bitrate              ,
      --v_duration             ,
      v_encodingformat
    );
    commit;
  exception
    when others then
      raise e_insert_source_error;
  end;

  commit;
exception
  when e_task_not_exist then
    rollback;
    o_retcode := 103;
  when e_cp_not_exist then
    rollback;
    o_retcode := 104;
  when e_tasksource_not_exist then
    rollback;
    o_retcode := 105;
  when e_fileindex_not_exist then
    rollback;
    o_retcode := 106;
  when e_getcontentindex_error then
    rollback;
    o_retcode := 108;
  when e_insert_source_error then
    rollback;
    o_retcode := 107;
  when others then
    rollback;
    o_retcode := 222;
end cms_split_distribute;
/


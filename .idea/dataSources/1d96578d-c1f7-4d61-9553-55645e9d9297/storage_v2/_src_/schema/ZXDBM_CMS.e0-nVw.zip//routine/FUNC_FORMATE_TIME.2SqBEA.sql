create function           func_formate_time
(
  i_time in  number
) return
varchar2 is
  v_retstring  varchar2(255);
  v_hour number(10);
  v_minute number(10);
  v_second number(10);
begin
  v_hour := trunc(i_time/3600);
  v_minute := trunc(mod(i_time, 3600)/60);
  v_second := mod(i_time, 60);

  return lpad(v_hour ,2,'0') || lpad(v_minute ,2, '0') || lpad(v_second, 2, '0') || '00';
exception when others then
  return '00000000';
end func_formate_time;
/


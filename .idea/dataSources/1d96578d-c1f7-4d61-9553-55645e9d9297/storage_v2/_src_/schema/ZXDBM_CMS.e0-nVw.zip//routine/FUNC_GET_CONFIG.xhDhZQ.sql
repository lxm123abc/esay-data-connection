create function           func_get_config
(
  i_config_type in  number,
  i_number_value in number
) return
varchar2 is
  v_retstring  varchar2(255);
begin

  select varchar_value into v_retstring from imp_sh_cms_config
  where config_type = i_config_type and number_value = i_number_value and rownum = 1;
  return(v_retstring);
exception when others then
  return 'TV';
end func_get_config;
/


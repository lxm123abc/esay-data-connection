create function           func_path_exchange
(
  i_path   in  varchar2,
  i_type   in  number  --1-deviceid->windiskid;2-windiskid->deviceid
) return varchar2
is
  v_prepath  varchar2(256);
  v_postpath varchar2(256);
  v_path     varchar2(256);
begin
  --deviceid:=SAN1 , windiskid:=x:/
  v_prepath := substr(i_path, 1, instr(i_path, '/', 1, 1) -1 );  --SAN1 or x:
  v_postpath := substr(i_path, instr(i_path, '/', 1, 1) );       --/proc
  if i_type = 1 then
    select rtrim(windiskid, '/')||v_postpath into v_path from zxdbm_cms.cms_device_windiskid_bind where rtrim(deviceid, '/') = v_prepath;
  elsif i_type = 2 then
    select rtrim(deviceid, '/')||v_postpath into v_path from zxdbm_cms.cms_device_windiskid_bind where rtrim(windiskid, '/') = v_prepath;
  end if;

  --SAN1 or x:
  return v_path;
exception when others then
  v_path:=sqlerrm;
  v_postpath := substr(i_path, instr(i_path, '/', 1, 1) );
  if i_type = 1 then
    v_path := 'x:'||v_postpath;
  elsif i_type = 2 then
    v_path := 'SAN1'||v_postpath;
  end if;
  return v_path;
end func_path_exchange;
/


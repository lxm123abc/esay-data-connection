create function           func_status
(
	i_platformindex		number
)
return status_table
is
	type type_arr is table of zxdbm_cms.cnt_target_sync%rowtype index by binary_integer;
	v_array			type_arr;
	v_status		status_type;
	v_status_arr	status_table;
begin
	v_status_arr := status_table();
	select * bulk collect into v_array from zxdbm_cms.cnt_target_sync where relateindex = i_platformindex;
	for i in 1..v_array.count loop
		v_status := status_type(v_array(i).operresult, v_array(i).status);
		-- 扩展
		v_status_arr.extend;
		v_status_arr(i) := v_status;
	end loop;
	return v_status_arr;
end func_status;
/


create function           get_platform_status
(
	i_status_arr	status_table
)
return number
is
	v_plat_status	number(3,0);
	p				number(3,0);
begin
	v_plat_status := -1;
	p	:= 5;

	for i in 1..i_status_arr.count loop
		if i_status_arr(i).status = 0 then
			v_plat_status := i_status_arr(i).status;
			exit;
		elsif i_status_arr(i).status = 400 then
			v_plat_status := i_status_arr(i).status;
			p := 1;
		elsif i_status_arr(i).status = 500 then
			if p > 2 then
				v_plat_status := i_status_arr(i).status;
				p := 2;
			end if;
		elsif i_status_arr(i).status = 200 then
			if p > 3 then
				v_plat_status := i_status_arr(i).status;
				p := 3;
			end if;
		elsif i_status_arr(i).status = 300 then
			if p > 4 then
				v_plat_status := i_status_arr(i).status;
				p := 4;
			end if;
		end if;
	end loop;

	return v_plat_status;
end get_platform_status;
/


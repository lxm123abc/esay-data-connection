create function           get_target_status
(
	i_status_arr	status_table
)
return number
is
	v_target_status	number(3,0);
begin
	for i in 1..i_status_arr.count loop
		if i_status_arr(i).operresult in (0, 80) then
			v_target_status := 0;
			exit;
		elsif i_status_arr(i).operresult in (10, 40, 70) then
			v_target_status := 200;
			exit;
		elsif i_status_arr(i).operresult in (20, 50, 90) then
			v_target_status := 300;
			exit;
		elsif i_status_arr(i).operresult = 30 then
			v_target_status := 400;
			exit;
		elsif i_status_arr(i).operresult = 60 then
			v_target_status := 500;
			exit;
		end if;
	end loop;

	return v_target_status;
end get_target_status;
/


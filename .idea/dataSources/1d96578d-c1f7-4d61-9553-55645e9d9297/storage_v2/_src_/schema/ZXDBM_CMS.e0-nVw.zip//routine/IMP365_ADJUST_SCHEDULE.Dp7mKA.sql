create procedure           imp365_adjust_schedule
(
	i_objid		in	varchar2,
	o_retcode	out	number,
	o_retdesc	out	varchar2
)
as
	type t_arr_schedule_table is table of zxdbm_cms.cms_schedule%rowtype;
	v_arr_sche_table	t_arr_schedule_table;
	v_start			varchar2(20);	-- 节目开始时间	yyyymmddhh24miss
	v_end			varchar2(20);	-- 节目结束时间
	v_startdate		zxdbm_cms.cms_schedule.startdate%TYPE;
	v_starttime		zxdbm_cms.cms_schedule.starttime%TYPE;	-- 开始时间
	v_duration		zxdbm_cms.cms_schedule.duration%TYPE;	-- 时长
	v_channelid		zxdbm_cms.cms_schedule.channelid%TYPE;
	v_tmp_start		varchar2(20);
	v_tmp_end		varchar2(20);
begin
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_start     := '';
	v_end       := '';
	v_startdate := '';
	v_starttime := '';
	v_duration  := '';
	v_channelid	:= '';
	v_tmp_start	:= '';
	v_tmp_end	:= '';

	begin
		-- 查看是否schedule存在
		select channelid, startdate, starttime, duration
		into v_channelid, v_startdate, v_starttime, v_duration
		from zxdbm_cms.cms_schedule where scheduleid = i_objid and rownum = 1;
	exception
		when no_data_found then
		o_retcode	:= 51;
		o_retdesc	:= 'error: no schedule - ' || i_objid ;
		return;
	end;

	-- 计算节目单开始及结束时间
	v_start := v_startdate || v_starttime;
	v_end	:= to_char(to_date(v_start, 'yyyymmddhh24miss') +
					to_number(substr(v_duration, 0, 2))/24 +
					to_number(substr(v_duration, 3, 2))/(24*60) +
					to_number(substr(v_duration, 5, 2))/(24*60*60), 'yyyymmddhh24miss');

	-- 查找同一频道下的节目单
	select * bulk collect into v_arr_sche_table from zxdbm_cms.cms_schedule
		where channelid = v_channelid and scheduleid <> i_objid;

	if v_arr_sche_table.count = 0 then
		o_retcode := 0;
		o_retdesc := 'no overlap schedule';
		return;
	end if;

	-- 删除重叠schedule 及对应的schedulerecord
	for i in 1..v_arr_sche_table.count loop
		v_tmp_start := v_arr_sche_table(i).startdate || v_arr_sche_table(i).starttime;
		v_tmp_end	:= to_char(to_date(v_tmp_start, 'yyyymmddhh24miss') +
				to_number(substr(v_arr_sche_table(i).duration, 0, 2))/24 +
				to_number(substr(v_arr_sche_table(i).duration, 3, 2))/(24*60) +
				to_number(substr(v_arr_sche_table(i).duration, 5, 2))/(24*60*60), 'yyyymmddhh24miss');

		if (v_start <= v_tmp_start and v_tmp_start < v_end)
			or (v_start < v_tmp_end and v_tmp_end <= v_end) then
			delete zxdbm_cms.cms_schedule where scheduleindex = v_arr_sche_table(i).scheduleindex;
			delete zxdbm_cms.cms_schedulerecord where scheduleid = v_arr_sche_table(i).scheduleid;
			-- 删除buf记录及审核历史记录
			delete zxdbm_cms.cms_schedule_wkfwhis where scheduleindex=v_arr_sche_table(i).scheduleindex;
			delete zxdbm_cms.cms_schedule_buf where scheduleindex=v_arr_sche_table(i).scheduleindex;
			-- 删除发布数据
			delete zxdbm_cms.cnt_platform_sync
			where objectid=v_arr_sche_table(i).scheduleid and objecttype=6;
			delete zxdbm_cms.cnt_target_sync
			where objectid=v_arr_sche_table(i).scheduleid and objecttype=6;
		end if;
	end loop;


exception
	when others then
		o_retcode := 99;
		o_retdesc := 'error, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		return;
end imp365_adjust_schedule;
/


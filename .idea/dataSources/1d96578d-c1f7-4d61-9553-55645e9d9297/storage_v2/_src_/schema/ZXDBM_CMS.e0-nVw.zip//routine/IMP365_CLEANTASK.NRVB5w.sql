create procedure           imp365_cleantask
(
	i_timeout	in	number,
    o_retcode	out number,
    o_retdesc	out varchar2
)
as
    v_nowtime	varchar2(14);
    v_expire_time varchar2(14);
	v_retcode	number(10,0);
	v_retdesc	varchar2(256);
	v_count		number(10,0);
begin
    v_nowtime := to_char(sysdate, 'yyyymmddhh24miss');
    v_retcode := 0;
	v_retdesc := 'success';
	v_count	:= 0;

    -- ftp 任务表，超过i_timeout分钟的任务，认为已经超时
    for m in (select taskindex, to_date(starttime, 'yyyymmddhh24miss'), correlateid, impcode, srcfileurl
    			from imp365_ftp_task where status = 2
    			and trunc((sysdate-to_date(starttime, 'yyyymmddhh24miss'))*24*60,0) > i_timeout) loop
		v_count := v_count +1;
		if v_count >= 50 then
			exit;
		end if;

    	update imp365_ftp_task set status = 4, result = 1000,
    		description = 'longer time to ftp xml file', endtime = v_nowtime
    	where taskindex = m.taskindex;

    	zxdbm_cms.imp365_update_taskdetail(m.correlateid,1000, 'longer time to ftp xml file',
    										m.srcfileurl, o_retcode, o_retdesc);
		if o_retcode <> 0 then
			v_retcode := o_retcode;
			v_retdesc := o_retdesc;
		end if;
    end loop;

    v_count := 0;
    -- 同步任务表，超过i_timeout分钟的任务，认为已经超时
    for m in (select taskindex, correlateid, resultfileurl
			from zxdbm_cms.cnt_sync_task where status = 2 and
			trunc((sysdate-to_date(starttime, 'yyyymmddhh24miss'))*24*60,0) > i_timeout) loop
		v_count := v_count +1;
		if v_count >= 50 then
			exit;
		end if;

		zxdbm_cms.imp365_update_taskdetail(m.correlateid, 1000, 'longer time for status = 2', m.resultfileurl, o_retcode, o_retdesc);
		if o_retcode <> 0 then
			v_retcode := o_retcode;
			v_retdesc := o_retdesc;
		end if;
	end loop;

	-- 清理过期任务
	v_expire_time := to_char(sysdate-30,'yyyymmddhh24miss');

	-- imp_epg_task_info
	delete imp365_ftp_task where starttime < v_expire_time;
	commit;

    o_retcode := 0;
    o_retdesc := v_retcode || ',' || v_retdesc;
    return;

exception
	when others then
        o_retcode := sqlcode;
        o_retdesc := substr(sqlerrm, 1, 80);
        rollback;
        return;
end imp365_cleantask;
/


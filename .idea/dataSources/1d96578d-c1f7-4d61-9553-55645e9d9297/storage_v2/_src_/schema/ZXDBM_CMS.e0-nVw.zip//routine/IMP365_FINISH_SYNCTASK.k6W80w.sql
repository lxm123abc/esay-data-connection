create procedure           imp365_finish_synctask
(
	i_correlateid	in		varchar2,	-- 任务流水号
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	i_reusltfileurl	in		varchar2,	-- 结果reply文件地址
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
--	pragma autonomous_transaction;  -- 自治事务 外无法操作内
	v_nowtime		varchar2(14);
	v_taskindex		number(10, 0);
	v_batchid		number(10, 0);
	v_wg_taskindex	number(10, 0);
	v_count			number(10, 0);
	v_destindex		zxdbm_cms.targetsystem.targetindex%TYPE;
	v_platform		zxdbm_cms.targetsystem.platform%TYPE;
	v_targettype	zxdbm_cms.targetsystem.targettype%TYPE;
	v_actiontype	number(3,0);
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间
	v_taskindex	:= 0;
	v_batchid	:= 0;
	v_wg_taskindex	:= 0;
	v_count		:= 0;
	v_actiontype:= 1;  -- 默认为 1-regist or update 3-delete

	update zxdbm_cms.cnt_sync_task
	set status = decode(i_result, 0, 3, 4), resultcode = i_result, resultdesc = i_desc,
		resultfileurl = i_reusltfileurl, starttime = nvl(starttime, v_nowtime), endtime = v_nowtime
	where correlateid = i_correlateid
	returning taskindex,batchid,wg_taskindex,destindex
	into v_taskindex,v_batchid,v_wg_taskindex,v_destindex;
	if sql%rowcount = 0 then
--        rollback;
        o_retcode	:= 201;
		o_retdesc	:= 'not exists cnt_sync_task record - correlateid [' || i_correlateid || ']';
		return;
	end if;

	-- 迁移任务到历史表
	insert into zxdbm_cms.cnt_sync_task_his
	select * from zxdbm_cms.cnt_sync_task where taskindex = v_taskindex;
	delete zxdbm_cms.cnt_sync_task where taskindex = v_taskindex;

	-- 查询任务网元类型及平台类型
	-- 平台类型：1-2.0平台，2-3.0平台
	-- 目标系统类型：0-2.0能力平台（文广接口），10-2.0能力平台（央视接口），1-BMS，2-EPG，3-CDN
	select platform,targettype into v_platform,v_targettype
	from zxdbm_cms.targetsystem where targetindex=v_destindex;

	-- 更新同批次任务及上游任务
	if i_result=0 then
		-- 任务成功
		select count(*) into v_count from zxdbm_cms.cnt_sync_task where batchid=v_batchid;
		if v_count=0 then
			-- 同批次任务结束 更新上游任务
		    if v_wg_taskindex is not null and v_wg_taskindex<>0 then
			    update zxdbm_cms.imp_cms_synctask
			    set result_20=decode(v_platform,1,0,result_20),
			        result_30=decode(v_platform,2,0,result_30),
			        replyfileurl_20=decode(v_platform,1,i_reusltfileurl,replyfileurl_20),
			        replyfileurl_30=decode(v_platform,2,i_reusltfileurl,replyfileurl_30)
			    where taskindex=v_wg_taskindex;

			    if sql%rowcount=0 then
			    	-- 对应上游任务不存在
			    	o_retcode	:= 0;
					o_retdesc	:= 'not exists imp_cms_synctask record:wg_taskindex['|| v_wg_taskindex ||']';
					update zxdbm_cms.cnt_sync_task_his
					set description=o_retdesc
					where taskindex=v_taskindex and rownum=1;
			    end if;
			end if;
		else
			-- 同批次任务没有结束 更新下一条任务为待执行
			-- 任务状态 1-新增 2-修改 3-删除
			for n in (select actiontype from zxdbm_cms.object_sync_record where taskindex=v_taskindex)
			loop
				if n.actiontype=3 then
					v_actiontype:=3;
					exit;
				end if;
			end loop;

			if v_actiontype=1 then
				-- regist or update sequence: 3:cdn->1:bms->2:epg
				update zxdbm_cms.cnt_sync_task a
				set a.status=1
				where a.batchid=v_batchid and a.status=0 and exists
				(select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=3);

				if sql%rowcount=0 then
				  update zxdbm_cms.cnt_sync_task a
				  set a.status=1
				  where a.batchid=v_batchid and a.status=0 and exists
				  (select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=1);

				  if sql%rowcount=0 then
					update zxdbm_cms.cnt_sync_task a
				    set a.status=1
				    where a.batchid=v_batchid and a.status=0 and exists
				    (select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=2);
				  end if;
				end if;
			else
				-- delete sequence: 2:epg->1:bms->3:cdn
				update zxdbm_cms.cnt_sync_task a
				set a.status=1
				where a.batchid=v_batchid and a.status=0 and exists
				(select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=2);

				if sql%rowcount=0 then
				  update zxdbm_cms.cnt_sync_task a
				  set a.status=1
				  where a.batchid=v_batchid and a.status=0 and exists
				  (select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=1);

				  if sql%rowcount=0 then
					update zxdbm_cms.cnt_sync_task a
				    set a.status=1
				    where a.batchid=v_batchid and a.status=0 and exists
				    (select * from zxdbm_cms.targetsystem b where a.destindex=b.targetindex and b.targettype=3);
				  end if;
				end if;
			end if; -- 同批次任务没结束
			goto label1;
		end if;
	else
		-- 任务失败 更新上游任务为失败结束
		if v_wg_taskindex is not null and v_wg_taskindex<>0 then
			-- 20140401 lxp 将具体错误描述信息填写至上游工单
			update zxdbm_cms.imp_cms_synctask
			set result_20=decode(v_platform,1,-2,result_20),
			    result_30=decode(v_platform,2,-3,result_30),
			    replyfileurl_20=decode(v_platform,1,i_reusltfileurl,replyfileurl_20),
			    replyfileurl_30=decode(v_platform,2,i_reusltfileurl,replyfileurl_30),
			    description=description||' '||
			      decode(v_platform,2,'3.0 '||decode(v_targettype,1,'BMS',2,'EPG',3,'CDN','UNKNOW')
			      ,1, '2.0')||' publish failed.'||substr(i_desc,0,255)
			where taskindex=v_wg_taskindex;

			if sql%rowcount=0 then
				-- 对应上游任务不存在
				o_retcode	:= 0;
				o_retdesc	:= 'not exists imp_cms_synctask record - taskindex['|| v_wg_taskindex ||']';
				update zxdbm_cms.cnt_sync_task_his
				set description=o_retdesc
				where taskindex=v_taskindex and rownum=1;
			end if;
		end if;

		-- 同批次任务 更新对应的发布状态 迁移历史表
		for t in (select taskindex from zxdbm_cms.cnt_sync_task where batchid=v_batchid)
		loop
			-- 任务迁移历史表
			update zxdbm_cms.cnt_sync_task
			set resultdesc='error:'||decode(v_targettype,1,'BMS',2,'EPG',3,'CDN','UNKNOW')||' publish fail'
			where taskindex = t.taskindex;
			insert into zxdbm_cms.cnt_sync_task_his
			select * from zxdbm_cms.cnt_sync_task where taskindex = t.taskindex;
			delete zxdbm_cms.cnt_sync_task where taskindex = t.taskindex;

			-- 更新对应的发布状态
			for s in (select objectid, objecttype, actiontype, destindex, parentid
			          from zxdbm_cms.object_sync_record where taskindex=t.taskindex)
			loop
				zxdbm_cms.imp365_update_objstatus(
				s.objectid,s.objecttype,s.parentid,s.actiontype,s.destindex,i_result,o_retcode,o_retdesc);
				if o_retcode <> 0 then
					rollback;
					return;
				end if;
			end loop;
		end loop;
	end if;

	-- 20131022 Liuxp 更新上游对象日志信息
	-- 有对应关系的 object
	update zxdbm_cms.object_cpcnt_record b
    set (retcode_20,retdesc_20,retcode_30,retdesc_30)=
    (
    select decode(v_platform,1,nvl(ret1,i_result),retcode_20),
    decode(v_platform,1,substr('2.0:'||nvl(ret1,i_result)||'-'||decode(desc1,null,i_desc,desc1),0,1024),retdesc_20),
    decode(v_platform,2,nvl(ret1,i_result),retcode_30),
    decode(v_targettype,1,'3.0 BMS:',2,'3.0 EPG:',3,'3.0 CDN:','3.0 UNKNOW:')
    ||decode(v_platform,2,substr(nvl(ret1,i_result)||'-'||decode(desc1,null,i_desc,desc1),0,1024),retdesc_30)
    from
    (
    select a.resultcode ret1,a.resultdesc desc1,c.objectcode objcode,c.objecttype objtype
    from zxdbm_cms.object_sync_record a,zxdbm_cms.object_cpcnt_record c
    where a.objecttype=c.objecttype and a.objectcode=c.objectcode
    and c.taskindex=v_wg_taskindex and a.taskindex=v_taskindex
    order by a.starttime desc
    )
    where objtype=b.objecttype and objcode=b.objectcode
    and rownum=1
    )
    where b.taskindex=v_wg_taskindex and exists
    (select * from zxdbm_cms.object_sync_record d
    where d.taskindex=v_taskindex
    and d.objecttype=b.objecttype and d.objectcode=b.objectcode);

    -- 有对应关系的 mapping
    update zxdbm_cms.object_cpcnt_record b
    set (retcode_20,retdesc_20,retcode_30,retdesc_30)=
    (
    select decode(v_platform,1,nvl(ret1,i_result),retcode_20),
    decode(v_platform,1,substr('2.0:'||nvl(ret1,i_result)||'-'||decode(desc1,null,i_desc,desc1),0,1024),retdesc_20),
    decode(v_platform,2,nvl(ret1,i_result),retcode_30),
    decode(v_targettype,1,'3.0 BMS:',2,'3.0 EPG:',3,'3.0 CDN:','3.0 UNKNOW:')
    ||decode(v_platform,2,substr(nvl(ret1,i_result)||'-'||decode(desc1,null,i_desc,desc1),0,1024),retdesc_30)
    from
    (
    select a.resultcode ret1,a.resultdesc desc1,c.objectcode objcode,c.objecttype objtype,a.parentcode pobjcode
    from zxdbm_cms.object_sync_record a,zxdbm_cms.object_cpcnt_record c
    where a.objecttype=c.objecttype and a.elementcode=c.objectcode and a.parentcode=c.parentcode
    and c.taskindex=v_wg_taskindex and a.taskindex=v_taskindex
    order by a.starttime desc
    )
    where objtype=b.objecttype and objcode=b.objectcode and pobjcode=b.parentcode
    and rownum=1
    )
    where b.taskindex=v_wg_taskindex and exists
    (select * from zxdbm_cms.object_sync_record d
    where d.taskindex=v_taskindex
    and d.objecttype=b.objecttype and d.elementcode=b.objectcode and d.parentcode=b.parentcode);

    -- 没有对应关系的 object
    update zxdbm_cms.object_cpcnt_record b
    set
    retcode_20=decode(v_platform,1,i_result,retcode_20),
    retdesc_20=decode(v_platform,1,decode(i_result,0,'2.0:success','2.0:'||'error-'||' publish fail'),retdesc_20),
    retcode_30=decode(v_platform,2,i_result,retcode_30),
    retdesc_30=decode(v_platform,2,decode(i_result,0,'3.0:success',
        '3.0:'||'error-'||decode(v_targettype,1,'BMS',2,'EPG',3,'CDN','UNKNOW')||' publish fail'),retdesc_30)
    where b.taskindex=v_wg_taskindex and b.objecttype<20 and not exists
    (
    select * from zxdbm_cms.object_sync_record a
    where a.taskindex=v_taskindex and a.objecttype=b.objecttype
    and a.objectcode=b.objectcode
    );

    -- 没有对应关系的 mapping
    update zxdbm_cms.object_cpcnt_record b
    set
    retcode_20=decode(v_platform,1,i_result,retcode_20),
    retdesc_20=decode(v_platform,1,decode(i_result,0,'2.0:success','2.0:'||'error-'||' publish fail'),retdesc_20),
    retcode_30=decode(v_platform,2,i_result,retcode_30),
    retdesc_30=decode(v_platform,2,decode(i_result,0,'3.0:success',
        '3.0:'||'error-'||decode(v_targettype,1,'BMS',2,'EPG',3,'CDN','UNKNOW')||' publish fail'),retdesc_30)
    where b.taskindex=v_wg_taskindex and b.objecttype>=20 and not exists
    (
    select * from zxdbm_cms.object_sync_record a
    where a.taskindex=v_taskindex and a.objecttype=b.objecttype
    and a.elementcode=b.objectcode and a.parentcode=b.parentcode
    );

	<<label1>>
      null;

	commit;
exception
	when others then
		o_retcode	:= 202;
		o_retdesc	:= 'error: sqlcode[' || sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
		rollback;
		return;
end imp365_finish_synctask;
/


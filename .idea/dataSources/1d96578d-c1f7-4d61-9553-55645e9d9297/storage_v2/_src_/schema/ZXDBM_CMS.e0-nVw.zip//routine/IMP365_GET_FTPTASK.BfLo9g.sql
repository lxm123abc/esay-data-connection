create procedure           imp365_get_ftptask
(
	i_impcode		in		varchar2,		-- 接口机服务器编码
	o_retcode		out		number,			-- 结果码
	o_retdesc		out		varchar2		-- 结果描述
)
as
	v_nowtime	varchar(14);
	v_taskindex		number(10,0);			-- 任务索引号
	v_srcfileurl	varchar2(1024);			-- tasktype =1:xml文件ftp地址 =2:实体文件源路径
	v_destfileurl	varchar2(256);			-- tasktype =1:xml文件本地路径 =2:实体文件目标路径
	v_tasktype		number(3,0);			-- ftp任务类型 1-ftp下载 2-mv
	v_lsptype		number(3,0);			-- lsp类型 用于区分reply格式
	v_lspid			varchar2(32);			-- lspid
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_taskindex	:= 0;
	v_srcfileurl := '';
	v_destfileurl:= '';
	v_tasktype	:= 0;
	v_lsptype	:= 0;
	v_lspid		:= '';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');

	begin
		-- 查看ftp任务是否存在
		select taskindex, srcfileurl, destfileurl, tasktype, lsptype, lspid
		into v_taskindex, v_srcfileurl, v_destfileurl, v_tasktype, v_lsptype, v_lspid from(
		select taskindex, srcfileurl, destfileurl, tasktype, lsptype, lspid from zxdbm_cms.imp365_ftp_task
		where impcode = i_impcode and status = 1 order by taskindex) where rownum = 1;
	exception
		when no_data_found then
			o_retcode	:= 431;
			o_retdesc	:= 'no ftp_task to deal';
			return;
	end;

	-- 更新ftp任务为执行中
	begin
		update zxdbm_cms.imp365_ftp_task
		set status = 2, starttime = v_nowtime
		where taskindex = v_taskindex;
	exception
		when others then
			o_retcode	:= 432;
			o_retdesc	:= 'update ftp_task to excuting error,taskindex:' || v_taskindex;
			rollback;
			return;
	end;

	o_retdesc := v_taskindex||'&'||v_srcfileurl||'&'||v_destfileurl||'&'||
				v_tasktype||'&'||v_lsptype||'&'||v_lspid;
	commit;
exception
	when others then
		o_retcode	:= 450;
		o_retdesc	:= 'unkown exception, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		return;

end imp365_get_ftptask;
/


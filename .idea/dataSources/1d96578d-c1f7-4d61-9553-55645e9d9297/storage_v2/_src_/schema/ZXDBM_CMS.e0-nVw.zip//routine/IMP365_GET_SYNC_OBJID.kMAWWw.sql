create function           imp365_get_sync_objid
(
	i_objid		varchar2,
	i_objtype	number,
	i_parentid	varchar2
)
return varchar2
is
	v_objid		varchar2(128);
begin
	v_objid := '-1';
	-- 1:service 2:category 3:program 4:series 5:channel 6:schedule (7:movie 8:physicalchannel)
	-- (9:schedulerecord) (10:picture) 11:cast 12:castrolemap
	-- 21:Service-program 22:Service-series 23:Service-channel 24:Service-schedual
	-- {25:Service-picture} 26:Category-program 27:Category-series 28:Category-channel
	-- '29:Category-schedual 30:Category-service' {31:Category-picture} 32:Program-movie
	-- '33:Program-schedualrecord' 34:Program-castrolemap {35:Program-picture} 36:Series-programe
	-- 37:Series-castrolemap {38:Series-picture 39:Channel-picture} 【40:Schedual-schedualrecord】
	-- {41:Cast-picture}
	-- (7,8,9,10)不记录对象发布状态 '/*29,30,33*/' 暂不支持 {}picture的mapping--记录发布状态
	if i_objtype in (1,2,3,4,5,6,11,12,21,22,23,24,26,27,28,25,31,/*29,30,33,*/34,35,36,37,38,39,41) then
		v_objid := i_objid;
		return v_objid;
	-- mapping 返回parentid
	elsif i_objtype in (32,40) then
		v_objid := i_parentid;
	elsif i_objtype = 7 then
		select programid into v_objid from zxdbm_cms.cms_movie where movieid = i_objid;
	elsif i_objtype = 8 then
		select channelid into v_objid from zxdbm_cms.physicalchannel where physicalchannelid = i_objid;
	elsif i_objtype = 9 then
		select scheduleid into v_objid from zxdbm_cms.cms_schedulerecord where schedulerecordid = i_objid;
--	elsif i_objtype = 10 then
--		select objectid into v_objid from zxdbm_cms.cnt_target_sync where parentid = i_objid and rownum = 1;
	end if;

	return v_objid;

exception
	when others then
		v_objid := '-1';
		return v_objid;
end imp365_get_sync_objid;
/


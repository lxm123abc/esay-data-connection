create procedure           imp365_init_taskstatus
(
	o_retcode		out 	number,
	o_retdesc		out		varchar2
)
as
begin
	o_retcode := 0;
	o_retdesc := 'success';

--	update zxdbm_cms.imp365_ftp_task set status = 1, starttime = '' where status = 2;
	delete from zxdbm_cms.imp365_ftp_task where status = 2;
	update zxdbm_cms.cnt_sync_task set status = 1, starttime = '' where status = 2;
	commit;

exception
	when others then
	o_retcode := 0;
	o_retdesc := 'init task error, sqlcode:' || sqlcode || ' sqlerrm:' || substr(sqlerrm, 0, 80);
	rollback;
	return;
end imp365_init_taskstatus;
/


create procedure           imp365_update_loginfo
(
	i_syncindex		in		number, 	-- 记录索引
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
	v_nowtime		varchar2(14);
	v_objid			zxdbm_cms.object_sync_record.objectid%TYPE;
	v_objtype		zxdbm_cms.object_sync_record.objecttype%TYPE;
	v_opertype		zxdbm_cms.object_sync_record.actiontype%TYPE;
	v_destindex		zxdbm_cms.object_sync_record.destindex%TYPE;
	v_parentid		zxdbm_cms.object_sync_record.parentid%TYPE;
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_objid		:= '';
	v_objtype	:= '';
	v_opertype	:= 0;
	v_destindex := 0;
	v_parentid	:= '';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间

	-- 更新对象日志记录
	update zxdbm_cms.object_sync_record
	set resultcode = i_result, resultdesc = i_desc,
		starttime = nvl(starttime, v_nowtime), endtime = v_nowtime
	where syncindex = i_syncindex
	returning objectid, objecttype, actiontype, destindex, parentid
	into v_objid, v_objtype, v_opertype, v_destindex, v_parentid;

	--not exist
    if sql%rowcount = 0 then
      o_retcode := 151;
	  o_retdesc := 'not exist object_sync_record - syncindex['||i_syncindex||']';
      return;
    end if;

	-- 更新对象发布状态
	zxdbm_cms.imp365_update_objstatus(
			v_objid, v_objtype, v_parentid, v_opertype,
			v_destindex, i_result, o_retcode, o_retdesc);
	if o_retcode <> 0 then
--		rollback;	-- 最外一层 主调函数 回滚
		return;
	end if;

--	commit;

exception
	when others then
		o_retcode := 199;
		o_retdesc := 'unkown error, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		return;

end imp365_update_loginfo;
/


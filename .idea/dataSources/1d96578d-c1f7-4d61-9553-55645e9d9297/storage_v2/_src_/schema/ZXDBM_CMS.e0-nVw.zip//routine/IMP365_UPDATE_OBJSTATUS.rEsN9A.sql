create procedure           imp365_update_objstatus
(
	i_objid		in		varchar2,		-- CMS 对象唯一ID
	i_objtype	in		number,			-- 对象类型-对应日志表中的对象类型
	i_parentid	in		varchar2,		--
	i_opertype	in		number,			-- 对象操作类型 1：regist 2：update 3：delete
	i_destindex	in		number,			-- 目标系统index
	i_result	in		number,			-- 操作结果
	o_retcode	out		number,			-- 结果码
	o_retdesc	out		varchar2		-- 结果描述
)
as
	v_curoperresult number(3,0);
	v_curstatus		number(3,0);
	v_objtype		number(3,0);
	v_status		number(3,0);
	v_operresult	number(3,0);
	v_platformindex	number(10,0);
	v_plat_status	number(3,0);
	v_nowtime		varchar2(14);
	v_status_arr	status_table;
	v_tmp_result	number(3,0);
	v_movietype		number(3,0);
	v_sync_objid	zxdbm_cms.object_sync_record.objectid%TYPE;
	type target_sync_type is table of zxdbm_cms.cnt_target_sync.syncindex%TYPE index by binary_integer;
	v_targetsync	target_sync_type;
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_curstatus		:= 0;
	v_objtype		:= 0;
	v_status		:= 0;
	v_operresult	:= 0;
	v_platformindex	:= 0;
	v_plat_status	:= 0;
	v_nowtime		:= to_char(sysdate, 'yyyymmddhh24miss');
	v_movietype		:= -1;

	-- 获取具有发布状态的对象id <20130314 若对象的发布状态不存在，则把对象的日志和任务结束>
	v_sync_objid := zxdbm_cms.imp365_get_sync_objid(i_objid, i_objtype, i_parentid);
	if v_sync_objid = '-1' then
	    o_retcode := 0;
	    o_retdesc := 'warn: not exist cnt_target_sync - objtype:'||i_objtype;
		return;
	end if;

	-- 如果是movie正片删除成功，则更新program状态为待发布，预览片删除，则更新为发布成功
	if i_objtype = 7 then
		select movietype into v_movietype from zxdbm_cms.cms_movie where movieid = i_objid;
	end if;

	-- 操作类型映射同步结果，进而映射发布状态
	-- 发布状态：0-待发布 200-发布中 300-发布成功 400-发布失败 500-修改发布失败 600-预下线
	-- 同步结果：0-待发布 10-新增同步中 20-新增同步成功 30-新增同步失败 40-修改同步中
	-- 50-修改同步成功 60-修改同步失败 70-取消同步中 80-取消同步成功 90-取消同步失败
	if i_result = 0 then -- succ
		if i_opertype = 1 then
			v_operresult := 20;
			v_status	 := 300;
		elsif i_opertype = 2 then
			v_operresult := 50;
			v_status	 := 300;
		else
		    if v_movietype = 0 then
		        v_operresult := 50;
				v_status	 := 300;
		    else
		    	v_operresult := 80;
			    v_status	 := 0;
			end if;
		end if;
	else
		if i_opertype = 1 then
			v_operresult := 30;
			v_status	 := 400;
		elsif i_opertype = 2 then
			v_operresult := 60;
			v_status	 := 500;
		else
			v_operresult := 90;
			v_status	 := 300;
		end if;
	end if;

	begin
		-- 检查是否存在发布记录
		select objecttype, relateindex, operresult, status
		into v_objtype, v_platformindex, v_curoperresult, v_curstatus
		from zxdbm_cms.cnt_target_sync
		where objectid = v_sync_objid and targetindex = i_destindex;
	exception
		when no_data_found then
		o_retcode	:= 0;
		o_retdesc	:= 'warn: not exist cnt_target_sync record, objectid-'
						|| v_sync_objid||',targetindex-'||i_destindex;
		return;
	end;

	-- <20130322 add lxp: 加锁> (考虑性能??)
	select syncindex bulk collect into v_targetsync
	from zxdbm_cms.cnt_target_sync
	where relateindex = v_platformindex for update;

	v_tmp_result := 500;
	-- 更新对象网元状态
	update zxdbm_cms.cnt_target_sync set operresult = v_operresult, status = v_status,
	publishtime = decode(v_status, 300, v_nowtime, publishtime),
	cancelpubtime = decode(i_opertype, 3, decode(v_status, 0, v_nowtime, ''), '')
	where objectid = v_sync_objid and targetindex = i_destindex;

	v_tmp_result := 501;
	-- 获取网元状态
	v_status_arr := zxdbm_cms.func_status(v_platformindex);

	v_tmp_result := 502;
	-- 调用映射平台发布状态规则函数
	v_plat_status := zxdbm_cms.get_platform_status(v_status_arr);
	if v_plat_status = -1 then
		o_retcode	:= 101;
		o_retdesc	:= 'error: get platform status fail, objectid-'||i_objid||', platformindex-'||v_platformindex;
		return;
	end if;
	v_tmp_result := 503;

	-- 更新平台发布状态 ("网元"发布成功的 更新平台发布时间 "平台"取消发布成功的 更新取消发布时间)

	update zxdbm_cms.cnt_platform_sync set status = v_plat_status,
    publishtime = decode(v_status, 300, v_nowtime, publishtime),
	cancelpubtime = decode(i_opertype, 3, decode(v_plat_status, 0, v_nowtime, ''), '')
	where syncindex = v_platformindex;
	-- not exist
	if sql%rowcount = 0 then
		o_retcode	:= 102;
		o_retdesc	:= 'error: update platform status fail, objectid[' || i_objid || '], platformindex[' ||
		v_platformindex || '], sqlcode:' || sqlcode || 'sqlerrm:' || substr(sqlerrm, 0, 64);
		return;
	end if;

	v_tmp_result := 504;
	-- scheduleB修改时 与scheduleA时间冲突 scheduleA已发布 删除scheduleA
	if v_objtype = 6 and v_plat_status = 300 and i_opertype = 2 then
		zxdbm_cms.imp365_adjust_schedule(v_sync_objid, o_retcode, o_retdesc);
		if o_retcode <> 0 then
			return;
		end if;
	end if;

	o_retdesc := o_retdesc;

exception
	when others then
		o_retcode := 149;
		o_retdesc := v_tmp_result || 'error: sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		return;
end imp365_update_objstatus;
/


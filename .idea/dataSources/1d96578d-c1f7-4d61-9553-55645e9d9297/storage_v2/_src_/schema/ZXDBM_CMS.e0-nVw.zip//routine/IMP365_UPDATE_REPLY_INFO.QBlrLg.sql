create procedure           imp365_update_reply_info
(
	i_taskindex		in		number,			-- 任务索引号
	i_objid			in		varchar2,		-- 对象id -- 3.0
	i_elemcode		in		varchar2,		-- 对象类型为 mapping时 子对象的code 非mapping时 2.0对象code
	i_elemtype		in		varchar2,		-- 对象类型为 mapping时 子对象的type 非mapping时 2.0对象type
	i_parentcode	in		varchar2,		-- 对象类型为 mapping时 父对象的code
	i_parenttype	in		varchar2,		-- 对象类型为 mapping时 父对象的type
	i_resultcode	in		number,			-- 对象同步结果码
	i_description	in		varchar2,		-- 对象同步结果描述
	o_retcode		out		number,			-- 结果码
	o_retdesc		out		varchar2		-- 结果描述
)
as
	v_count			number(10,0);
	v_taskindex		number(10,0);
	v_syncindex		number(10,0);
	v_elemcode    varchar2(128);
	v_correlateid	zxdbm_cms.cnt_sync_task.correlateid%TYPE;
begin
	-- 初始化
	o_retcode		:= 0;
	o_retdesc		:= 'success';
	v_count			:= 0;
	v_taskindex		:= 0;
	v_syncindex		:= 0;

	-- 查看ftp任务是否存在
	select count(*) into v_count from zxdbm_cms.imp365_ftp_task where taskindex = i_taskindex and status = 2;
	if v_count = 0 then
		o_retcode	:= 451;
		o_retdesc	:= 'no ftptask[' || i_taskindex || '] in executing';
		return;
	end if;

	begin
		-- 更新
		select correlateid into v_correlateid from zxdbm_cms.imp365_ftp_task where taskindex = i_taskindex;
		select taskindex into v_taskindex from zxdbm_cms.cnt_sync_task
		where correlateid = v_correlateid;
	exception
		when no_data_found then
		o_retcode	:= 452;
		o_retdesc	:= 'no sync task exist, ftptask:' || i_taskindex || ' correlateid:' || v_correlateid;
		return;
	end;

	begin
		-- 3.0 object
		if i_objid is not null then
			select syncindex into v_syncindex from zxdbm_cms.object_sync_record
			where taskindex = v_taskindex and objectid = i_objid and resultcode is null and rownum = 1;
		-- 2.0 object
		elsif i_parentcode is null then
			select syncindex into v_syncindex from zxdbm_cms.object_sync_record
			where taskindex = v_taskindex and objectcode = i_elemcode and resultcode is null and rownum = 1;
		-- mapping
		else
			-- 将physicalchannel 转换为channel
			if upper(i_elemtype) = 'PHYSICALCHANNEL' then
				select a.cpcontentid into v_elemcode from zxdbm_cms.cms_channel a,zxdbm_cms.physicalchannel b
				where a.channelid = b.channelid and b.cpcontentid = i_elemcode and rownum = 1;
			else
				v_elemcode := i_elemcode;
			end if;

			select syncindex into v_syncindex from zxdbm_cms.object_sync_record
			where taskindex = v_taskindex and elementcode = v_elemcode and parentcode = i_parentcode
			 and resultcode is null and rownum = 1;
		end if;

	exception
		when no_data_found then
			o_retcode	:= 0;	-- 453 -> 0
			o_retdesc	:= 'no obj log info exist, objectid[' || i_objid || '] elemcode[' || i_elemcode ||
			'] elemtype[' || i_elemtype || '] parentcode[' || i_parentcode || '] parenttype[' || i_parenttype || ']';
			return;
	end;

	zxdbm_cms.imp365_update_loginfo(v_syncindex, i_resultcode, i_description, o_retcode, o_retdesc);
	if o_retcode <> 0 then
		rollback;
		return;
	end if;

	commit;
exception
	when others then
		o_retcode	:= 499;
		o_retdesc	:= 'unkown exception, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		return;
end imp365_update_reply_info;
/


create procedure           imp365_update_taskdetail
(
	i_correlateid	in		varchar2,	-- 任务流水号
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	i_reusltfileurl	in		varchar2,	-- 结果reply文件地址
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
	v_nowtime		varchar2(14);
	v_taskindex		number(10, 0);
	type t_index_type is record(syncindex zxdbm_cms.object_sync_record.syncindex%TYPE);
	type t_arr_index_table is table of t_index_type index by binary_integer;
	v_arr_index		t_arr_index_table;
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间
	v_taskindex	:= 0;

	begin
		-- 查看任务是否存在
		select taskindex into v_taskindex from zxdbm_cms.cnt_sync_task where correlateid = i_correlateid;
	exception
		when no_data_found then
		o_retcode	:= 205;
		o_retdesc	:= 'no task with correlateid [' || i_correlateid || ']';
		return;
	end;

	-- 更新任务信息
	zxdbm_cms.imp365_finish_synctask(i_correlateid, i_result, i_desc, i_reusltfileurl, o_retcode, o_retdesc);
	if o_retcode <> 0 then
		return;
	end if;

	-- 一个工单包含多个对象 循环更新(排除已处理过的对象日志记录？？)
	select syncindex bulk collect into v_arr_index from zxdbm_cms.object_sync_record
			where taskindex = v_taskindex and resultcode is null;
	if v_arr_index.count = 0 then
		o_retcode	:= 0;
		o_retdesc	:= 'no obj_sync record with taskindex:' || v_taskindex;
		return;
	end if;

	for m in 1..v_arr_index.count loop
		-- 调用更新对象日志记录表信息存储过程
		zxdbm_cms.imp365_update_loginfo(v_arr_index(m).syncindex, i_result, i_desc, o_retcode, o_retdesc);
		if o_retcode <> 0 then
			rollback;
			return;
		end if;
	end loop;

	o_retdesc := o_retdesc || ' correlateid:' || i_correlateid;
	commit;
exception
	when others then
		o_retcode	:= 210;
		o_retdesc	:= 'error: sqlcode[' || sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
		rollback;
		return;
end imp365_update_taskdetail;
/


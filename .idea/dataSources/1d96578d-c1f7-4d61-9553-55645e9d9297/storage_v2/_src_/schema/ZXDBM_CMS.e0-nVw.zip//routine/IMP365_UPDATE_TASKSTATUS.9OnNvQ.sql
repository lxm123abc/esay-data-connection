create procedure           imp365_update_taskstatus
(
	i_taskindex		in		number,		-- 任务索引
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
	v_nowtime		varchar2(14);
	v_correlateid	varchar2(20);
	v_targeturl		zxdbm_cms.targetsystem.msgurl%TYPE;	-- 目标系统url
	v_targetid		zxdbm_cms.targetsystem.targetid%TYPE;	-- 目标系统标识
	v_targettype	number(3,0);-- 目标系统类型
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_correlateid	:= '';
	v_targeturl	:= '';
	v_targetid	:= '';
	v_targettype:= -1;
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间

	-- 状态修改为执行中
	if (i_result = 2) then
		update zxdbm_cms.cnt_sync_task set status = i_result, starttime = v_nowtime
		where taskindex = i_taskindex;
		if sql%rowcount = 0 then
			o_retcode	:= 211;
			o_retdesc	:= 'update task status error, taskindex [' || i_taskindex || '] sqlcode['
						|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
			rollback;
			return;
		end if;
		-- 同时更新日志记录中的starttime <20130314 添加resultcode is null>
		update zxdbm_cms.object_sync_record set starttime = v_nowtime
		where taskindex = i_taskindex and resultcode is null;
--		if sql%rowcount = 0 then
--			o_retcode	:= 212;
--			o_retdesc	:= 'no log info with taskindex [' || i_taskindex || ']';
--			rollback;
--			return;
--		end if;

		-- 查询目标url
		begin
			select msgurl, targetid, targettype into v_targeturl, v_targetid, v_targettype
			from zxdbm_cms.targetsystem t
			where exists
			(select * from zxdbm_cms.cnt_sync_task c
			where c.taskindex = i_taskindex and t.targetindex=c.destindex);
		exception
			when no_data_found then
				o_retcode	:= 10000;
				o_retdesc	:= 'no target url&id found with taskindex[' || i_taskindex || ']';
				commit;	/* 无需回滚 直接提交 在代码中 url错误 任务失败结束 */
				return;
		end;
		o_retdesc := v_targeturl||'&'||v_targetid||'&'||v_targettype;
	-- 失败 状态修改
	else
		select correlateid into v_correlateid from zxdbm_cms.cnt_sync_task where taskindex = i_taskindex;

		-- 更新任务状态及信息
		zxdbm_cms.imp365_update_taskdetail(v_correlateid, i_result, i_desc, '', o_retcode, o_retdesc);
		if o_retcode <> 0 then
			return;
		end if;
	end if;

	commit;
exception
	when others then
		o_retcode	:= 219;
		o_retdesc	:= 'error: sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		return;
end imp365_update_taskstatus;
/


create procedure           imp369_cleantask
(
	i_timeout	in	number,
    o_retcode	out number,
    o_retdesc	out varchar2
)
as
    v_nowtime	varchar2(14);
    v_expire_time varchar2(14);
	v_retcode	number(10,0);
	v_retdesc	varchar2(256);
begin
    v_nowtime := to_char(sysdate, 'yyyymmddhh24miss');
    v_retcode := 0;
	v_retdesc := 'success';

    -- ftp 任务表，超过i_timeout分钟的任务，认为已经超时
    for m in (select taskindex, to_date(starttime, 'yyyymmddhh24miss'), correlateid, impcode, srcfileurl
    			from imp369_ftp_task where status = 2
    			and trunc((sysdate-to_date(starttime, 'yyyymmddhh24miss'))*24*60,0) > i_timeout) loop
    	begin
    		update imp369_ftp_task set status = 4, result = 1000,
    			description = 'longer time to ftp xml file', endtime = v_nowtime
    		where taskindex = m.taskindex;
    	exception
    	when others then
			v_retcode	:= 501;
			v_retdesc	:= 'update ftp task [' || m.taskindex || ']  to fail error, sqlcode['
						|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
--			rollback;/* 无需回滚 批量修改 修改不成功 不回退 不退出 20120529 Liuxp*/
			commit;
--			return;
		end;

    	zxdbm_cms.imp369_update_taskdetail(m.correlateid,1000, 'longer time to ftp xml file',
    										m.srcfileurl, o_retcode, o_retdesc);
		if o_retcode <> 0 then
--			rollback;
			v_retcode := o_retcode;
			v_retdesc := o_retdesc;
			commit;
--			return;
		end if;
    	commit;
    end loop;

    -- 同步任务表，超过i_timeout分钟的任务，认为已经超时
    for m in (select taskindex, correlateid, resultfileurl
			from zxdbm_cms.epgtemplt_sync_task where status = 2 and trunc((sysdate-to_date(starttime, 'yyyymmddhh24miss'))*24*60,0) > i_timeout) loop

		zxdbm_cms.imp369_update_taskdetail(m.correlateid, 1000, 'longer time for status = 2', m.resultfileurl, o_retcode, o_retdesc);
		if o_retcode <> 0 then
--			rollback;
			v_retcode := o_retcode;
			v_retdesc := o_retdesc;
			commit;
--			return;
		end if;
		commit;
	end loop;

	-- 清理过期任务
	v_expire_time := to_char(sysdate-30,'yyyymmddhh24miss');

	-- imp_epg_task_info
	delete imp369_ftp_task where starttime < v_expire_time;
	commit;

    o_retcode := 0;
    o_retdesc := v_retcode || ',' || v_retdesc;
    return;

    exception when others then
        o_retcode := sqlcode;
        o_retdesc := substr(sqlerrm, 1, 80);
        rollback;
        commit;
        return;
end imp369_cleantask;
/


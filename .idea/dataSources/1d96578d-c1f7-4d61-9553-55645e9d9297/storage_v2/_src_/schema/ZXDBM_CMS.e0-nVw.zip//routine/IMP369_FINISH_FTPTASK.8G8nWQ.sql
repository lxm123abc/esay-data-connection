create procedure           imp369_finish_ftptask
(
	i_taskindex		in		varchar2,		-- 接口机服务器编码
	i_result		in		number,			-- reply结果
	i_desc			in		varchar2,		-- 错误描述
	i_localftp		in		varchar2,		-- 本地ftp信息
	i_localpath		in		varchar2,		-- xml本地存放路径
	o_retcode		out		number,			-- 结果码
	o_retdesc		out		varchar2		-- 结果描述
)
as
	v_correlateid		zxdbm_cms.imp369_ftp_task.correlateid%TYPE;
	v_localfile			zxdbm_cms.imp369_ftp_task.destfileurl%TYPE;
	v_resultfileurl		varchar2(256);
	v_result			number(10,0);
	v_desc				varchar2(256);
	v_nowtime			varchar2(14);
	v_count				number(10,0);
begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_correlateid	:= 0;
	v_resultfileurl := '';
	v_result	:= 0;
	v_desc		:= '';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');
	v_count		:= 0;

	-- 查看ftp任务是否存在
	select count(*) into v_count from zxdbm_cms.imp369_ftp_task where taskindex = i_taskindex and status = 2;
	if v_count = 0 then
		o_retcode	:= 501;
		o_retdesc	:= 'no ftp_task in executing, taskindex[' || i_taskindex || ']';
		return;
	end if;

	-- 本地ftp全路径
	if i_localpath is not null then
		v_localfile := i_localftp||i_localpath;
	end if;

	-- 更新ftp任务
	begin
		update zxdbm_cms.imp369_ftp_task set status = decode(i_result, 0, 3, 4), endtime = v_nowtime,
		result = decode(i_result, 0, result, i_result), description = decode(i_result, 0, description, i_desc),
		destfileurl = v_localfile
		where taskindex = i_taskindex;
	exception
		when others then
		o_retcode	:= 442;
		o_retdesc	:= 'update ftp_task to success error,taskindex:' || i_taskindex;
--		rollback;
		commit;
		return;
	end;

	-- 获取同步任务相关信息
	select correlateid, nvl(destfileurl, srcfileurl), result, description
	into v_correlateid, v_resultfileurl, v_result, v_desc
	from zxdbm_cms.imp369_ftp_task where taskindex = i_taskindex;

	-- 更新同步任务
	zxdbm_cms.imp369_update_taskdetail(v_correlateid, v_result, v_desc, v_resultfileurl, o_retcode, o_retdesc);
	if o_retcode <> 0 then
--		rollback;
		commit;
		return;
	end if;

	commit;

exception
	when others then
		o_retcode	:= 449;
		o_retdesc	:= 'unkown exception, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		commit;
		return;

end imp369_finish_ftptask;
/


create procedure           imp369_store_ftptask
(
	i_impcode		in		varchar2,		-- 接口机编码
	i_cspid			in		varchar2, 		-- cms平台标识
	i_lspid			in 		varchar2, 		-- 业务平台标识
	i_correlateid	in		varchar2,		-- 关联性标识
	i_resultfileurl	in		varchar2,		-- 内容管理结果反馈的 结果指令文件 ftp地址
	i_resultcode	in		number,			-- 内容管理结果反馈的结果码
	i_description	in		varchar2,		-- 内容管理结果反馈的结果描述
	i_lsptype		in		number,			-- lsp类型
	o_retcode		out		number,			-- 结果码
	o_retdesc		out		varchar2		-- 结果描述
)
as
	v_taskindex	number(10,0);			-- 任务索引号
begin
	-- 获取index
	zxdbm_umap.sp_getmaxvalue('imp369_ftp_task', 1, v_taskindex);

	-- 插入文件迁移任务
	begin
		insert into zxdbm_cms.imp369_ftp_task (
			taskindex,
			impcode,
			cspid,
			lspid,
			correlateid,
			srcfileurl,
			result,
			description,
			destfileurl,
			tasktype,
			lsptype,
			status,
			starttime,
			endtime
			)
		values(
			v_taskindex,
			i_impcode,
			i_cspid,
			i_lspid,
			i_correlateid,
			i_resultfileurl,
			i_resultcode,
			i_description,
			'',
			1,
			i_lsptype,
			1,
			'',
			''
			);
	exception
		when others then
			o_retcode	:= 401;
			o_retdesc	:= 'insert ftp info error,sqlcode:' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
			rollback;
			commit;
	end;

	o_retcode	:= 0;
	o_retdesc	:= 'success';
	commit;

exception
	when others then
		o_retcode	:= 402;
		o_retdesc	:= 'unkown exception, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		commit;

end imp369_store_ftptask;
/


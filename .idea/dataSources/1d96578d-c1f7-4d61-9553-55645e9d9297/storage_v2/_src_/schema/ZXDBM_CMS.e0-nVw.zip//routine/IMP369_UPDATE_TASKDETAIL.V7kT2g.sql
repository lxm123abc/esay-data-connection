create procedure           imp369_update_taskdetail
(
	i_correlateid	in		varchar2,	-- 任务流水号
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	i_reusltfileurl	in		varchar2,	-- 结果reply文件地址
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
	v_nowtime		varchar2(14);
	v_taskindex		number(10, 0);

begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间
	v_taskindex	:= 0;

	-- 查看任务是否存在
	begin
		select taskindex into v_taskindex from zxdbm_cms.epgtemplt_sync_task where correlateid = i_correlateid;
	exception
	when no_data_found then
		o_retcode	:= 205;
		o_retdesc	:= 'no task with correlateid [' || i_correlateid || ']';
		return;
	end;

	begin
		update zxdbm_cms.epgtemplt_sync_task set status = decode(i_result, 0, 3, 4), resultcode = i_result,
		resultdesc = i_desc, resultfileurl = i_reusltfileurl, starttime = nvl(starttime, v_nowtime),
		endtime = v_nowtime where taskindex = v_taskindex;
	exception
		when others then
		o_retcode	:= 202;
		o_retdesc	:= 'update task detail error, taskindex[' || v_taskindex ||
			 '], sqlcode[' || sqlcode || '], sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
		return;
	end;

	-- 迁移任务到历史表
	begin
		insert into zxdbm_cms.epgtemplt_sync_task_his (taskindex, starttime, endtime, status, priority,
			description, resultcode, resultdesc, resultfileurl, correlateid,
			templtindex, tasktype, platform, cmdfileurl, source)
			select taskindex, starttime, endtime, status, priority,
			description, resultcode, resultdesc, resultfileurl, correlateid,
			templtindex, tasktype, platform, cmdfileurl, source
			from zxdbm_cms.epgtemplt_sync_task where taskindex = v_taskindex;

		delete zxdbm_cms.epgtemplt_sync_task where taskindex = v_taskindex;

		exception
		when others then
			o_retcode	:= 203;
			o_retdesc	:= 'mv task [' || v_taskindex || ']  to task_his error, sqlcode['
				|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
			rollback;
			commit;
			return;
	end;

	commit;
exception
	when others then
		o_retcode	:= 210;
		o_retdesc	:= 'unkown error, sqlcode[' || sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
		rollback;
		commit;
		return;
end imp369_update_taskdetail;
/


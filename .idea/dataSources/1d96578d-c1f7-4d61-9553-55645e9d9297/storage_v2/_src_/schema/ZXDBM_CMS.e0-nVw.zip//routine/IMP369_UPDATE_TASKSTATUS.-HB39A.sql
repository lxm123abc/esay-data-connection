create procedure           imp369_update_taskstatus
(
	i_taskindex		in		number,		-- 任务索引
	i_result		in		number,		-- 执行结果
	i_desc			in		varchar2,	-- 错误描述
	o_retcode		out		number,		-- 结果码
	o_retdesc		out		varchar2	-- 结果描述
)
as
	v_nowtime		varchar2(14);
	v_templtindex	number(10,0);
	v_platform		number(3,0);
	v_targeturl		varchar2(256);	-- 目标系统url
	v_standard		number(3,0);	-- 目标系统标识
	v_cmdfileurl	varchar2(256);	-- 2.0平台 下发xml地址
	v_templtid		zxdbm_cms.epgtemplt.templtid%TYPE;
	v_templtver		zxdbm_cms.epgtemplt.templtver%TYPE;
	v_templtdftflag	zxdbm_cms.epgtemplt.templtdftflag%TYPE;
	v_begintime		zxdbm_cms.epgtemplt.begintime%TYPE;
	v_expiredtime	zxdbm_cms.epgtemplt.expiredtime%TYPE;
	v_addresspath	zxdbm_cms.epgtemplt.addresspath%TYPE;
	v_tasktype		number(3,0);
	v_count			number(10,0);

begin
	-- 初始化
	o_retcode	:= 0;
	o_retdesc	:= 'success';
	v_templtindex	:= 0;
	v_targeturl	:= '';
	v_nowtime	:= to_char(sysdate, 'yyyymmddhh24miss');	-- 当前时间
	v_count		:= 0;

	-- 判断任务是否存在
	select count(*) into v_count from zxdbm_cms.epgtemplt_sync_task where taskindex = i_taskindex;
	if v_count = 0 then
		o_retcode	:= 211;
		o_retdesc	:= 'no task [' || i_taskindex || ']';
		return;
	end if;

	-- 状态修改为执行中
	if (i_result = 2) then
		begin
			update zxdbm_cms.epgtemplt_sync_task set status = i_result, starttime = v_nowtime
			where taskindex = i_taskindex;
		exception
		when others then
			o_retcode	:= 212;
			o_retdesc	:= 'update epgtask status error, taskindex [' || i_taskindex || '] sqlcode['
						|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
			commit;
			return;
		end;

		-- 查询templtindex
		select templtindex, platform, tasktype, cmdfileurl
		into v_templtindex, v_platform, v_tasktype, v_cmdfileurl
		from zxdbm_cms.epgtemplt_sync_task where taskindex = i_taskindex;

		-- 查询目标url
		-- 2.0 - targeturl&standard&cmdfileurl
		-- 3.0 - targeturl&standard&templtid&action&templtver&templtdftflag&begintime&expiredtime&addrpath
		begin
			-- 1-2.0平台，2-3.0平台
			if v_platform = 1 then
				select sendto20addr,standard20 into v_targeturl,v_standard
				from zxdbm_cms.epgtemplt where templtindex = v_templtindex;

				o_retdesc := v_targeturl||'&'||v_standard||'&'||v_cmdfileurl;
			else
				select sendto30addr,standard30 into v_targeturl,v_standard
				from zxdbm_cms.epgtemplt where templtindex = v_templtindex;

				o_retdesc := v_targeturl||'&'||v_standard||'&'||v_templtid||'&'||v_tasktype||'&'||
				v_templtver||'&'||v_templtdftflag||'&'||v_begintime||'&'||v_expiredtime||'&'||v_addresspath;
			end if;

			-- 1-2.0规范 2-3.0规范
			if v_standard = 1 then
				o_retdesc := v_targeturl||'&'||v_standard||'&'||v_cmdfileurl;
			else
				select templtid,templtver,templtdftflag,begintime,expiredtime,addresspath
				into v_templtid,v_templtver,v_templtdftflag,v_begintime,v_expiredtime,v_addresspath
				from zxdbm_cms.epgtemplt where templtindex = v_templtindex;

				o_retdesc := v_targeturl||'&'||v_standard||'&'||v_templtid||'&'||v_tasktype||'&'||
				v_templtver||'&'||v_templtdftflag||'&'||v_begintime||'&'||v_expiredtime||'&'||v_addresspath;
			end if;

		exception
			when no_data_found then
				o_retcode	:= 10000;
				o_retdesc	:= 'no target url&id found with taskindex[' || i_taskindex || ']';
				commit;	/* 无需回滚 直接提交 在代码中 url错误 任务失败结束 */
				return;
		end;

	else
		-- 更新任务状态及信息
		begin
			update zxdbm_cms.epgtemplt_sync_task set status = decode(i_result, 0, 3, 4), resultcode = i_result,
			resultdesc = i_desc, starttime = nvl(starttime, v_nowtime), endtime = v_nowtime
			where taskindex = i_taskindex;
		exception
			when others then
			o_retcode	:= 213;
			o_retdesc	:= 'update epgtask status error, taskindex [' || i_taskindex || '] sqlcode['
						|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
			rollback;
			commit;
			return;
		end;
		-- 迁移任务到历史表
		begin
			insert into zxdbm_cms.epgtemplt_sync_task_his (taskindex, starttime, endtime, status, priority,
			description, resultcode, resultdesc, resultfileurl, correlateid,
			templtindex, tasktype, platform, cmdfileurl, source)
			select taskindex, starttime, endtime, status, priority,
			description, resultcode, resultdesc, resultfileurl, correlateid,
			templtindex, tasktype, platform, cmdfileurl, source
			from zxdbm_cms.epgtemplt_sync_task where taskindex = i_taskindex;

			delete zxdbm_cms.epgtemplt_sync_task where taskindex = i_taskindex;

		exception
			when others then
				o_retcode	:= 214;
				o_retdesc	:= 'mv epgtask [' || i_taskindex || ']  to task_his error, sqlcode['
				|| sqlcode || '] sqlerrm[' || substr(sqlerrm, 0, 64) || ']';
				rollback;
				commit;
				return;
		end;
	end if;

	commit;
exception
	when others then
		o_retcode	:= 219;
		o_retdesc	:= 'unkown exception, sqlcode' || sqlcode || ',sqlerrm'|| substr(sqlerrm, 0, 64);
		rollback;
		commit;
		return;
end imp369_update_taskstatus;
/


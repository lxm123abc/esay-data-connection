create procedure imp_epg_cleantask
(
    i_impcode       in  varchar2,
	i_backdate		in	number,
	i_tasktimeout	in	number,
    o_result  		out number,
    o_desc    		out varchar2
)
as
    v_tmp_date date;
    v_tmp_time number(10);
    v_tmp_taskid number(10);
    v_expire_time varchar2(20);

begin
    begin
        select task_id, to_date(create_time,'yyyy.mm.dd hh24:mi:ss') into v_tmp_taskid, v_tmp_date
        from imp_epg_task_info where (state=1 or state=2 or state=3) and impcode=i_impcode;
        exception when no_data_found then
            o_result := 0;
            o_desc   := 'success';
        return;
    end;
    --select trunc((sysdate-v_tmp_date)*24*60,0) into v_tmp_time from dual;
    v_tmp_time := trunc((sysdate-v_tmp_date)*24*60,0);

    if v_tmp_time>i_tasktimeout then
    --超过i_tasktimeout分钟的任务，认为已经超时
        update imp_epg_task_detail set state=2, result=1, description='time out' where task_id=v_tmp_taskid;
        update imp_epg_task_info set state=4, result=1, description='time out' where task_id=v_tmp_taskid;
    end if;

	-- 清理过期任务
	v_expire_time := to_char(add_months(sysdate, -i_backdate),'yyyy.mm.dd hh24:mi:ss');

	-- imp_epg_task_info
	delete imp_epg_task_info where create_time < v_expire_time and impcode=i_impcode;
	commit;

	-- imp_epg_upgrade_info
	delete imp_epg_upgrade_info where begin_time < v_expire_time;
	commit;

    o_result := 0;
    o_desc   := 'success';
    return;

    exception when others then
        o_result := sqlcode;
        o_desc   := substr(sqlerrm, 1, 80);
        rollback;
        return;
end imp_epg_cleantask;
/


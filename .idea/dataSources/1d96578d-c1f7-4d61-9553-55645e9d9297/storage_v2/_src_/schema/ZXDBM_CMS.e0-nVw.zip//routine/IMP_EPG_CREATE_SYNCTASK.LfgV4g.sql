create procedure imp_epg_create_synctask
(
	i_taskid       in number,
    i_result       in number,
    i_desc         in varchar2,
    i_iptv20_xmlsync	in varchar2,
    i_iptv30_xmlsync    in varchar2,
    o_result       out number,
    o_desc         out varchar2
)
as
    v_taskindex	    	number(10);
    v_templtindex		number(10);
    v_status			number(3,0);
    v_is20				number(3,0);
    v_standard20		number(3,0);	-- 1-2.0规范，2-3.0规范
    v_is30				number(3,0);
    v_standard30		number(3,0);	-- 1-2.0规范，2-3.0规范
    v_tasktype			number(3,0);
    v_action			imp_epg_task_detail.action%TYPE;
    v_tmp_epggroup      varchar2(128);
    e_invalid_action	exception;
begin
	o_result	:= 0;
	o_desc		:= 'success';
    v_taskindex	:= 0;
    v_templtindex := 0;
    v_status := 0;
    v_is20 := 0;
    v_standard20 := 0;
    v_is30 := 0;
    v_standard30 := 0;
    v_tasktype := 0;
    v_action := '';
    v_tmp_epggroup := '';

	if i_result = 0 then
		select epg_group into v_tmp_epggroup from imp_epg_task_info where task_id=i_taskid;
		-- 任务在接口机中处理成功，写入到cms的模板同步任务表中 add liuxp 2012-12-05
    	begin
    		select templtindex, status, sendto20flag, standard20, sendto30flag, standard30
    			into v_templtindex, v_status, v_is20, v_standard20, v_is30, v_standard30
    			from zxdbm_cms.epgtemplt where epggroup = v_tmp_epggroup;
    	exception
    		when no_data_found then
    		o_result := 102;
       		o_desc   := 'no epg templt, epggroup:' || v_tmp_epggroup;
			raise e_invalid_action;
    	end;

    	select action into v_action from imp_epg_task_detail
    		where task_id=i_taskid and rownum=1;
    	if v_action = 'DELETE' then
    		v_tasktype := 3;
    	else
    		v_tasktype := 1;
    	end if;

    	if v_is20 = 1 then
    		zxdbm_umap.sp_getmaxvalue('cms_epgtempltsync_seq', 1, v_taskindex);
        	insert into epgtemplt_sync_task
        	(taskindex, status, priority, correlateid, templtindex, tasktype, source, platform, cmdfileurl)
        	values
        	(v_taskindex, 1, 2, lpad(v_taskindex, 20, 0), v_templtindex, v_tasktype, 1, 1, i_iptv20_xmlsync);
        end if;

        if v_is30 = 1 then
    		zxdbm_umap.sp_getmaxvalue('cms_epgtempltsync_seq', 1, v_taskindex);
    		if v_standard30 = 1 then
    			insert into epgtemplt_sync_task
        		(taskindex, status, priority, correlateid, templtindex, tasktype, source, platform, cmdfileurl)
        		values
        		(v_taskindex, 1, 2, lpad(v_taskindex, 20, 0), v_templtindex, v_tasktype, 1, 2, i_iptv30_xmlsync);
    		elsif v_standard30 = 2 then
    			insert into epgtemplt_sync_task
        		(taskindex, status, priority, correlateid, templtindex, tasktype, source, platform)
        		values
        		(v_taskindex, 1, 2, lpad(v_taskindex, 20, 0), v_templtindex, v_tasktype, 1, 2);
    		end if;
        end if;
	end if;

	update imp_epg_task_info set state=4,result=i_result,description=i_desc where task_id=i_taskid;
	update imp_epg_task_detail set state=2,result=i_result,description=i_desc
		where task_id=i_taskid and state in (0,1);

	commit;
    return;

exception
	when e_invalid_action then
		update imp_epg_task_info set state=4,result=5,description=o_desc where task_id=i_taskid;
		update imp_epg_task_detail set state=2,result=5,description=o_desc
			where task_id=i_taskid and state in (0,1);
		commit;
	    return;
	when others then
	    rollback;
	    o_result := sqlcode;
	    o_desc   := substr(sqlerrm, 1, 80);
	    update imp_epg_task_info set state=4,result=1,description=o_desc where task_id=i_taskid;
		update imp_epg_task_detail set state=2,result=1,description=o_desc
			where task_id=i_taskid and state in (0,1);
	    commit;
	    return;
end imp_epg_create_synctask;
/


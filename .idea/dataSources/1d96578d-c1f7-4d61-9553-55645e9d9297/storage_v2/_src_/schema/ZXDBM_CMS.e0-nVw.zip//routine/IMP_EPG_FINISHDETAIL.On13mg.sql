create procedure imp_epg_finishdetail
(
	i_taskid       in number,
    i_result       in number,
    i_desc         in varchar2,
    i_epgfilesetid in varchar2,
    i_epgfileid    in varchar2,
    i_test_epg     in number,
    o_result       out number,
    o_retdesc	   out varchar2,
    o_reqxmlfile   out varchar2,
    o_xmlsyncdir   out varchar2,
    o_iptv20_standard out number,
    o_iptv30_standard out number
)
as
	type t_arr_result_table is table of zxdbm_cms.imp_epg_task_detail%rowtype;
	v_arr_result_table	t_arr_result_table;
	v_tmp_exists	number(10,0);
	v_tmp_result	number(10,0);
	v_tmp_epggroup	varchar2(128);
begin
	o_result		:= 0;
	o_retdesc		:= 'success';
	v_tmp_exists	:= 0;
	v_tmp_result	:= 0;

	update imp_epg_task_detail set state=2,result=i_result,description=i_desc
        where task_id=i_taskid and epg_file_set_id=i_epgfilesetid and epg_file_id=i_epgfileid;
    select count(*) into v_tmp_exists from imp_epg_task_detail where task_id=i_taskid and (state=0 or state=1);
    if v_tmp_exists=0 then
    	select * bulk collect into v_arr_result_table from imp_epg_task_detail
    		where task_id=i_taskid;
    	if v_arr_result_table.count = 0 then
    		o_result	:= 101;
    		o_retdesc	:= 'no detail,taskid:'||i_taskid;
    		update imp_epg_task_info set state=4,result=1,description=o_retdesc where task_id=i_taskid;
        	commit;
    		return;
    	end if;

    	for m in 1..v_arr_result_table.count loop
    		if v_arr_result_table(m).result <> 0 then
    			v_tmp_result := v_arr_result_table(m).result;
    		end if;
    	end loop;

        if v_tmp_result<>0 then
        	-- state=4 等待结果上报 state=5 等待生成syncxml
        	update imp_epg_task_info set state=4,result=v_tmp_result,description=i_desc where task_id=i_taskid;
        else
        	update imp_epg_task_info set state=5,result=v_tmp_result,description=i_desc where task_id=i_taskid;
        	select epg_group,file_name into v_tmp_epggroup,o_reqxmlfile from imp_epg_task_info
        		where task_id=i_taskid;
        	-- （1-2.0规范，2-3.0规范）
        	select standard20, standard30 into o_iptv20_standard, o_iptv30_standard from zxdbm_cms.epgtemplt
        		where epggroup = v_tmp_epggroup;
        	zxdbm_cms.sp_cms_getpath(1,o_result,o_xmlsyncdir);
        	if o_result <> 0 then
        		o_retdesc := 'get temp xmlsync path fail';
        		update imp_epg_task_info set state=4,result=1,description=o_retdesc where task_id=i_taskid;
        		commit;
        		return;
        	end if;
        	o_result	:= 10000;
        	o_retdesc	:= 'all detail finish,then create syncxml';
        end if;
    end if;
    commit;
exception
	when others then
		o_result	:= 999;
		o_retdesc	:= substr(sqlerrm, 1, 80);
		rollback;
		commit;
end imp_epg_finishdetail;
/


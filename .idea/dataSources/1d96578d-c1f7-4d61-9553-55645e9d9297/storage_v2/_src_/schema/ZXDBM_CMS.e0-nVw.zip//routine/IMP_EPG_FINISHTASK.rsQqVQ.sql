create procedure imp_epg_finishtask
(
    i_taskid        in number,
    i_result        in number,
    i_desc          in varchar2,
    i_epgfilesetid  in varchar2,
    i_epgfileid     in varchar2,
    i_test_epg      in number,
    i_cmdreqfile    in varchar2,
    o_result        out number,
    o_desc          out varchar2
)
as

begin

    update imp_epg_task_info set state=4,result=i_result,description=i_desc,cmdxmlurl=i_cmdreqfile
    where task_id=i_taskid;
    update imp_epg_task_detail set state=2,result=i_result,description=i_desc
        where task_id=i_taskid and epg_file_set_id=i_epgfilesetid and epg_file_id=i_epgfileid;
    update imp_epg_task_detail set state=2 where task_id=i_taskid and epg_file_set_id=i_epgfilesetid and (state=0 or state=1);

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;

    exception when others then
        rollback;
        o_result := sqlcode;
        o_desc   := substr(sqlerrm, 1, 80);
    return;
end imp_epg_finishtask;
/


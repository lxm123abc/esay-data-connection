create procedure imp_epg_getdetail
(
    i_impcode       in  varchar2,
    o_result        out number,
    o_desc          out varchar2,
    o_taskid        out number,
    o_epgtype       out number,
    o_epggroup      out varchar2,
    o_needuntar     out number,
    o_epgfilesetid  out varchar2,
    o_epgfilenum    out number,
    o_epgfileid     out varchar2,
    o_action        out varchar2,
    o_ftpip         out varchar2,
    o_ftpuser       out varchar2,
    o_ftppasswd     out varchar2,
    o_ftpport       out number,
    o_ftppath       out varchar2,
    o_ftpname       out varchar2,
    o_destpath      out varchar2,
    o_destfile      out varchar2,
    o_md5           out varchar2
)
as
    v_tmp_taskid    number(10);

begin
    --查找stat=2（即xml解析完，待detail处理）的最小的任务id
    begin
      select min(task_id) into v_tmp_taskid from imp_epg_task_info where state=2 and impcode=i_impcode;
      if v_tmp_taskid is null then
        o_result := 1;
        o_desc   := 'no detail to be proceed';
        return;
      end if;
    end;
    begin
    select b.task_id,b.epg_file_set_id,b.need_untar,b.epg_type,b.epg_group,a.epg_file_id,a.action,a.ftp_ip,a.ftp_user,a.ftp_pwd,a.ftp_port,a.ftp_path,a.file_name,a.dest_path,a.dest_file,a.md5
        into o_taskid,o_epgfilesetid,o_needuntar,o_epgtype,o_epggroup,o_epgfileid,o_action,o_ftpip,o_ftpuser,o_ftppasswd,o_ftpport,o_ftppath,o_ftpname,o_destpath,o_destfile,o_md5
        from imp_epg_task_detail a, imp_epg_task_info b
        where a.task_id=b.task_id
        and a.state=0
        and a.task_id=v_tmp_taskid
        and rownum=1;

    exception when no_data_found then
        --所有的detail均已经开始处理或处理完成
        --update imp_epg_task_info set state=4 where task_id=v_tmp_taskid;
        o_result := 100;
        o_desc   := 'all details done';
        commit;
        return;
    end;

    update imp_epg_task_detail set state=1
        where task_id=o_taskid and epg_file_set_id=o_epgfilesetid and epg_file_id=o_epgfileid;
    --返回剩余待处理的文件数目
    select count(1) into o_epgfilenum from imp_epg_task_detail
        where task_id=o_taskid and epg_file_set_id=o_epgfilesetid and state=0;

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;

    exception when others then
        o_result := sqlcode;
        o_desc   := substr(sqlerrm, 1, 80);
        rollback;
        return;

end imp_epg_getdetail;
/


create procedure imp_epg_getfilenotify
(
    i_taskid        in number,
    o_result        out number,
    o_desc          out varchar2,
    o_epgfilesetid  out varchar2,
    o_epgfileid     out varchar2,
    o_sourceurl     out varchar2,
    o_result2       out number,
    o_desc2         out varchar2
)
as
	v_tmp_exists    number(4);
    v_tmp_fileid    varchar2(32);
begin

	select count(1),min(epg_file_id) into v_tmp_exists,v_tmp_fileid from imp_epg_task_detail
            where state=2 and task_id=i_taskid;
    if v_tmp_exists>0 then
        select epg_file_set_id,epg_file_id,'ftp://'||ftp_user||':'||ftp_pwd||'@'||ftp_ip||':'||ftp_port||ftp_path||file_name, result,description
            into o_epgfilesetid,o_epgfileid,o_sourceurl,o_result2,o_desc2
            from imp_epg_task_detail
            where task_id=i_taskid and state=2 and epg_file_id=v_tmp_fileid and rownum=1;
        delete imp_epg_task_detail where epg_file_id = v_tmp_fileid;
    else
    	o_result := 1;
    	o_desc := 'no epgfile info to notify';
    	delete imp_epg_task_detail where task_id = i_taskid;
    	update imp_epg_task_info set state = 6 where task_id = i_taskid;

    	commit;
    	return;
    end if;

    o_result := 0;
    o_desc := 'success';
    commit;

    exception
    	when others then
    		o_result := sqlcode;
    		o_desc := substr(sqlerrm, 1, 80);
    		rollback;
    		return;
end imp_epg_getfilenotify;
/


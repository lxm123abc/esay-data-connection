create procedure imp_epg_getfinishedtask
(
    i_impcode       in  varchar2,
    o_result        out number,
    o_desc          out varchar2,
    o_taskid        out number,
    o_spindex       out number,
    o_correlateid   out varchar2,
    o_filename      out varchar2,
    o_result1       out number,
    o_desc1         out varchar2,
    o_epgfilesetid  out varchar2,
    o_epgfileid     out varchar2,
    o_sourceurl     out varchar2,
    o_result2       out number,
    o_desc2         out varchar2
)
as
    v_tmp_exists    number(4);
    v_tmp_taskid    number(10);
    v_tmp_fileid    varchar2(32);
    v_upgrade_serial number(10);
begin

    select count(1),min(task_id) into v_tmp_exists,v_tmp_taskid from imp_epg_task_info
    where state=4 and impcode=i_impcode;
    if v_tmp_exists=0 then
        o_result := 1;
        o_desc   := 'no task to notify';
        return;
    end if;

    begin
        select task_id,sp_index,correlate_id,file_name,result,description, epg_file_set_id
            into o_taskid,o_spindex,o_correlateid,o_filename,o_result1,o_desc1, v_tmp_fileid
            from imp_epg_task_info
            where task_id=v_tmp_taskid;
    end;

    -- 更新升级记录
   	select max(upgrade_serial) into v_upgrade_serial from imp_epg_upgrade_info
    	where frame_id = v_tmp_fileid and result = 999;
    if v_upgrade_serial is not null then
    	if o_result1 <> 0 then
    		begin
    			update imp_epg_upgrade_info set result = 1,
    			end_time = to_char(sysdate, 'yyyy.mm.dd hh24:mi:ss'), description = 'epgfile sync error'
    			where upgrade_serial = v_upgrade_serial and result = 999;
    		end;
    	else
    		begin
    			update imp_epg_upgrade_info set result = 0,
    			end_time = to_char(sysdate, 'yyyy.mm.dd hh24:mi:ss'), description = 'success'
    			where upgrade_serial = v_upgrade_serial and result = 999;
    		end;
    		--升级成功 删除detail记录 （成功不反馈epgfile信息）
    		begin
    			delete imp_epg_task_detail where task_id = v_tmp_taskid;
    		end;
    	end if;
	end if;

    begin
        select count(1),min(epg_file_id) into v_tmp_exists,v_tmp_fileid from imp_epg_task_detail
            where state=2 and task_id=v_tmp_taskid and result<>0;
        if v_tmp_exists>0 then
            select epg_file_set_id,epg_file_id,'ftp://'||ftp_user||':'||ftp_pwd||'@'||ftp_ip||':'||ftp_port||ftp_path||file_name, result,description
                into o_epgfilesetid,o_epgfileid,o_sourceurl,o_result2,o_desc2
                from imp_epg_task_detail
                where task_id=v_tmp_taskid and state=2 and epg_file_id=v_tmp_fileid and rownum=1;
         end if;
    end;

	--删除detail表中的纪录
--    delete imp_epg_task_detail where task_id=v_tmp_taskid;
    update imp_epg_task_info set state=6 where task_id=v_tmp_taskid;
    commit;
    o_result := 0;
    o_desc   := 'success';
    return;

    exception when others then
        rollback;
        o_result := sqlcode;
        o_desc   := substr(sqlerrm, 1, 80);
        return;
end imp_epg_getfinishedtask;
/


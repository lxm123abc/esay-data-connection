create procedure imp_epg_gettask
(
    i_impcode   in  varchar2,
    o_result    out number,
    o_desc      out varchar2,
    o_taskid    out number,
    o_ftpip     out varchar2,
    o_ftpport   out number,
    o_ftpuser   out varchar2,
    o_ftppasswd out varchar2,
    o_ftppath   out varchar2,
    o_ftpfile   out varchar2,
    o_spindex   out number
)
as
    v_tmp_exists number(10);
    v_tmp_taskid number(10);
begin
    o_result := 0;
    v_tmp_exists := 0;
    v_tmp_taskid := 0;

    -- 如果当前有任务待处理，还需要增加一步判断当前处理的任务是否已经超时
    select count(1) into v_tmp_exists from imp_epg_task_info where (state=1 or state=2 or state=3) and impcode=i_impcode;
    if v_tmp_exists > 0 then
        o_result := 1;
        o_desc   := 'some task in detail table';
        return;
    end if;

    select count(1) into v_tmp_exists from imp_epg_task_info where state=0 and impcode=i_impcode;
    if v_tmp_exists=0 then
        o_result := 2;
        o_desc   := 'no task to deal';
        return;
    end if;

    -- status:1待执行 2执行中 3成功结束 4失败结束 source:1-文广 2-cms modify by Liuxp 2011-11-30
/*    select count(1) into v_tmp_exists from zxdbm_cms.epgtemplt_sync_task where status in (1,2) and source = 1;
    if v_tmp_exists > 0 then
        o_result := 4;
        o_desc := 'some task in epgtemplt_sync_task';
        return;
    end if;
*/
    begin
    select min(task_id) into v_tmp_taskid from imp_epg_task_info where state=0 and impcode=i_impcode;
    select task_id,ftp_ip,ftp_port,ftp_user,ftp_pwd,ftp_path,file_name,sp_index
      into o_taskid,o_ftpip,o_ftpport,o_ftpuser,o_ftppasswd,o_ftppath,o_ftpfile,o_spindex
      from imp_epg_task_info
      where task_id=v_tmp_taskid and state=0;
    end;
    update imp_epg_task_info set state=1,deal_time=to_char(sysdate,'yyyy.mm.dd hh24:mi:ss') where task_id = v_tmp_taskid;

    o_desc := 'success';

    commit;
    return;

    exception when others then
      rollback;
      o_result := sqlcode;
      o_desc   := substr(sqlerrm, 1, 80);
      return;
end imp_epg_gettask;
/


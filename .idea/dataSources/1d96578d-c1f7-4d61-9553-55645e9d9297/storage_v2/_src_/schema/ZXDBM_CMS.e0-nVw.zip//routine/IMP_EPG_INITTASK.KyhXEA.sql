create procedure imp_epg_inittask
(
    o_result   out  number,
    o_desc     out  varchar2
)
as
begin
    --delete imp_epg_task_detail a where exists (select 1 from imp_epg_task_info b where a.task_id=b.task_id and (b.state=1 or b.state=2 or b.state=3));
    --delete imp_epg_task_detail;
    update imp_epg_task_info set state=0 where state=1 or state=2 or state=3;

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;
end imp_epg_inittask;
/


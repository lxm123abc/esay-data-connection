create procedure imp_epg_storedetail
(
    i_taskid         in number,
    i_epgfilesetid   in varchar2,
    i_epgfileid      in varchar2,
    i_action         in varchar2,
    i_ftpip          in varchar2,
    i_ftpuser        in varchar2,
    i_ftppasswd      in varchar2,
    i_ftpport        in number,
    i_ftppath        in varchar2,
    i_ftpname        in varchar2,
    i_destpath       in varchar2,
    i_destfile       in varchar2,
    i_md5            in varchar2,
    o_result         out number,
    o_desc           out varchar2
)
as
    v_tmp_count      number(4);
    v_tmp_epgfilenum number(4);

begin

    insert into imp_epg_task_detail
        (task_id,epg_file_set_id,epg_file_id,action,ftp_ip,ftp_user,ftp_pwd,ftp_port,ftp_path,file_name,dest_path,dest_file,md5,state,create_time)
        values
        (i_taskid,i_epgfilesetid,i_epgfileid,i_action,i_ftpip,i_ftpuser,i_ftppasswd,i_ftpport,i_ftppath,i_ftpname,i_destpath,i_destfile,i_md5,0,to_char(sysdate,'yyyy.mm.dd hh24:mi:ss'));

    select count(1) into v_tmp_count from imp_epg_task_detail where task_id=i_taskid and epg_file_set_id=i_epgfilesetid;
    select epg_file_num into v_tmp_epgfilenum from imp_epg_task_info where task_id=i_taskid and epg_file_set_id=i_epgfilesetid;
    if v_tmp_count = v_tmp_epgfilenum then
        --全部detail保存后，修改状态为解析完毕，等待detail处理
        update imp_epg_task_info set state=2 where task_id=i_taskid and epg_file_set_id=i_epgfilesetid;
    end if;

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;

    exception when others then
        o_result := sqlcode;
        o_desc   := substr(sqlerrm, 1, 80);
        rollback;
        return;

end imp_epg_storedetail;
/


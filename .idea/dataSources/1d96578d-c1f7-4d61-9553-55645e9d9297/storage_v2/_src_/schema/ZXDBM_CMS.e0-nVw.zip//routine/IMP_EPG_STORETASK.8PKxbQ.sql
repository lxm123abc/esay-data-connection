create procedure imp_epg_storetask
(
  i_sp_index        in number                         , --该task对应的csplsp
  i_correlate_id    in varchar2                       , --该task对应的相关性标识
  i_ftp_ip          in varchar2                       , --该task对应的xml文件的ftp地址
  i_ftp_user        in varchar2                       , --该task对应的xml文件的ftp用户名
  i_ftp_pwd         in varchar2                       , --该task对应的xml文件的ftp密码
  i_ftp_port        in number                         , --该task对应的xml文件的ftp端口
  i_ftp_path        in varchar2                       , --该task对应的xml文件的ftp路径
  i_file_name       in varchar2                       , --该task对应的xml文件名称
  i_impcode         in varchar2                       , --该task对应的接口机编号
  o_result          out number                        ,
  o_desc            out varchar2
)
as
  v_tmp_taskid number(10);


begin
  o_result := 0;
  v_tmp_taskid := 0;

  begin
    select max(task_id) into v_tmp_taskid from imp_epg_task_info;
    if v_tmp_taskid is null then
       v_tmp_taskid := 0;
    else
       v_tmp_taskid := v_tmp_taskid+1;
    end if;
  end;

  insert into imp_epg_task_info
  (task_id,sp_index,correlate_id,ftp_ip,ftp_user,ftp_pwd,ftp_port,ftp_path,file_name,
  state,create_time,impcode)
  values
  (v_tmp_taskid,i_sp_index,i_correlate_id,i_ftp_ip,i_ftp_user,i_ftp_pwd,i_ftp_port,i_ftp_path,i_file_name,
  0,to_char(sysdate,'yyyy.mm.dd hh24:mi:ss'),i_impcode);

  o_desc := 'success';

  commit;
  return;

  exception when others then
    rollback;
    o_result := sqlcode;
    o_desc   := substr(sqlerrm, 1, 80);
    return;
end imp_epg_storetask;
/


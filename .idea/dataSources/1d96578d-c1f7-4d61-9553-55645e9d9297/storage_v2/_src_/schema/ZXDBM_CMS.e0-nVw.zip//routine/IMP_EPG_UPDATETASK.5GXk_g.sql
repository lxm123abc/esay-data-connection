create procedure imp_epg_updatetask
(
    i_taskid       in number,
    i_epgfilenum   in number,
    i_epgfilesetid in varchar2,
    i_epggroup     in varchar2,
    i_epgtype	   in number,
    i_systemfile   in number,
    i_needuntar    in number,
    i_begintime	   in varchar2,
    i_cmdfileurl   in varchar2,
    o_result       out number,
    o_desc         out varchar2
)
as
    v_tmp_exists		number(4);
--    v_tmp_epgtype		number(4);
    v_upgrade_serial	number(10);
    v_cp_spindex		number(4);
    v_spindex			number(4);

begin
  	begin
    	select count(1) into v_tmp_exists from imp_epg_task_info where task_id=i_taskid;
    	if v_tmp_exists=0 then
        	o_result := 1;
        	o_desc   := 'no task with taskid '||i_taskid;
        	return;
    	elsif v_tmp_exists>1 then
        	o_result := 2;
        	o_desc   := 'more than 1 task with taskid '||i_taskid;
        	return;
    	end if;
  	end;

--    if i_epggroup is null or length(i_epggroup)=0 then
--        v_tmp_epgtype :=0;
--    else
--        v_tmp_epgtype :=1;
--    end if;

    update imp_epg_task_info
        set epg_file_num=i_epgfilenum, epg_file_set_id=i_epgfilesetid, epg_group=i_epggroup,
        system_file=i_systemfile, need_untar=i_needuntar, begin_time=i_begintime, epg_type=i_epgtype,
        state=1, cmdxmlurl=i_cmdfileurl
        where task_id=i_taskid;

	--add by Liuxp 2011-11-30
    select max(upgrade_serial) into v_upgrade_serial from imp_epg_upgrade_info;
    if v_upgrade_serial is null then
    	v_upgrade_serial := 0;
    else
    	v_upgrade_serial := v_upgrade_serial+1;
    end if;
  	-- 插入升级记录
  	begin
  		insert into imp_epg_upgrade_info (upgrade_serial, begin_time, frame_id, result, description)
  		values (v_upgrade_serial, to_char(sysdate, 'yyyy.mm.dd hh24:mi:ss'), i_epgfilesetid, 999, 'upgrading');
  	end;

  	--20131111 liuxp 更新spindex入zxdbm_cms.epgtemplt reserve1字段
  	begin
  		select reserve1 into v_spindex from zxdbm_cms.epgtemplt
  		where epggroup = i_epggroup and rownum=1;
  	exception when no_data_found then
  		rollback;
  		o_result := 3;
        o_desc   := 'epggroup:'||i_epggroup||'not exist';
        return;
  	end;

  	select sp_index into v_cp_spindex from zxdbm_cms.imp_epg_task_info b
  	where task_id=i_taskid;
  	if v_spindex is null then
  		update zxdbm_cms.epgtemplt a set reserve1=
  		(select sp_index from zxdbm_cms.imp_epg_task_info b
  		where task_id=i_taskid and a.epggroup=b.epg_group)
  		where a.epggroup=i_epggroup;
  	elsif v_spindex <> v_cp_spindex then
  		rollback;
  		o_result := 5;
        o_desc   := 'epggroup has no purview to update! '||i_epggroup||':has been conflicted with other cp';
        return;
	end if;

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;

    exception when others then
      rollback;
      o_result := sqlcode;
      o_desc   := substr(sqlerrm, 1, 128);
      return;
end imp_epg_updatetask;
/


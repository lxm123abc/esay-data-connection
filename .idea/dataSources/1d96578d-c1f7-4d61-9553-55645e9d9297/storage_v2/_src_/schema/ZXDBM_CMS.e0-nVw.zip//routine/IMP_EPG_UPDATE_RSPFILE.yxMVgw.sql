create procedure imp_epg_update_rspfile
(
    i_taskid       in number,
    i_rspfileurl   in varchar2,
    o_result       out number,
    o_desc         out varchar2
)
as
    v_tmp_exists		number(4);

begin
  	begin
    	select count(1) into v_tmp_exists from imp_epg_task_info where task_id=i_taskid;
    	if v_tmp_exists=0 then
        	o_result := 1;
        	o_desc   := 'no task with taskid '||i_taskid;
        	return;
    	elsif v_tmp_exists>1 then
        	o_result := 2;
        	o_desc   := 'more than 1 task with taskid '||i_taskid;
        	return;
    	end if;
  	end;

    update imp_epg_task_info
        set notifyxmlurl=i_rspfileurl
        where task_id=i_taskid;

    o_result := 0;
    o_desc   := 'success';
    commit;
    return;

    exception when others then
      rollback;
      o_result := sqlcode;
      o_desc   := substr(sqlerrm, 1, 128);
      return;
end imp_epg_update_rspfile;
/


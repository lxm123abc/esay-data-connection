create procedure           publishedmovie_filedelete
as
  --type define
  type type_number_cms is table of cnt_platform_sync.objectindex%type;
  --declare
  v_isdelete_publishedmovie number(1);
  v_movie_save_days         number(3);
  v_endtime                 char(14);
  v_para                    number(3);
  v_count                   number(3);
  v_movieindex              number(10);
  v_moviefilepath           varchar2(1024);
  v_taskindex               number(10,0);
  v_indexlist               type_number_cms;
begin
  begin
    select to_number(cfgvalue) into v_isdelete_publishedmovie
    from zxdbm_umap.usys_config
    where cfgkey = 'cms.publishedmovie.filedelete.switch';
  exception
    when no_data_found then
      return;
  end;

  --已经发布成功的内容实体文件删除开关为1:关闭，退出
  if(v_isdelete_publishedmovie = 0) then
    return;
  end if;

  begin
    select to_number(cfgvalue) into v_movie_save_days
    from zxdbm_umap.usys_config
    where cfgkey = 'cms.publishedmovie.filesave.days';
  exception
    when no_data_found then
      return;
  end;

  v_endtime := to_char(sysdate - v_movie_save_days, 'yyyymmddhh24miss');

  --查询zxdbm_cms.targetsystem表是否存在状态为正常的2.0的目标系统
  select count(*) into v_para from zxdbm_cms.targetsystem where platform = 1 and status=0;
  if(v_para > 0) then
    --点播内容在2.0,3.0平台需要全部发布成功
    select objectindex bulk collect into v_indexlist from
	      (select objectindex,count(*) as num
		  from zxdbm_cms.cnt_platform_sync
		  where objecttype = 3 and isfiledelete = 0 and status = 300 and publishtime < v_endtime group by objectindex)
		  where num =2 ;
  else
    --点播内容只需在3.0平台发布成功
    select objectindex bulk collect into v_indexlist from zxdbm_cms.cnt_platform_sync
	        where objecttype = 3 and platform = 2 and isfiledelete = 0 and status = 300 and publishtime < v_endtime;
  end if;

  for i in 1..v_indexlist.count
  loop
    select count(*) into v_count from zxdbm_cms.cms_movie where programindex = v_indexlist(i);
	if (v_count > 0) then
	  for c in (select movieindex,fileurl from zxdbm_cms.cms_movie where programindex = v_indexlist(i))
	  loop
	    zxdbm_umap.sp_getmaxvalue('cms_ftptask', 1, v_taskindex);
	    insert into zxdbm_cms.cms_ftptask
        (
          taskindex, tasktype, filetype, fileindex,uploadtype,srcaddress,status,srcfilehandle
        )
        values
        (
          v_taskindex,1,1,c.movieindex,5,c.fileurl,0,0
        );
      end loop;
	  --更新发布记录表中该条数据isfiledelete为1：已删除
	  update zxdbm_cms.cnt_platform_sync set isfiledelete = 1 where objecttype = 3 and objectindex = v_indexlist(i);
	end if;
  end loop;
  commit;
exception
  when others then
    rollback;
end publishedmovie_filedelete;
/


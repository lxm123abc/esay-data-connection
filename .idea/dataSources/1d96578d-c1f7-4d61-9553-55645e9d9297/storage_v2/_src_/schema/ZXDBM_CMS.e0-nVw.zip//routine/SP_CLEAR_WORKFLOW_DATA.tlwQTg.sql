create procedure           sp_clear_workflow_data
  (
    i_objecttype   in number,      --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	i_objectcode   in varchar2,    --对象的文广code
  	o_retcode      out number,     --返回值 0-成功
    o_desc         out varchar2    --结果描述信息
  )
  as
    v_objectindex     number(10,0);
    v_count           number(10,0);
    v_processid       number(10,0);
  begin
    --初始化
    o_retcode:=0;
    o_desc := 'SUCCESS';

    if i_objecttype in (1,3,5,6,7,8) then
      --判断是否为服务
      if i_objecttype = 1 then
        --判断该服务是否处在“审核中”,120-审核中
        select count(1) into v_count from zxdbm_cms.service where servicecode = i_objectcode and status = 120;
        if v_count > 0 then
          --删除处在“审核中”的服务的工单数据
          begin
            select serviceindex into v_objectindex from zxdbm_cms.service where servicecode = i_objectcode and status =120 and rownum =1;
            select process_id into v_processid from jwf.wfw_task where pbo_spec like 'CMS_SERVICE%' and pbo_id= v_objectindex and status ='N' and rownum = 1;
            delete from zxdbm_cms.service_buf where serviceindex = v_objectindex;
            delete from zxdbm_cms.service_wkfwhis where workflowindex = v_processid;
            delete from jwf.wfw_task where process_id = v_processid;
            update zxdbm_cms.service set status = 0,workflow =0,workflowlife=0 where serviceindex = v_objectindex;
          exception
            when others then
              o_retcode := 1;
              o_desc  := 'fail to delete service workflow data; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 128)||']';
              rollback;
              return;
          end;
        else
          o_retcode:=0;
          o_desc := 'service:'||i_objectcode||' is not in workflow';
          return;
        end if;
      --判断是否为点播内容
      elsif (i_objecttype = 3) or (i_objecttype = 7) then
        if i_objecttype = 3 then
          --判断该program是否处在“审核中”,120-一审中,140-二审中,170-三审中
          select count(1) into v_count from zxdbm_cms.cms_program where cpcontentid = i_objectcode and status in (120,140,170);
          if v_count > 0 then
            select programindex into v_objectindex from zxdbm_cms.cms_program where cpcontentid = i_objectcode and status in (120,140,170) and rownum =1;
          else
            o_retcode:=0;
            o_desc := 'program:'||i_objectcode||' is not in workflow';
            return;
          end if;
        elsif i_objecttype = 7 then
          --判断该movie是否处在“审核中”,120-一审中,140-二审中,170-三审中
          select count(1) into v_count from zxdbm_cms.cms_movie where cpcontentid = i_objectcode and status in (120,140,170);
          if v_count > 0 then
            select programindex into v_objectindex from zxdbm_cms.cms_movie where cpcontentid = i_objectcode and status in (120,140,170) and rownum =1;
          else
            o_retcode:=0;
            o_desc := 'movie:'||i_objectcode||' is not in workflow';
            return;
          end if;
        end if;

        begin
        	--删除处在“审核中”的点播内容的工单数据
        	select process_id into v_processid from jwf.wfw_task where pbo_spec like 'CMS_CNT%' and pbo_id= v_objectindex and status ='N' and rownum = 1;
          delete from zxdbm_cms.cms_program_buf where programindex = v_objectindex;
          delete from zxdbm_cms.cms_movie_buf where programindex = v_objectindex;
          delete from zxdbm_cms.cms_program_wkfwhis where workflowindex = v_processid;
          delete from jwf.wfw_task where process_id = v_processid;
          update zxdbm_cms.cms_program set status = 0,workflow =0,workflowlife=0 where programindex = v_objectindex;
          update zxdbm_cms.cms_movie set status = 0 where programindex = v_objectindex;
        exception
        when others then
           o_retcode :=2;
           o_desc  := 'fail to delete program and movie workflow data; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 128)||']';
           rollback;
           return;
        end;
      --判断是否为直播频道
      elsif i_objecttype = 5 or i_objecttype = 8 then
        if i_objecttype = 5 then
          --判断该channel是否处在“审核中”,120-审核中
          select count(1) into v_count from zxdbm_cms.cms_channel where cpcontentid = i_objectcode and status = 120;
          if v_count > 0 then
            select channelindex into v_objectindex from zxdbm_cms.cms_channel where cpcontentid = i_objectcode and status = 120 and rownum =1;
          else
            o_retcode := 0;
            o_desc := 'channel:'||i_objectcode||' is not in workflow';
            return;
          end if;
        elsif i_objecttype = 8 then
          --判断该movie是否处在“审核中”,120-审核中
          select count(1) into v_count from zxdbm_cms.physicalchannel where cpcontentid = i_objectcode and status = 120;
          if v_count > 0 then
            select channelindex into v_objectindex from zxdbm_cms.cms_channel where channelid = (select channelid from zxdbm_cms.physicalchannel where cpcontentid = i_objectcode and status = 120 and rownum =1) and status = 120 and rownum =1;
          else
            o_retcode := 0;
            o_desc := 'physicalchannel:'||i_objectcode||' is not in workflow';
            return;
          end if;
        end if;

        begin
        	--删除处在“审核中”的直播频道的工单数据
        	select process_id into v_processid from jwf.wfw_task where pbo_spec like 'CMS_CHANNEL%' and pbo_id= v_objectindex and status ='N' and rownum = 1;
          delete from zxdbm_cms.cms_channel_buf where channelindex = v_objectindex;
          delete from zxdbm_cms.physicalchannel_buf where channelid = (select channelid from zxdbm_cms.cms_channel where channelindex = v_objectindex and rownum = 1);
          delete from zxdbm_cms.channel_wkfwhis where workflowindex = v_processid;
          delete from jwf.wfw_task where process_id = v_processid;
          update zxdbm_cms.cms_channel set status = 0,workflow =0,workflowlife=0 where channelindex = v_objectindex;
          update zxdbm_cms.physicalchannel set status = 0 where channelid = (select channelid from zxdbm_cms.cms_channel where channelindex = v_objectindex and rownum = 1);
        exception
        when others then
          o_retcode := 3;
          o_desc := 'fail to delete channel and physicalchannel workflow data; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 128)||']';
          rollback;
          return;
        end;
      elsif i_objecttype = 6 then
        --判断该节目单是否处在“审核中”,120-审核中
        select count(1) into v_count from zxdbm_cms.cms_schedule where cpcontentid = i_objectcode and status = 120;
        if v_count > 0 then
          --删除处在“审核中”的节目单的工单数据
          begin
            select scheduleindex into v_objectindex from zxdbm_cms.cms_schedule where cpcontentid = i_objectcode and status =120 and rownum =1;
            select process_id into v_processid from jwf.wfw_task where pbo_spec like 'CMS_SCHEDULE%' and pbo_id= v_objectindex and status ='N' and rownum = 1;
            delete from zxdbm_cms.cms_schedule_buf where scheduleindex = v_objectindex;
            delete from zxdbm_cms.cms_schedule_wkfwhis where workflowindex = v_processid;
            delete from jwf.wfw_task where process_id = v_processid;
            update zxdbm_cms.cms_schedule set status = 0,workflow =0,workflowlife=0 where scheduleindex = v_objectindex;
          exception
          when others then
            o_retcode := 4;
            o_desc := 'fail to delete schedule workflow data; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 128)||']';
            rollback;
            return;
          end;
        else
          o_retcode := 0;
          o_desc := 'schedule:'||i_objectcode||' is not in workflow';
          return;
        end if;
      end if;
    else
      o_retcode := 5;
      o_desc := 'objecttype:'||i_objecttype||' is not right';
      return;
    end if;

    o_retcode := 0;

  exception
  when others then
    o_retcode := 6;
    o_desc := 'ERROR:'||substr(sqlerrm,1,128);
  end sp_clear_workflow_data;
/


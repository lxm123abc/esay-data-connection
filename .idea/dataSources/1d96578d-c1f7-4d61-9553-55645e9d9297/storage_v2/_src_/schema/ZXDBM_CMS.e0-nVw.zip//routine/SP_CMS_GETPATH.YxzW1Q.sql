create procedure           sp_cms_getpath (

                                                  i_storageareatype in zxdbm_cms.cms_storagemanage.storagearea%type,
												  o_retcode   out number,
                                                  o_path            out varchar2) as
  v_spaceid     zxdbm_cms.cms_storagemanage.storageid%type;
  v_deviceid    zxdbm_cms.cms_storagemanage.storageid%type;
  v_deviceindex zxdbm_cms.cms_storagemanage.parentindex%type;
begin

  select storageid, parentindex
    into v_spaceid, v_deviceindex
    from (select a.storageindex,
                 a.parentindex,
                 a.storageid,
                 a.currentcapacity,
                 b.priority,
                 a.status,
                 a.storagearea,
                 a.storagetype
            from cms_storagemanage a, cms_storagemanage b
           where ((a.parentindex = b.storageindex) and
                 (a.storagearea = i_storageareatype) and
                 (a.storagetype = 2)and(a.status=1))
           order by b.priority asc, a.currentcapacity desc)
   where rownum < 2;

  if v_spaceid is null then
  o_retcode := 1;   --no suitable row
  return;
  end if;

  select storageid
    into v_deviceid
    from cms_storagemanage
   where storageindex = v_deviceindex;

  o_path := v_deviceid || '/' || v_spaceid;
  o_retcode := 0;

 exception
   when others then
     o_retcode := sqlcode;
end sp_cms_getpath;
/


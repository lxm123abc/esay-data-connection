create procedure           sp_cms_schedule_delete
as
  v_keepday         number(3, 0);
begin
  v_keepday := 0;
  --query the savetime of schedule
  begin
  	select to_number(cfgvalue) into v_keepday
    from zxdbm_umap.usys_config
    where cfgkey = 'cms.schedule.savetime';
  exception
    when no_data_found then
      -- 默认保留一个月
	  v_keepday := 30;
  end;

   -- 删除发布数据
   delete zxdbm_cms.cnt_target_sync a where exists
    (
    select * from zxdbm_cms.cms_schedule b
    where a.objectid = b.scheduleid
    and startdate < to_char(sysdate-v_keepday,'yyyymmdd')
    )
    and objecttype=6;
   delete zxdbm_cms.cnt_platform_sync a where exists
    (
    select * from zxdbm_cms.cms_schedule b
    where a.objectid = b.scheduleid
    and startdate < to_char(sysdate-v_keepday,'yyyymmdd')
    )
    and objecttype=6;

    -- 删除buf记录及审核历史记录
    delete zxdbm_cms.cms_schedule_wkfwhis a where exists
    (
    select * from zxdbm_cms.cms_schedule b
    where a.scheduleid = b.scheduleid
    and startdate < to_char(sysdate-v_keepday,'yyyymmdd')
    );
    delete zxdbm_cms.cms_schedule_buf a where exists
    (
    select * from zxdbm_cms.cms_schedule b
    where a.scheduleid = b.scheduleid
    and startdate < to_char(sysdate-v_keepday,'yyyymmdd')
    );
    -- 删除过期节目单
    delete zxdbm_cms.cms_schedule where startdate < to_char(sysdate-v_keepday,'yyyymmdd');
    delete zxdbm_cms.cms_schedulerecord a where
    not exists
    (
    select * from zxdbm_cms.cms_schedule b
    where a.scheduleid = b.scheduleid
    );

  commit;
  exception
    when others then
    rollback;
end sp_cms_schedule_delete;
/


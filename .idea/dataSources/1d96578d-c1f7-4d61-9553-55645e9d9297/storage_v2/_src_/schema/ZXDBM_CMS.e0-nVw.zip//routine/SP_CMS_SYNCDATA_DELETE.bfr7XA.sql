create procedure           sp_cms_syncdata_delete
as
  v_datetime        varchar2(14)     := '';
  v_keepmonth       number(3, 0)     := 0;
  v_basenum         number(10)       := 100001;

begin
  --query the savetime of logs
  begin
  	select to_number(cfgvalue) into v_keepmonth
    from zxdbm_umap.usys_config
    where cfgkey = 'cms.syncdata.savetime';
  exception
    when others then
	    return;
  end;

  v_keepmonth := -v_keepmonth;
  v_datetime  := to_char(add_months(sysdate, v_keepmonth), 'yyyymmddhh24miss');

  --delete the table (zxdbm_cms.object_sync_record) 's records
  while (1=1)
  loop
    begin
  	  delete from zxdbm_cms.object_sync_record where taskindex in(select taskindex from zxdbm_cms.cnt_sync_task_his where endtime < v_datetime and endtime is not null) and rownum <v_basenum;
      if (sql%rowcount=0) then
        exit;
      end if;
      commit;
    end;
  end loop;

  --delete the table (zxdbm_cms.cnt_sync_task_his) 's records
  while (1=1)
  loop
    begin
  	  delete from zxdbm_cms.cnt_sync_task_his where endtime < v_datetime and endtime is not null and rownum <v_basenum;
      if (sql%rowcount=0) then
        exit;
      end if;
      commit;
    end;
  end loop;

  --delete the table (zxdbm_cms.cms_ftptask_his) 's records
  while (1=1)
  loop
    begin
  	  delete from zxdbm_cms.cms_ftptask_his where endtime < v_datetime and endtime is not null and rownum <v_basenum;
      if (sql%rowcount=0) then
        exit;
      end if;
      commit;
    end;
  end loop;
  commit;
exception
when others then
    rollback;
end sp_cms_syncdata_delete;
/


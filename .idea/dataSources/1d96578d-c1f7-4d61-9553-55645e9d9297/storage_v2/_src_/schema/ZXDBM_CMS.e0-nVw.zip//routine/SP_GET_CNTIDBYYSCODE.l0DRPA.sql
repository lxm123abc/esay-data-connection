create procedure           sp_get_cntidbyyscode
(
  i_yscode                  in  varchar2,  --yscode,当i_type='CAST'或'CARM'或'SCHERD'时可不填
  i_type                    in  varchar2,  --[M]内容类型：'PROG'-program  'CAST'-cast 'CARM'-castrolemap 'CHAN'-channel  'SCHE'-schedule 'PICT'-picture 'CATE'-category 'SERI'-series 'PACK'-package(serivie) 'MOVI'-movie,'PHYCHAN'-物理频道,'SCHERD'-录制计划
  i_cspid                   in  varchar2,  --[M]内容提供商接口平台编码cspid
  o_telecomcode             out varchar2,  --电信编码（32位）：contentid CPID（8位） + 内容类型编码（8位） + 编号（16位） physicalcontentid:类型标识（2位） + 预留（2位） +CPID（8位）+ 编号（20位）
  o_resultcode              out number,    --结果码：0-成功  -1-失败
  o_resultdesc              out varchar2   --结果描述：o_resultcode为0时为空，o_resultcode为1时为具体的失败描述
)
is
  --declare
  v_cpid          varchar2(8);
  v_content_type  varchar2(8);
  v_config_desc   varchar2(32);
  v_seqno         varchar2(32);
  v_count         number(10);
  --exception
  e_get_cpid_fault    exception;
  e_get_number_fault  exception;
  e_get_cnttype_fault exception;
  e_length_not_32     exception;
begin

  select count(1) into v_count
  from imp_sh_cms_config where  config_type = 10 and config_name = 'CP_IMP_CSPID' and varchar_value = i_cspid;
  if v_count > 0 and i_type not in('CAST','CARM','SCHERD') then
    if length(i_yscode) <> 32 then
       raise e_length_not_32;
    else
      o_telecomcode := i_yscode;
      goto labelB;
    end if;
  end if;

  select count(1) into v_count
  from imp_sh_cms_config where config_type = 4 and config_name like 'CP_IMP_YS_%';

  if v_count > 0 then
    if v_count = 1 then
       select substr(varchar_value,1,8) into v_cpid
       from imp_sh_cms_config where config_type = 4 and config_name like 'CP_IMP_YS_%' and rownum=1;
    else
       select substr(varchar_value,1,8) into v_cpid
       from imp_sh_cms_config where config_type = 4 and config_name like 'CP_IMP_YS_%' and config_desc = i_cspid and rownum=1;
    end if;
  else
    raise e_get_cpid_fault;
  end if;

  if (i_type in ('PROG','PICT','CATE','SERI','PACK','CHAN','CAST','CARM','SCHE')) then
    begin
      select substr(varchar_value,0,8), config_desc into v_content_type, v_config_desc
      from zxdbm_cms.imp_sh_cms_config where config_type=1 and config_name=upper(i_type) and rownum=1;
    exception
      when others then
      raise e_get_cnttype_fault;
    end;

    zxdbm_umap.sp_getmaxvalue(v_config_desc, 1, v_seqno);
    if (v_seqno = 0) then
      raise e_get_number_fault;
    end if;
    --3.0ContentID（32位）＝COPID（8位）+内容类型（8位）+编号（16位）
    o_telecomcode := lpad(v_cpid,8,'0')||lpad(v_content_type,8,'0')||lpad(v_seqno,16,'0');
  else
    begin
      select substr(varchar_value,0,2), config_desc into v_content_type, v_config_desc
      from zxdbm_cms.imp_sh_cms_config where config_type=3 and config_name=upper(i_type) and rownum=1;
    exception
      when others then
      raise e_get_cnttype_fault;
    end;
    zxdbm_umap.sp_getmaxvalue(v_config_desc, 1, v_seqno);
    if (v_seqno = 0) then
      raise e_get_number_fault;
    end if;
    --3.0Physicalcontentid（32位）=Type+ Reserved+cpid+编号
    o_telecomcode := v_content_type||'00'||v_cpid||lpad(v_seqno,20,'0');
  end if;

  <<labelB>>
  o_resultcode := 0;
  o_resultdesc  := '';

exception
  when e_length_not_32  then
    o_telecomcode := i_yscode;
    o_resultcode := -1;
    o_resultdesc  := 'the length of code is not equal 32';
  when e_get_cpid_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode fault:get cpid failed';
  when e_get_number_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode fault:get content sequence failed';
  when e_get_cnttype_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode fault:get content type failed';
  when others then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := substr(sqlerrm, 1, 80);
end sp_get_cntidbyyscode;
/


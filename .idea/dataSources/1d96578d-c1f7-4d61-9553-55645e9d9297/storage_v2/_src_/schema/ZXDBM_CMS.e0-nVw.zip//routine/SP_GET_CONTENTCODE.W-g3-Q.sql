create procedure           sp_get_contentcode
(
  i_prefix       in  varchar2,  --[M].
  i_cpid         in  varchar2,  --[M].cp id.
  i_type         in  varchar2,  --[M].'PROG','',...
  o_telecomcode  out varchar2
)
is
  v_prefix   char(5) := '00000';
  v_cpid     char(8) := '00000000';
  v_element  char(8) := '00000000';
  v_seq      number(10);
  v_config_desc  varchar2(30);
begin
  --o_telecomcode := v_prefix + v_cpindex + v_element + v_seq
  begin
    select varchar_value, config_desc into v_element, v_config_desc from zxdbm_cms.imp_sh_cms_config where config_type = 1 and config_name = upper(i_type);
  exception
    when others then
      v_element := '00000000';
      v_config_desc := 'cms_content_defaultindex';
  end;

  v_prefix := lpad(i_prefix, 5, '0');
  v_cpid := lpad(nvl(i_cpid,'0'), 8, '0');

  zxdbm_umap.sp_getmaxvalue(v_config_desc, 1, v_seq );

  o_telecomcode := v_prefix || v_cpid || v_element || lpad(v_seq, 8, '0')||'001';

exception when others then
  o_telecomcode := '0';
end sp_get_contentcode;
/


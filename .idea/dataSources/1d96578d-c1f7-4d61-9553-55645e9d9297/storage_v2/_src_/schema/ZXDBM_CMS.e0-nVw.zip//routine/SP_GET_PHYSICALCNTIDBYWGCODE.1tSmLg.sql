create procedure           sp_get_physicalcntidbywgcode
(
  i_wgcode                  in  varchar2,  --[M].wgcode=Umai：内容类型/编号@BESTV.SMG.SMG 或Umai：内容类型/编号@BESTV.STA.SMG 或者Umai：内容类型/1234.root
  i_type                    in  varchar2,  --内容类型：'MOVI'-movie  'PHCH'-physicalchannel 'SCHERD'-schedulerecord
  i_cspid                   in  varchar2,  --内容提供商接口平台编码cspid
  o_telecomcode             out varchar2,  --电信编码（32位）：类型标识（2位） + 预留（2位） +CPID（8位）+ 编号（20位）
  o_resultcode              out number,    --结果码：0-成功  -1-失败
  o_resultdesc              out varchar2   --结果描述：o_resultcode为0时为空，o_resultcode为1时为具体的失败描述
)
is
  --type define
  type type_varchar_value is table of imp_sh_cms_config.varchar_value%type;
  type type_config_desc is table of imp_sh_cms_config.config_desc%type;
  --declare
  v_varchar_value type_varchar_value;
  v_config_desc   type_config_desc;
  v_cpid          varchar2(8);
  v_content_type  varchar2(8);
  v_type          varchar2(10);
  v_no            varchar2(32);
  v_reserve       varchar2(2) := '00';
  v_count         number(10);
  --exception
  e_get_cpid_fault    exception;
  e_get_number_fault  exception;
  e_get_cnttype_fault exception;
  e_length_not_32     exception;
begin

  select count(1) into v_count
  from imp_sh_cms_config where  config_type = 10 and config_name = 'CP_IMP_CSPID' and varchar_value = i_cspid;
  if v_count > 0 then
    if length(i_wgcode) <> 32 then
       raise e_length_not_32;
    else
      o_telecomcode := i_wgcode;
      goto labelB;
    end if;
  end if;

  begin
    select upper(varchar_value), upper(config_desc) bulk collect
      into v_varchar_value, v_config_desc
      from imp_sh_cms_config
     where config_type = 4 and config_name like 'CP_IMP_CODE_%'
       and config_desc <> 'TO_NUMBER';
  exception
    when others then
      null;
  end;

  if v_config_desc.count > 0 then
    for i in v_config_desc.first .. v_config_desc.last loop

      if instr(upper(i_wgcode), v_config_desc(i)) <> 0 and
         (instr(upper(i_wgcode), v_config_desc(i)) +
          length(v_config_desc(i)) - 1 = length(i_wgcode)) then
        -- COPID
        v_cpid := v_varchar_value(i);
        v_type  := upper(i_type);
        v_no    := substr(i_wgcode,
                          instr(i_wgcode, '/') + 1,
                          instr(upper(i_wgcode), v_config_desc(i)) -
                          instr(i_wgcode, '/') - 1);

        goto labelA;
      end if;
    end loop;
  end if;

  begin
    select substr(varchar_value, 1, 8)
      into v_cpid
      from imp_sh_cms_config
     where config_type = 4 and config_name like 'CP_IMP_CODE_%'
       and config_desc = 'TO_NUMBER';

    v_no   := to_number(i_wgcode);
    v_type := upper(i_type);

  exception
    when others then
      raise e_get_cpid_fault;
  end;

  <<labelA>>
  if v_no is null then
    raise e_get_number_fault;
  end if;

  begin
    select varchar_value
      into v_content_type
      from imp_sh_cms_config
     where config_type = 3 and upper(config_name) = v_type
       and rownum = 1;
  exception
    when no_data_found then
      raise e_get_cnttype_fault;
  end;

  select lpad(reverse(substr(reverse(v_no),1,20)),20,'0') into v_no from dual;
  o_telecomcode := substr(v_content_type, 1, 2) || substr(v_reserve, 1, 2)|| substr(v_cpid, 1, 8) || v_no;

  <<labelB>>
  o_resultcode := 0;
  o_resultdesc  := '';

exception
  when e_get_cpid_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode(physicalcontentid) fault:get cpid failed';
  when e_get_number_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode(physicalcontentid) fault:get content sequence failed';
  when e_get_cnttype_fault then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := 'get telecode(physicalcontentid) fault:get content type failed';
  when e_length_not_32  then
    o_telecomcode := i_wgcode;
    o_resultcode := -1;
    o_resultdesc  := 'the length of code is not equal 32';
  when others then
    o_telecomcode := '0';
    o_resultcode := -1;
    o_resultdesc  := substr(sqlerrm, 1, 80);
end sp_get_physicalcntidbywgcode;
/


create procedure           sp_get_physicalcontentid
(
  i_type         in  varchar2,  --[M].'MOVI'-movie,'PHYCHAN'-物理频道,'SCHERECORD'-录制计划
  o_telecomcode  out varchar2
)
is
  v_reserve  char(2) := '00';
  v_element  char(2) := '00';
  v_seq      number(10);
  v_config_desc  varchar2(255);
begin
  --o_telecomcode := v_type + i_reserve + v_seq
  begin
    select substr(varchar_value,0,2), config_desc into v_element, v_config_desc from zxdbm_cms.imp_sh_cms_config where config_type = 3 and config_name = upper(i_type);
  exception
    when others then
      v_element := '00';
      v_config_desc := 'cms_content_defaultindex';
  end;

  zxdbm_umap.sp_getmaxvalue(v_config_desc, 1, v_seq );

  o_telecomcode := v_element || v_reserve || lpad(v_seq, 28, '0');

exception when others then
  o_telecomcode := '0';
end sp_get_physicalcontentid;
/


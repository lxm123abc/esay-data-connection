create procedure           sp_get_wgcodebycntid
(
  i_contentid    in  varchar2,  --[M].ContentID＝COPID+内容类型+编号
  o_wgcode       out varchar2
)
is
  v_cpid         char(8) := '00000001';  --文广CPID=00000001
  v_element      char(8);
  v_seq          char(10);
  v_config_name  char(8);
  v_config_desc  varchar2(255);
begin

  begin
  	select substr(varchar_value,0,8) into v_cpid from zxdbm_cms.imp_sh_cms_config where config_type = 4 and config_name = 'CP_CMS';
  	exception
    when others then
      v_cpid := '99999999';
  end;
  begin
    select substr(i_contentid,9,8),ltrim(substr(i_contentid,17),'0') into v_element,v_seq from dual;
    select substr(config_name,0,6) into v_config_name from zxdbm_cms.imp_sh_cms_config where config_type = 1 and varchar_value = upper(v_element);
  exception
    when others then
      v_config_name := 'null';
      zxdbm_umap.sp_getmaxvalue('cms_content_defaultindex', 1, v_seq );
  end;
  begin
    select config_desc into v_config_desc from zxdbm_cms.imp_sh_cms_config where config_type = 4 and varchar_value = upper(v_cpid);
  exception
    when others then
      v_config_desc := '@ZTE.COM.CN';
  end;
  o_wgcode := 'Umai:'||trim(v_config_name)||'/'||trim(v_seq)||trim(v_config_desc);
exception when others then
  o_wgcode := '0';
end sp_get_wgcodebycntid;
/


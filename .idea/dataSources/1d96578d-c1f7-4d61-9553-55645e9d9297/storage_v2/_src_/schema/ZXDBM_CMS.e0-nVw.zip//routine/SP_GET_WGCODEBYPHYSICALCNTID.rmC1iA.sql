create procedure           sp_get_wgcodebyphysicalcntid
(
  i_physicalcontentid    in  varchar2,  --[M].physicalcontentid＝Type+Reserve+编号
  o_wgcode               out varchar2
)
is
  v_element      char(2);
  v_seq          char(28);
  v_config_name  char(8);
  v_config_desc  varchar2(255);
begin

  begin
    select substr(i_physicalcontentid,0,2),ltrim(substr(i_physicalcontentid,5),'0') into v_element,v_seq from dual;
    select substr(config_name,0,6) into v_config_name from zxdbm_cms.imp_sh_cms_config where config_type = 3 and varchar_value = upper(v_element);
    select config_desc into v_config_desc from zxdbm_cms.imp_sh_cms_config where config_type = 4 and config_name = 'CP_CMS';
  exception
    when others then
      v_config_name := 'null';
      v_config_desc := '@ZTE.COM.CN';
      zxdbm_umap.sp_getmaxvalue('cms_content_defaultindex', 1, v_seq );
  end;
  o_wgcode := 'Umai:'||trim(v_config_name)||'/'||trim(v_seq)||trim(v_config_desc);
exception when others then
  o_wgcode := '0';
end sp_get_wgcodebyphysicalcntid;
/


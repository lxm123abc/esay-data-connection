create procedure           sp_imp313_update_splitinfo
(
	i_taskindex		in		number,
  i_resultinfo  in    varchar2,
  i_resulttype  in    number,
  o_retcode    out    number,
  o_retdesc    out    varchar2,
  o_destaddress out   varchar2  --success return
)
as
  v_taskcount    number(10);
begin
  -- 变量初始化
  o_retcode  := 0;
  o_retdesc  := 'success';
  v_taskcount  := 0;

  -- 参数检查
  if i_taskindex = 0 then
    o_retcode  := 710;
    o_retdesc  := 'param error;taskindex['||i_taskindex||']';
    return;
  end if;

  -- 查找任务是否存在
  select count(*) into v_taskcount from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
  if v_taskcount = 0 then
    o_retcode  := 711;
    o_retdesc  := 'can not find the ingest task;taskindex['||i_taskindex||']';
    return;
  end if;

  -- 更新任务信息
  if i_resulttype = 0 then
    begin
      update zxdbm_cms.cms_splittask
      set status = 3, endtime = to_char(sysdate, 'yyyymmddhh24miss'), rtnresult = i_resultinfo, rtncode = i_resulttype
      where taskindex = i_taskindex returning destaddress into o_destaddress;
      --insert into his
      insert into zxdbm_cms.cms_splittask_his select * from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
      delete from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
    exception
      when others then
        o_retcode  := 712;
        o_retdesc  := 'callback msg return success, fail to update ingest task info; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
        rollback;
        return;
    end;
  -- 结果失败
  else
    begin
      update zxdbm_cms.cms_splittask
      set status = 4, endtime = to_char(sysdate, 'yyyymmddhh24miss'), rtnresult = i_resultinfo, rtncode = i_resulttype
      where taskindex = i_taskindex;
      --insert into his
      insert into zxdbm_cms.cms_splittask_his select * from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
      delete from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
    exception
      when others then
        o_retcode  := 713;
        o_retdesc  := 'callback msg return failed, fail to update ingest task info; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
        rollback;
        return;
    end;

    o_retcode  := 2;
    o_retdesc  := 'callback msg return failed';

  end if;

--  begin
--    update zxdbm_cms.imp_ingest_callback_task
--    set status = 3 where taskindex = i_taskindex;
--  exception
--    when others then
--      o_retcode  := 714;
--        o_retdesc  := 'fail to update callback task status; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
--        rollback;
--        return;
--  end;


  commit;
  return;

end sp_imp313_update_splitinfo;
/


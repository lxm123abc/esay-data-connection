create procedure           sp_imp313_update_splitstatus
(
	i_taskindex		in		number,
  i_result    in    number,
  i_resultinfo  in    varchar2,
  o_retcode    out    number,
  o_retdesc    out    varchar2
)
as
  v_taskcount    number(10);
begin
  -- 参数初始化
  o_retcode  := 0;
  o_retdesc  := 'success';
  v_taskcount  := 0;

  -- 入参检查
  if i_taskindex = 0 then
    o_retcode  := 701;
    o_retdesc  := 'param error: taskindex['||i_taskindex||']';
    return;
  end if;

  -- 查询该任务是否存在
  select count(*) into v_taskcount from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
  if v_taskcount = 0 then
    o_retcode  := 702;
    o_retdesc  := 'can not find the task from cms_ingesttask: taskindex['||i_taskindex||']';
    return;
  end if;

  -- 根据结果更新任务状态 1-待执行 2-执行中 3-成功结束 4-失败结束
  if i_result = 2 then
    begin
      update zxdbm_cms.cms_splittask set status = i_result, starttime = to_char(sysdate, 'yyyymmddhh24miss') where taskindex = i_taskindex;
    exception
      when others then
        o_retcode  := 703;
        o_retdesc  := 'fail to update ingesttask status as excecuting; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
        rollback;
        return;
    end;
  -- 结果成功 no used
  elsif i_result = 0 then
    begin
      update zxdbm_cms.cms_splittask set status = 3, endtime = to_char(sysdate, 'yyyymmddhh24miss'), rtncode = i_result, rtnresult = i_resultinfo where taskindex = i_taskindex;
      --insert into his
      insert into zxdbm_cms.cms_splittask_his select * from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
      delete from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
    exception
      when others then
        o_retcode  := 704;
        o_retdesc  := 'fail to update ingesttask status as success; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
        rollback;
        return;
    end;
  -- 结果失败
  else
    begin
      update zxdbm_cms.cms_splittask set status = 4, endtime = to_char(sysdate, 'yyyymmddhh24miss'), rtncode = i_result, rtnresult = i_resultinfo where taskindex = i_taskindex;
      --insert into his
      insert into zxdbm_cms.cms_splittask_his select * from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
      delete from zxdbm_cms.cms_splittask where taskindex = i_taskindex;
    exception
      when others then
        o_retcode  := 705;
        o_retdesc  := 'fail to update ingesttask status as failed; sqlcode['||sqlcode||'];sqlerrm['||substr(sqlerrm, 64)||']';
        rollback;
        return;
    end;
  end if;

  commit;
  return;

end sp_imp313_update_splitstatus;
/


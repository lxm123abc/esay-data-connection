create procedure           sp_imp329_object_delete_timely
(
  i_taskindex    in  number
)
as
  v_taskindex     number(10);
  systime    varchar2(14);
  v_retcode      number(10);
  v_desc         varchar2(255);
  v_logindex     number(10);
begin
	systime := to_char(sysdate,'yyyymmddhh24miss');
    v_taskindex := 0;

    begin
      --program-3 start
      --根据对象日志结果判定，根据target无法删除program，源于movie决定cdn的发布状态
      --zxdbm_cms.sp_imp329_program_delete(i_taskindex,o_retcode,o_retdesc);
      --删除program-movie-32
      update zxdbm_cms.cms_movie q
      set mappingid=null,programindex=null,programid=null
      where exists
      (
      select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and q.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.program_crm_map map
      where exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-program-35
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=35 and exists
      (
      select * from zxdbm_cms.program_picture_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=35 and exists
      (
      select * from zxdbm_cms.program_picture_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.program_picture_map map
      where exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --category-program-26
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=26 and exists
      (
      select * from zxdbm_cms.category_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=26 and exists
      (
      select * from zxdbm_cms.category_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_program_map map
      where exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-program-36
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=36 and exists
      (
      select * from zxdbm_cms.series_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=36 and exists
      (
      select * from zxdbm_cms.series_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_program_map map
      where exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-program-21
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=21 and exists
      (
      select * from zxdbm_cms.service_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=21 and exists
      (
      select * from zxdbm_cms.service_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_program_map map
      where exists
      (select * from zxdbm_cms.cms_program m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.programindex=m.programindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct prog.cpcontentid
                from zxdbm_cms.cms_program prog
                where exists
                (select * from zxdbm_cms.object_cpcnt_record n
                 where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
                 and prog.cpcontentid=n.objectcode
                 and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
                 and (n.retcode_30=0 or n.retcode_30 is null)
--                 and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
               ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         3,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除program正式表
      --将删除的program移至del临时表记录
      --20140222 liuxp cpcontentid 有唯一索引 保证多次删除时 del表中数据正确
      delete from zxdbm_cms.cms_program_del m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cms_program t
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode and n.objectcode=t.cpcontentid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      insert into zxdbm_cms.cms_program_del
      select * from zxdbm_cms.cms_program m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cms_program m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      --20140401 liuxp objectid objecttype 有唯一 保证多次删除时 del表中数据正确
      delete from zxdbm_cms.cnt_platform_sync_del m
      where exists
      (
      select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cnt_platform_sync t
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and m.objectid=n.objectid and n.objectid=t.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ) and m.objecttype=3;

      --将删除program的发布数据移至平台del临时表记录
      insert into zxdbm_cms.cnt_platform_sync_del
      select * from zxdbm_cms.cnt_platform_sync p
      where objecttype=3 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=3 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=3 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=3 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'program delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --program-3 end

    --删除游离的movie ==
    for n in
    (
    	select movieindex,programindex,fileurl,cpcontentid
    	from zxdbm_cms.cms_movie
    	where reservesel1=1
    )
    loop
    	if n.programindex is not null then
    		null;
    	else
    		-- insert into ftptask
    		zxdbm_umap.sp_getmaxvalue('cms_ftptask', 1, v_taskindex);
    		if v_taskindex <> 0 then
      			begin
      				insert into zxdbm_cms.cms_ftptask
        			(taskindex, tasktype, filetype, fileindex,uploadtype,srcaddress,status,srcfilehandle)
        			values
        			(v_taskindex,1,1,n.movieindex,5,n.fileurl,0,0);

        		    --将删除movie移至del临时表记录
        		    --20140222 liuxp cpcontentid 有唯一索引
        		    delete from zxdbm_cms.cms_movie_del m
        		    where exists
        		    (select * from zxdbm_cms.cms_movie n where m.cpcontentid=n.cpcontentid);
        		    insert into zxdbm_cms.cms_movie_del
        		    select * from zxdbm_cms.cms_movie where movieindex=n.movieindex;
        			-- delete data
        			delete from zxdbm_cms.cms_movie where movieindex=n.movieindex;
        		exception
    				when others then
    					null;
    			end;
    		end if;
    	end if;
    	commit;
	end loop;
	commit;

    begin
      --package-1 start
      --zxdbm_cms.sp_imp329_package_delete(i_taskindex,o_retcode,o_retdesc);
      --删除package-program-21
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=21 and exists
      (
      select * from zxdbm_cms.service_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=21 and exists
      (
      select * from zxdbm_cms.service_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_program_map map
      where exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-series-22
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=22 and exists
      (
      select * from zxdbm_cms.service_series_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=22 and exists
      (
      select * from zxdbm_cms.service_series_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_series_map map
      where exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-channel-23
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=23 and exists
      (
      select * from zxdbm_cms.service_channel_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=23 and exists
      (
      select * from zxdbm_cms.service_channel_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_channel_map map
      where exists
      (select * from zxdbm_cms.service m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and map.serviceindex=m.serviceindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in(
               select distinct s.servicecode
               from zxdbm_cms.service s
               where exists
               (select * from zxdbm_cms.object_cpcnt_record n
               where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
               and s.servicecode=n.objectcode
               and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
              ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         1,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.servicecode,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除package正式表记录
      --将删除package移至del临时表记录
      --20140222 liuxp cpcontentid 有唯一索引
      delete from zxdbm_cms.service_del m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.service t
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode and n.objectcode=t.servicecode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      insert into zxdbm_cms.service_del
      select * from zxdbm_cms.service m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.service m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.servicecode=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      --20140401 liuxp objectid objecttype 有唯一 保证多次删除时 del表中数据正确
      delete from zxdbm_cms.cnt_platform_sync_del m
      where exists
      (
      select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cnt_platform_sync t
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and m.objectid=n.objectid and n.objectid=t.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ) and m.objecttype=1;

      --将删除package的发布数据移至del临时表记录
      insert into zxdbm_cms.cnt_platform_sync_del
      select * from zxdbm_cms.cnt_platform_sync p
      where objecttype=1 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=1 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=1 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=1 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'package delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --package-1 end

    begin
      --category-2 start
      --zxdbm_cms.sp_imp329_category_delete(i_taskindex,o_retcode,o_retdesc);
      --删除category-program-26
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=26 and exists
      (
      select * from zxdbm_cms.category_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=26 and exists
      (
      select * from zxdbm_cms.category_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_program_map map
      where exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-series-27
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=27 and exists
      (
      select * from zxdbm_cms.category_series_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=27 and exists
      (
      select * from zxdbm_cms.category_series_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_series_map map
      where exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-channel-28
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=28 and exists
      (
      select * from zxdbm_cms.category_channel_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=28 and exists
      (
      select * from zxdbm_cms.category_channel_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_channel_map map
      where exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-category-31
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=31 and exists
      (
      select * from zxdbm_cms.category_picture_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=31 and exists
      (
      select * from zxdbm_cms.category_picture_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_picture_map map
      where exists
      (select * from zxdbm_cms.categorycdn m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode and map.categoryindex=m.categoryindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category正式表记录
      delete from zxdbm_cms.categorycdn m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and m.catagorycode=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=2 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=2 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=2 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'category delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --category-2 end

    begin
      --series-4 start
      --zxdbm_cms.sp_imp329_series_delete(i_taskindex,o_retcode,o_retdesc);
      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_crm_map map
      where exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-series-38
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=38 and exists
      (
      select * from zxdbm_cms.series_picture_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=38 and exists
      (
      select * from zxdbm_cms.series_picture_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_picture_map map
      where exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-series-27
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=27 and exists
      (
      select * from zxdbm_cms.category_series_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=27 and exists
      (
      select * from zxdbm_cms.category_series_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_series_map map
      where exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-series-22
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=22 and exists
      (
      select * from zxdbm_cms.service_series_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=22 and exists
      (
      select * from zxdbm_cms.service_series_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_series_map map
      where exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-program-36
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=36 and exists
      (
      select * from zxdbm_cms.series_program_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=36 and exists
      (
      select * from zxdbm_cms.series_program_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_program_map map
      where exists
      (select * from zxdbm_cms.cms_series m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.seriesindex=m.seriesindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series正式表记录
      --将删除series移至del临时表记录
      --20140222 liuxp cpcontentid 有唯一索引
      delete from zxdbm_cms.cms_series_del m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cms_series t
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode and n.objectcode=t.cpcontentid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      insert into zxdbm_cms.cms_series_del
      select * from zxdbm_cms.cms_series m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cms_series m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      --20140401 liuxp objectid objecttype 有唯一 保证多次删除时 del表中数据正确
      delete from zxdbm_cms.cnt_platform_sync_del m
      where exists
      (
      select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cnt_platform_sync t
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and m.objectid=n.objectid and n.objectid=t.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ) and m.objecttype=4;

      --将删除series的发布数据移至del临时表记录
      insert into zxdbm_cms.cnt_platform_sync_del
      select * from zxdbm_cms.cnt_platform_sync p
      where objecttype=4 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=4 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=4 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=4 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'series delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --series-4 end

    begin
      --channel-5 start
      --根据对象日志结果判定，根据target无法删除channel，源于phy决定cdn的发布状态
      --zxdbm_cms.sp_imp329_channel_delete(i_taskindex,o_retcode,o_retdesc);
      --删除picture-channel-39
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=39 and exists
      (
      select * from zxdbm_cms.channel_picture_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=39 and exists
      (
      select * from zxdbm_cms.channel_picture_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.channel_picture_map map
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-channel-28
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=28 and exists
      (
      select * from zxdbm_cms.category_channel_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=28 and exists
      (
      select * from zxdbm_cms.category_channel_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.category_channel_map map
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-channel-23
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=23 and exists
      (
      select * from zxdbm_cms.service_channel_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=23 and exists
      (
      select * from zxdbm_cms.service_channel_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.service_channel_map map
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and map.channelindex=m.channelindex
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除schedulerecord
      delete from zxdbm_cms.cms_schedulerecord  sr
      where exists
      (
      select * from zxdbm_cms.cms_schedule sch
      where sr.scheduleid=sch.scheduleid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and sch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));
      commit;

      --删除工作流
      for m in (
                select distinct sch.cpcontentid
                from zxdbm_cms.cms_schedule sch
                where exists
                (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
                where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
                and m.cpcontentid=n.objectcode and sch.channelid=m.channelid
                and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
                and (n.retcode_30=0 or n.retcode_30 is null)
--                and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
               ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         6,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除schedule-6
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=6 and exists
      (select * from zxdbm_cms.cms_schedule sch
      where cps.objectid=sch.scheduleid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and sch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=6 and exists
      (select * from zxdbm_cms.cms_schedule sch
      where cts.objectid=sch.scheduleid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and sch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cms_schedule sch
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and sch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除physicalchannel
      --将删除physicalchannel移至del临时表记录
      --20140222 liuxp cpcontentid 有唯一索引
      delete from zxdbm_cms.physicalchannel_del ph
      where exists
      (select * from zxdbm_cms.physicalchannel phch
      where ph.cpcontentid=phch.cpcontentid
      and exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and phch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));
      insert into zxdbm_cms.physicalchannel_del
      select * from zxdbm_cms.physicalchannel phch
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and phch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.physicalchannel phch
      where exists
      (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and phch.channelid=m.channelid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct phch.cpcontentid
                from zxdbm_cms.physicalchannel phch
                where exists
                (select * from zxdbm_cms.cms_channel m,zxdbm_cms.object_cpcnt_record n
                where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
                and m.cpcontentid=n.objectcode and phch.channelid=m.channelid
                and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
                and (n.retcode_30=0 or n.retcode_30 is null)
--                and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
               ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         8,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除工作流
      for m in (
                select distinct m.cpcontentid
                from zxdbm_cms.cms_channel m
                where exists
                (select * from zxdbm_cms.object_cpcnt_record n
                where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
                and m.cpcontentid=n.objectcode
                and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
                and (n.retcode_30=0 or n.retcode_30 is null)
--                and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
               ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         5,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除channel正式表记录
      --将删除channel移至del临时表记录
      --20140222 liuxp cpcontentid 有唯一索引
      delete from zxdbm_cms.cms_channel_del m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cms_channel t
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode and n.objectcode=t.cpcontentid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      insert into zxdbm_cms.cms_channel_del
      select * from zxdbm_cms.cms_channel m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cms_channel m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      --20140401 liuxp objectid objecttype 有唯一 保证多次删除时 del表中数据正确
      delete from zxdbm_cms.cnt_platform_sync_del m
      where exists
      (
      select * from zxdbm_cms.object_cpcnt_record n, zxdbm_cms.cnt_platform_sync t
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and m.objectid=n.objectid and n.objectid=t.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ) and m.objecttype=5;

      --将删除channel的发布数据移至del临时表记录
      insert into zxdbm_cms.cnt_platform_sync_del
      select * from zxdbm_cms.cnt_platform_sync p
      where objecttype=5 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=5 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=5 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=5 and n.actiontype=3
      and p.objectid=n.objectid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
--      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'channel delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --channel-5 end

    begin
      --schedule-6 start
      --zxdbm_cms.sp_imp329_schedule_delete(i_taskindex,o_retcode,o_retdesc);

      --删除schedulerecord
      delete from zxdbm_cms.cms_schedulerecord  sr
      where exists
      (select * from zxdbm_cms.cms_schedule m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=6 and n.actiontype=3
      and m.cpcontentid=n.objectcode and sr.scheduleid=m.scheduleid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct m.cpcontentid
                from zxdbm_cms.cms_schedule m
                where exists
                (select * from zxdbm_cms.object_cpcnt_record n
                where n.taskindex=i_taskindex and n.objecttype=6 and n.actiontype=3
                and m.cpcontentid=n.objectcode
                and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
                ))
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         6,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除schedule正式表记录
      delete from zxdbm_cms.cms_schedule m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=6 and n.actiontype=3
      and m.cpcontentid=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=6 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=6 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=6 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=6 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'schedule delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --schedule-6 end

    begin
      --mapping start
      --zxdbm_cms.sp_imp329_mapping_delete(i_taskindex,o_retcode,o_retdesc);
      --package-program-21
      delete from zxdbm_cms.service_program_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=21 and n.actiontype=3
      and map.serviceid=n.parentid and map.programid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=21 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=21 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=21 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=21 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --package-series-22
      delete from zxdbm_cms.service_series_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=22 and n.actiontype=3
      and map.serviceid=n.parentid and map.seriesid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=22 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=22 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=22 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=22 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --package-channel-23
      delete from zxdbm_cms.service_channel_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=23 and n.actiontype=3
      and map.serviceid=n.parentid and map.channelid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=23 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=23 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=23 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=23 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --category-program-26
      delete from zxdbm_cms.category_program_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=26 and n.actiontype=3
      and map.categoryid=n.parentid and map.programid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=26 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=26 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=26 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=26 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --category-series-27
      delete from zxdbm_cms.category_series_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=27 and n.actiontype=3
      and map.categoryid=n.parentid and map.seriesid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=27 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=27 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=27 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=27 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --category-channel-28
      delete from zxdbm_cms.category_channel_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=28 and n.actiontype=3
      and map.categoryid=n.parentid and map.channelid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=28 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=28 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=28 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=28 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --picture-category-31
      delete from zxdbm_cms.category_picture_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=31 and n.actiontype=3
      and map.pictureid=n.parentid and map.categoryid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=31 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=31 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=31 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=31 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --program-castrolemap-34
      delete from zxdbm_cms.program_crm_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=34 and n.actiontype=3
      and map.programid=n.parentid and map.castrolemapid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=34 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=34 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=34 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=34 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --picture-program-35
      delete from zxdbm_cms.program_picture_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=35 and n.actiontype=3
      and map.pictureid=n.parentid and map.programid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=35 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=35 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=35 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=35 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --series-program-36
      delete from zxdbm_cms.series_program_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=36 and n.actiontype=3
      and map.seriesid=n.parentid and map.programid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=36 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=36 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=36 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=36 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --series-castrolemap-37
      delete from zxdbm_cms.series_crm_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=37 and n.actiontype=3
      and map.seriesid=n.parentid and map.castrolemapid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=37 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=37 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=37 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=37 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --picture-series-38
      delete from zxdbm_cms.series_picture_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=38 and n.actiontype=3
      and map.pictureid=n.parentid and map.seriesid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=38 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=38 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=38 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=38 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --picture-channel-39
      delete from zxdbm_cms.channel_picture_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=39 and n.actiontype=3
      and map.pictureid=n.parentid and map.channelid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=39 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=39 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=39 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=39 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
      --picture-cast-41
      delete from zxdbm_cms.cast_picture_map map
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=41 and n.actiontype=3
      and map.pictureid=n.parentid and map.castid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=41 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=41 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=41 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=41 and n.actiontype=3
      and p.parentid=n.parentid and p.elementid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.parentid=t.parentid and n.objectid=t.objectid and t.status<>0)
      );
      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'mapping delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --mapping end

    begin
      --castrolemap-12 start
      --zxdbm_cms.sp_imp329_castrolemap_delete(i_taskindex,o_retcode,o_retdesc);
      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.program_crm_map map
      where exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_crm_map map
      where exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除castrolemap正式表-12
      delete from zxdbm_cms.castrolemap m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and m.castrolemapcode=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=12 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=12 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=12 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'castrolemap delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --castrolemap-12 end

    begin
      --cast-11 start
      --zxdbm_cms.sp_imp329_cast_delete(i_taskindex,o_retcode,o_retdesc);
      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
      select * from zxdbm_cms.program_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.program_crm_map map
      where exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and /*m.castid=n.objectid*/n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cps.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
      select * from zxdbm_cms.series_crm_map map
      where cts.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      ));

      delete from zxdbm_cms.series_crm_map map
      where exists
      (select * from zxdbm_cms.castrolemap m,zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castcdn s
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and /*m.castid=n.objectid*/n.objectcode=s.castcode and m.castid=s.castid and map.castrolemapindex=m.castrolemapindex
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除castrolemap-12
      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=12 and exists
      (select * from zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castrolemap m
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and m.castid=n.objectid and p.objectid=m.castrolemapid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=12 and exists
      (select * from zxdbm_cms.object_cpcnt_record n,zxdbm_cms.castrolemap m
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and m.castid=n.objectid and p.objectid=m.castrolemapid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.castrolemap m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and m.castid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除cast正式表-11
      delete from zxdbm_cms.castcdn m
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and m.castcode=n.objectcode
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=11 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_target_sync p
      where objecttype=11 and exists
      (select * from zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=11 and n.actiontype=3
      and p.objectid=n.objectid
      and not exists (select * from zxdbm_cms.cnt_target_sync t where n.objectid=t.objectid and t.status<>0)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'cast delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --cast-11 end

    begin
      --picture-10 start
      --zxdbm_cms.sp_imp329_picture_delete(i_taskindex,o_retcode,o_retdesc);
      --picture没有发布状态，根据对象日志处理结果进行删除
      --picture的删除，要删对应的mapping 根据下游结果进行处理
      --picture-program-35
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=35 and exists
      (select * from zxdbm_cms.program_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=35 and exists
      (select * from zxdbm_cms.program_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.program_picture_map map
      where exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      );
      commit;
      --picture-series-38
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=38 and exists
      (select * from zxdbm_cms.series_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=38 and exists
      (select * from zxdbm_cms.series_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.series_picture_map map
      where exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      );
      commit;
      --picture-channel-39
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=39 and exists
      (select * from zxdbm_cms.channel_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=39 and exists
      (select * from zxdbm_cms.channel_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.channel_picture_map map
      where exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      );
      --picture-cast-41
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=41 and exists
      (select * from zxdbm_cms.cast_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.cnt_target_sync p
      where p.objecttype=41 and exists
      (select * from zxdbm_cms.cast_picture_map map
      where p.objectid=map.mappingid
      and exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      ));

      delete from zxdbm_cms.cast_picture_map map
      where exists
      (select * from zxdbm_cms.picture m,zxdbm_cms.object_cpcnt_record n
      where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
      and n.objectcode=m.picturecode and map.pictureid=m.pictureid
      and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
      and (n.retcode_30=0 or n.retcode_30 is null)
      );

      delete from zxdbm_cms.picture p
      where exists
      (select * from zxdbm_cms.object_cpcnt_record n
       where n.taskindex=i_taskindex and n.objecttype=10 and n.actiontype=3
       and n.objectcode=p.picturecode
       and n.resultcode=2 and (n.retcode_20=0 or n.retcode_20 is null)
       and (n.retcode_30=0 or n.retcode_30 is null)
      );
      commit;

    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,i_taskindex,'picture delete fail:'||v_desc,systime,'sp_imp329_object_delete_timely');
    end; --picture-10 end

end sp_imp329_object_delete_timely;
/


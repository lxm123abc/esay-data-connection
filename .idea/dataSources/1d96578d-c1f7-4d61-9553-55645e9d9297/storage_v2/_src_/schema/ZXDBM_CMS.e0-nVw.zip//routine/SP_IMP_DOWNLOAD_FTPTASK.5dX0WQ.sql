create procedure           sp_imp_download_ftptask
(
	i_taskindex   in  number,
  o_result    out number, ---- 0成功，其他失败
  o_msg       out varchar2 ----结果信息
)
as
  v_taskindex      number(10,0);
  v_endtime      char(14) := to_char(sysdate,'yyyymmddhh24miss'); --最后更新时间
  --v_cyctime      zxdbm_cms.cms_ftptask.retrytimes%type := 0; --同步失败次数
begin
  --v_cyctime :=0;
  v_taskindex:=0;
  o_result := 0;
  o_msg := '';

  --根据入参i_taskindex来查找TASK表的taskindex
  begin
    select taskindex
      into v_taskindex
        from zxdbm_cms.cms_ftptask
        where taskindex >=i_taskindex
              and status =0
              and rownum =1;
  exception
    when no_data_found then
      o_result    := 4013;
      o_msg       := 'can not get anything for' || to_char(i_taskindex);
      return;
    when others then
      o_result    := 1;
      o_msg       := 'query  table zxdbm_cms.cms_ftptask error :sqlcode=' ||
                     sqlcode || ':sqlerrm=' || sqlerrm;
      return;
  end;


  update zxdbm_cms.cms_ftptask c set status = 1, retrytimes = retrytimes - 1, endtime = v_endtime
  where taskindex = v_taskindex returning c.taskindex || '|' ||c.uploadtype || '|' || c.srcfilehandle || '|' || c.srcaddress || '|' || c.destaddress into o_msg;

    commit;
exception
  when others then
    rollback;
    o_result := 4804;
    o_msg := 'zxdbm_cms.cms_ftpdownload_task exception error';
end sp_imp_download_ftptask;
/


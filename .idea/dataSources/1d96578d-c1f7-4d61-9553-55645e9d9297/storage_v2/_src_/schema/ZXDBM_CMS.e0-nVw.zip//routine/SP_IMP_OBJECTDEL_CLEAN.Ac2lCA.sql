create procedure           sp_imp_objectdel_clean
as
  v_overtime     char(14);
  v_savedays     number(3);
  v_retcode      number(10);
  v_desc         varchar2(255);
  v_logindex	 number(10);
  systime        varchar2(14);
begin
	systime := to_char(sysdate,'yyyymmddhh24miss');

    begin
      select to_number(cfgvalue) into v_savedays
      from zxdbm_umap.usys_config
      where cfgkey = 'cms.imp.cpcntdelete.time' and servicekey='CMS';
    exception
      when no_data_found then
      v_savedays := 30;
    end;

    v_overtime := to_char(sysdate - v_savedays, 'yyyymmddhh24miss');

    begin
      --package-1
      delete from zxdbm_cms.service_del m
      where exists
      (
      select * from zxdbm_cms.cnt_platform_sync_del p
      where p.objectid=m.serviceid and p.objecttype=1 and p.cancelpubtime<v_overtime
      );

      delete from zxdbm_cms.cnt_platform_sync_del p
      where p.objecttype=1 and p.cancelpubtime<v_overtime;
      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,0,'service_del clean fail:'||v_desc,systime,'sp_imp_objectdel_clean');
    end;

    begin
      --program-3
      delete from zxdbm_cms.cms_program_del m
      where exists
      (
      select * from zxdbm_cms.cnt_platform_sync_del p
      where p.objectid=m.programid and p.objecttype=3 and p.cancelpubtime<v_overtime
      );

      delete from zxdbm_cms.cnt_platform_sync_del p
      where p.objecttype=3 and p.cancelpubtime<v_overtime;
      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,0,'program_del clean fail:'||v_desc,systime,'sp_imp_objectdel_clean');
    end;

    begin
      --movie-7
      delete from zxdbm_cms.cms_movie_del m
      where m.reserveTime1<v_overtime;

      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,0,'movie_del clean fail:'||v_desc,systime,'sp_imp_objectdel_clean');
    end;

    begin
      --series-4
      delete from zxdbm_cms.cms_series_del m
      where exists
      (
      select * from zxdbm_cms.cnt_platform_sync_del p
      where p.objectid=m.seriesid and p.objecttype=4 and p.cancelpubtime<v_overtime
      );

      delete from zxdbm_cms.cnt_platform_sync_del p
      where p.objecttype=4 and p.cancelpubtime<v_overtime;
      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,0,'series_del clean fail:'||v_desc,systime,'sp_imp_objectdel_clean');
    end;

    begin
      --channel-5
      delete from zxdbm_cms.cms_channel_del m
      where exists
      (
      select * from zxdbm_cms.cnt_platform_sync_del p
      where p.objectid=m.channelid and p.objecttype=5 and p.cancelpubtime<v_overtime
      );
      --physicalchannel
      delete from zxdbm_cms.physicalchannel_del m
      where exists
      (
      select * from zxdbm_cms.cnt_platform_sync_del p
      where p.objectid=m.channelid and p.objecttype=5 and p.cancelpubtime<v_overtime
      );

      delete from zxdbm_cms.cnt_platform_sync_del p
      where p.objecttype=5 and p.cancelpubtime<v_overtime;
      commit;
    exception
      when others then
        rollback;
        v_desc := substr(sqlerrm,1,255);
        zxdbm_umap.sp_getmaxvalue('cms_error_log_index', 1, v_logindex);
        insert into zxdbm_cms.cms_error_log
            (logindex,sourcetype,objindex1,errordesc,errortime,errobjectname)
        values(v_logindex,2,0,'channel_del clean fail:'||v_desc,systime,'sp_imp_objectdel_clean');
    end;
end sp_imp_objectdel_clean;
/


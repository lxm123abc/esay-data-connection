create procedure           sp_imp_object_delete
  as
    v_overtime     char(14);
    v_savedays     number(3);
    v_retcode      number(10);
    v_desc         varchar2(255);
    v_taskindex	   number(10);
  begin

    begin
      select to_number(cfgvalue) into v_savedays
      from zxdbm_umap.usys_config
      where cfgkey = 'cms.imp.cpcntdelete.time' and servicekey='CMS';
    exception
      when no_data_found then
        v_savedays := 30;
    end;

    v_overtime := to_char(sysdate - v_savedays, 'yyyymmddhh24miss');

    begin
      --package-1
      --删除package-program-21
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=21 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_program_map map
       where p.objecttype=1
       and cps.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=21 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_program_map map
       where p.objecttype=1
       and cts.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=1
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-series-22
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=22 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_series_map map
       where p.objecttype=1
       and cps.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=22 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_series_map map
       where p.objecttype=1
       and cts.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=1
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-channel-23
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=23 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_channel_map map
       where p.objecttype=1
       and cps.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=23 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_channel_map map
       where p.objecttype=1
       and cts.objectid=map.mappingid
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=1
       and map.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in(
               select distinct s.servicecode
               from zxdbm_cms.service s, zxdbm_cms.cnt_platform_sync p
               where p.objecttype=1
               and s.serviceid=p.objectid
               and p.isfiledelete=-1
               and p.cancelpubtime<v_overtime
               and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
              )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         1,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.servicecode,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除package正式表记录
      delete from zxdbm_cms.service s
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=1
       and s.serviceid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=1
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select *
       from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=1
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --category-2
      --删除category-program-26
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=26 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_program_map map
       where p.objecttype=2
       and cps.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=26 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_program_map map
       where p.objecttype=2
       and cts.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=2
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-series-27
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=27 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_series_map map
       where p.objecttype=2
       and cps.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=27 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_series_map map
       where p.objecttype=2
       and cts.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=2
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-channel-28
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=28 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_channel_map map
       where p.objecttype=2
       and cps.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=28 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_channel_map map
       where p.objecttype=2
       and cts.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=2
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-category-31
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=31 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_picture_map map
       where p.objecttype=2
       and cps.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=31 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_picture_map map
       where p.objecttype=2
       and cts.objectid=map.mappingid
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=2
       and map.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category正式表记录
      delete from zxdbm_cms.categorycdn c
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=2
       and c.categoryid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=2
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select *
       from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=2
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --program-3
      --删除program-movie-32
      update zxdbm_cms.cms_movie m
      set mappingid=null,
          programindex=null,
          programid=null
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and m.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_crm_map map
       where p.objecttype=3
       and cps.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_crm_map map
       where p.objecttype=3
       and cts.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.program_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-program-35
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=35 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_picture_map map
       where p.objecttype=3
       and cps.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=35 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_picture_map map
       where p.objecttype=3
       and cts.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.program_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --category-program-26
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=26 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_program_map map
       where p.objecttype=3
       and cps.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=26 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_program_map map
       where p.objecttype=3
       and cts.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-program-36
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=36 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_program_map map
       where p.objecttype=3
       and cps.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=36 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_program_map map
       where p.objecttype=3
       and cts.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-program-21
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=21 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_program_map map
       where p.objecttype=3
       and cps.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=21 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_program_map map
       where p.objecttype=3
       and cts.objectid=map.mappingid
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and map.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct prog.cpcontentid
                from zxdbm_cms.cms_program prog, zxdbm_cms.cnt_platform_sync p
                where p.objecttype=3
                and prog.programid=p.objectid
                and p.isfiledelete=-1
                and p.cancelpubtime<v_overtime
                and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
               )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         3,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除program正式表
      delete from zxdbm_cms.cms_program prog
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=3
       and prog.programid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=3
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=3
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --series-4
      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_crm_map map
       where p.objecttype=4
       and cps.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_crm_map map
       where p.objecttype=4
       and cts.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除picture-series-38
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=38 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_picture_map map
       where p.objecttype=4
       and cps.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=38 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_picture_map map
       where p.objecttype=4
       and cts.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-series-27
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=27 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_series_map map
       where p.objecttype=4
       and cps.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=27 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_series_map map
       where p.objecttype=4
       and cts.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-series-22
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=22 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_series_map map
       where p.objecttype=4
       and cps.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=22 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_series_map map
       where p.objecttype=4
       and cts.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-program-36
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=36 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_program_map map
       where p.objecttype=4
       and cps.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=36 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_program_map map
       where p.objecttype=4
       and cts.objectid=map.mappingid
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and map.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series正式表记录
      delete from zxdbm_cms.cms_series s
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=4
       and s.seriesid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=4
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=4
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --channel-5
      --删除picture-channel-39
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=39 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.channel_picture_map map
       where p.objecttype=5
       and cps.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=39 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.channel_picture_map map
       where p.objecttype=5
       and cts.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.channel_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除category-channel-28
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=28 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_channel_map map
       where p.objecttype=5
       and cps.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=28 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.category_channel_map map
       where p.objecttype=5
       and cts.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.category_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除package-channel-23
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=23 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_channel_map map
       where p.objecttype=5
       and cps.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=23 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.service_channel_map map
       where p.objecttype=5
       and cts.objectid=map.mappingid
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.service_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and map.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除schedulerecord
      delete from zxdbm_cms.cms_schedulerecord  sr
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_schedule sch
       where p.objecttype=5
       and sr.scheduleid=sch.scheduleid
       and sch.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct sch.cpcontentid
                from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_schedule sch
                where p.objecttype=5
                and sch.channelid=p.objectid
                and p.isfiledelete=-1
                and p.cancelpubtime<v_overtime
                and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
               )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         6,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除schedule-6
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=6 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_schedule sch
       where p.objecttype=5
       and cps.objectid=sch.scheduleid
       and sch.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=6 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_schedule sch
       where p.objecttype=5
       and cts.objectid=sch.scheduleid
       and sch.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cms_schedule sch
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and sch.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除physicalchannel
      delete from zxdbm_cms.physicalchannel phch
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and phch.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;
      --删除工作流
      for m in (
                select distinct phch.cpcontentid
                from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.physicalchannel phch
                where p.objecttype=5
                and phch.channelid=p.objectid
                and p.isfiledelete=-1
                and p.cancelpubtime<v_overtime
                and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
               )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         8,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除工作流
      for m in (
                select distinct c.cpcontentid
                from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_channel c
                where p.objecttype=5
                and p.objectid=c.channelid
                and p.isfiledelete=-1
                and p.cancelpubtime<v_overtime
                and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
               )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         5,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除channel正式表记录
      delete from zxdbm_cms.cms_channel c
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=5
       and c.channelid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=5
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=5
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --schedule-6
      --删除schedulerecord
      delete from zxdbm_cms.cms_schedulerecord  sr
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=6
       and sr.scheduleid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除工作流
      for m in (
                select distinct sch.cpcontentid
                from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.cms_schedule sch
                where p.objecttype=6
                and p.objectid=sch.scheduleid
                and p.isfiledelete=-1
                and p.cancelpubtime<v_overtime
                and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
               )
      loop
        zxdbm_cms.sp_clear_workflow_data
        (
         6,                 --1-service(package),3-program,5-channel,6-schedule,7-movie,8-physicalchannel;只有这几个对象才有工作流
  	     m.cpcontentid,     --对象的文广code
  	     v_retcode,         --返回值 0-成功
         v_desc             --结果描述信息
        );
      end loop;
      commit;

      --删除schedule正式表记录
      delete from zxdbm_cms.cms_schedule sch
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=6
       and sch.scheduleid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where objecttype=6
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype=6
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --cast-11
      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm, zxdbm_cms.program_crm_map map
       where p.objecttype=11
       and cps.objectid=map.mappingid
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm, zxdbm_cms.program_crm_map map
       where p.objecttype=11
       and cts.objectid=map.mappingid
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.program_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm
       where p.objecttype=11
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm, zxdbm_cms.series_crm_map map
       where p.objecttype=11
       and cps.objectid=map.mappingid
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm, zxdbm_cms.series_crm_map map
       where p.objecttype=11
       and cts.objectid=map.mappingid
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap crm
       where p.objecttype=11
       and crm.castrolemapid=map.castrolemapid
       and crm.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );

      --删除castrolemap-12
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=12 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap map
       where p.objecttype=11
       and cps.objectid=map.castrolemapid
       and map.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=12 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.castrolemap map
       where p.objecttype=11
       and cts.objectid=map.castrolemapid
       and map.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.castrolemap map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=11
       and map.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除cast-11
      delete from zxdbm_cms.castcdn c
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=11
       and c.castid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=11
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      ) ;
      delete from zxdbm_cms.cnt_target_sync t
      where t.objecttype=11
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --castrolemap-12
      --删除program-castrolemap-34
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_crm_map map
       where p.objecttype=12
       and cps.objectid=map.mappingid
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=34 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.program_crm_map map
       where p.objecttype=12
       and cts.objectid=map.mappingid
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.program_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=12
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除series-castrolemap-37
      delete from zxdbm_cms.cnt_platform_sync cps
      where cps.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_crm_map map
       where p.objecttype=12
       and cps.objectid=map.mappingid
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_target_sync cts
      where cts.objecttype=37 and exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p, zxdbm_cms.series_crm_map map
       where p.objecttype=12
       and cts.objectid=map.mappingid
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.series_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=12
       and map.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      commit;

      --删除castrolemap-12
      delete from zxdbm_cms.castrolemap crm
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=12
       and crm.castrolemapid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype=12
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      ) ;
      delete from zxdbm_cms.cnt_target_sync t
      where t.objecttype=12
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    begin
      --package-program-21
      delete from zxdbm_cms.service_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=21
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --package-series-22
      delete from zxdbm_cms.service_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=22
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --package-channel-23
      delete from zxdbm_cms.service_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=23
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --category-program-26
      delete from zxdbm_cms.category_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=26
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --category-series-27
      delete from zxdbm_cms.category_series_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=27
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --category-channel-28
      delete from zxdbm_cms.category_channel_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=28
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --picture-category-31
      delete from zxdbm_cms.category_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=31
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --program-castrolemap-34
      delete from zxdbm_cms.program_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=34
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --picture-program-35
      delete from zxdbm_cms.program_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=35
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --series-program-36
      delete from zxdbm_cms.series_program_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=36
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --series-castrolemap-37
      delete from zxdbm_cms.series_crm_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=37
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --picture-series-38
      delete from zxdbm_cms.series_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=38
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --picture-channel-39
      delete from zxdbm_cms.channel_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=39
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );
      --picture-cast-41
      delete from zxdbm_cms.cast_picture_map map
      where exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.objecttype=41
       and map.mappingid=p.objectid
       and p.isfiledelete=-1
       and p.cancelpubtime<v_overtime
       and not exists (select * from zxdbm_cms.cnt_target_sync t where p.objectid=t.objectid and t.status<>0)
      );

      delete from zxdbm_cms.cnt_platform_sync p
      where p.objecttype in (21,22,23,26,27,28,31,34,35,36,37,38,39,41)
      and p.isfiledelete=-1
      and p.cancelpubtime<v_overtime
      and not exists
      (
       select * from zxdbm_cms.cnt_target_sync t
       where p.objectid=t.objectid and t.status<>0
      );
      delete from zxdbm_cms.cnt_target_sync t
      where objecttype in (21,22,23,26,27,28,31,34,35,36,37,38,39,41)
      and not exists
      (
       select *
       from zxdbm_cms.cnt_platform_sync p
       where p.syncindex=t.relateindex
      );
      commit;
    exception
      when others then
        rollback;
    end;

    -- 20130321 add lxp: 删除游离的movie
    for n in
    (
    	select movieindex,programindex,fileurl
    	from zxdbm_cms.cms_movie
    	where reservesel1=1
    )
    loop
    	if n.programindex is not null then
    		null;
    	else
    		-- insert into ftptask
    		zxdbm_umap.sp_getmaxvalue('cms_ftptask', 1, v_taskindex);
    		if v_taskindex <> 0 then
      			begin
      				insert into zxdbm_cms.cms_ftptask
        			(taskindex, tasktype, filetype, fileindex,uploadtype,srcaddress,status,srcfilehandle)
        			values
        			(v_taskindex,1,1,n.movieindex,5,n.fileurl,0,0);

        			-- delete data
        			delete from zxdbm_cms.cms_movie where movieindex=n.movieindex;
        		exception
    				when others then
    					null;
    			end;
    		end if;
    	end if;
    	commit;
    end loop;
    commit;
  exception
    when others then
      rollback;
  end sp_imp_object_delete;
/


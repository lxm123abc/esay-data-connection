create procedure           sp_imp_update_ftptask
(
  i_taskindex    in  number,   --同步任务记录ID
  i_operateindex in  number,   --状态更新或移入历史表标识，2-正常的下载处理,3-把长时间状态为1的设备为0
  i_filesize     in  varchar2, --zxdbm_cms.icm_file.filesize or zxdbm_cms.icm_source.filesize
  i_resultcode   in  number,   --操作结果标识:成功-0，失败-非零
  i_resultmsg    in  varchar2, --操作结果说明
  o_result       out number,   --执行结果
  o_position     out number,   --位置信息
  o_msg          out varchar2  --结果信息
)
as
  v_systime      char(14) := to_char(sysdate, 'yyyymmddhh24miss');
  v_yestime      char(14) := to_char(sysdate - 1, 'yyyymmddhh24miss');  --读取前一天的时间
  v_count        number(3);  --记录数
  v_tasktype     zxdbm_cms.cms_ftptask.tasktype%type;
  v_batchid      zxdbm_cms.cms_ftptask.batchid%type;
  v_movieindex   number(10); --movie主键
  v_movieid      varchar2(32);
  v_programid    varchar2(32); --program ID
  v_oldfilestatus number(3);
  v_addresspath  varchar2(1024);
  v_filetype     number(3);
  v_resultcode   number(3);
  v_uploadtype   number(3);
  v_movietype    number(3);
  v_cpnoauditcnt number(10);
begin

  --初始化返参
  o_result:=10000;
  o_position:=0;
  o_msg := '';

  --入参校验
  if( i_operateindex not in (2,3) )then
    o_result    :=10101;
    o_position  :=1;
    o_msg       := 'illegal operate index';
    return;
  end if;

  if(i_operateindex=2 and i_taskindex is null)then
    o_result:=10102;
    o_position:=2;
    o_msg := 'illegal task index';
    return;
  end if;

  if(i_operateindex=2 and i_resultcode is null )then
    o_result    :=10103;
    o_position  :=3;
    o_msg       := 'illegal result code';
    return;
  else
    if(i_resultcode=0)then
      v_resultcode:=0;
    else
      v_resultcode:=1;
    end if;
  end if;

  --将长时间中间状态的任务改成初始状态
  if (i_operateindex = 3) then
    --重试次数 > 0 的记录状态改成初始状态
    update zxdbm_cms.cms_ftptask set status = 0 where status = 1 and retrytimes > 0 and (endtime < v_yestime or endtime is null);

    --重试次数 = 0 的记录改成失败
    --tasktype 1-icm_file;2-icm_sourcefile
    for c in(select tasktype, taskindex, fileindex, uploadtype, srcaddress, destaddress, resultdesc from zxdbm_cms.cms_ftptask where status = 1 and v_yestime > endtime
        and retrytimes = 0 and tasktype = 1)
    loop
      update zxdbm_cms.cms_ftptask
      set status = case when c.uploadtype <= 3 then 3 else 5 end, resultdesc = i_resultmsg, endtime = v_systime
      where taskindex = c.taskindex;

      --file.status  fail
      select count(*) into v_count from zxdbm_cms.cms_movie where movieindex = c.fileindex;
      if (v_count > 0) then
        select status, movieid, fileurl, movietype
        into v_oldfilestatus, v_movieid, v_addresspath, v_filetype
        from zxdbm_cms.cms_movie where movieindex = c.fileindex;

        --fail log
        insert into zxdbm_cms.imp_ftp_fail
        (
          taskindex, tasktype, fileid, filestatus, uploadtype, fromurl, tourl, failtime, errordesc
        )
        values
        (
          c.taskindex, c.tasktype, v_movieid, v_oldfilestatus, c.uploadtype, c.srcaddress, c.destaddress, v_systime, c.resultdesc
        );
      end if;

      --move to history
      insert into zxdbm_cms.cms_ftptask_his select * from zxdbm_cms.cms_ftptask where taskindex = c.taskindex;
      delete from zxdbm_cms.cms_ftptask where  taskindex = c.taskindex;
    end loop;
  elsif(i_operateindex =2) then
    begin
      select tasktype, fileindex into v_tasktype, v_movieindex from zxdbm_cms.cms_ftptask where taskindex=i_taskindex;
    exception
      when others then
        o_result    :=10104;
        o_position  :=4;
        o_msg       := 'the task do not exists';
        return;
    end;

    if(v_tasktype=1)then
      --更新任务状态
      update zxdbm_cms.cms_ftptask set status = case when uploadtype = 3 then decode(v_resultcode,0,2,1,3,3) else decode(v_resultcode,0,4,1,5,5) end, endtime=v_systime, resultdesc = i_resultmsg where taskindex = i_taskindex
      returning uploadtype, filetype into v_uploadtype, v_filetype;

      --更新该任务对应的movie的状态
      if (v_filetype=1 and v_uploadtype=3)then
        --添加点播字内容时区分预览片和正片，如果添加的是正片，则添加成功后若该点播内容所属CP为免审CP，该点播子内容（正片）的状态为审核通过，点播内容状态为审核通过，若不是免审CP，则点播内容和子内容都为待审核
        select movietype,programid into v_movietype,v_programid from zxdbm_cms.cms_movie where movieindex=v_movieindex;
        select count(1)　into v_cpnoauditcnt from zxdbm_cms.cms_lpop_noaudit cpnoaudit where cpnoaudit.lptype = 4 and cpnoaudit.cpid = (select cpid from zxdbm_cms.cms_program where programid = v_programid);

        if(v_movietype=1)then
           if(v_cpnoauditcnt>0)then
               update zxdbm_cms.cms_movie set status=decode(v_resultcode,0,0,1,100,100), filesize=nvl(i_filesize,0) where movieindex=v_movieindex;

               select count(*) into v_count from zxdbm_cms.cms_movie where programid=v_programid and status<>0;

               if(v_count=0)then
                   update zxdbm_cms.cms_program set status=0 where programid=v_programid;
               end if;
           else
               update zxdbm_cms.cms_movie set status=decode(v_resultcode,0,110,1,100,100), filesize=nvl(i_filesize,0) where movieindex=v_movieindex;

               select count(*) into v_count from zxdbm_cms.cms_movie where programid=v_programid and status<>110;

               if(v_count=0)then
                   update zxdbm_cms.cms_program set status=110 where programid=v_programid;
               end if;
           end if;
        elsif(v_movietype=2)then
           if(v_cpnoauditcnt>0)then
               update zxdbm_cms.cms_movie set status=decode(v_resultcode,0,0,1,100,100), filesize=nvl(i_filesize,0) where movieindex=v_movieindex;

               select count(*) into v_count from zxdbm_cms.cms_movie where programid=v_programid and movietype = 1 and status=0;
               if(v_count=0)then
                   update zxdbm_cms.cms_program set status=110 where programid=v_programid;
               end if;
           else
               update zxdbm_cms.cms_movie set status=decode(v_resultcode,0,110,1,100,100), filesize=nvl(i_filesize,0) where movieindex=v_movieindex;

               select count(*) into v_count from zxdbm_cms.cms_movie where programid=v_programid and status<>110;

               if(v_count=0)then
                   update zxdbm_cms.cms_program set status=110 where programid=v_programid;
               end if;
           end if;
        end if;
      end if;

      --将任务移到历史表中
      insert into zxdbm_cms.cms_ftptask_his select * from zxdbm_cms.cms_ftptask where taskindex = i_taskindex;
      delete from zxdbm_cms.cms_ftptask where taskindex = i_taskindex;
    end if;
  end if;

  o_position:=999;
  o_result:=0;
  o_msg:='update ftp task successfully';
  commit;
exception
  when others then
    rollback;
    o_position:=888;
    o_result:=10000;
    o_msg:=substr(sqlerrm,0,255);
    return;
end sp_imp_update_ftptask;
/


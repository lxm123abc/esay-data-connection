create procedure           sp_job_minute_cmsc2imp329
as
  v_taskindex        number(10);
  v_count            number(10);
  v_correlateid_20   varchar2(32);
  v_correlateid_bms  varchar2(32);
  v_correlateid_epg  varchar2(32);
  v_correlateid_cdn  varchar2(32);
  v_xmlurl_20        varchar2(256);
  v_xmlurl_bms       varchar2(256);
  v_xmlurl_epg       varchar2(256);
  v_xmlurl_cdn       varchar2(256);
  v_retcode          number(10);
  v_desc             varchar2(255);
  v_step             number(10);
  v_num              number(10);
begin
  --init
  v_taskindex := 0 ;
  v_count := 0;
  v_num := 0;


  --重新执行已解锁的任务
  while (1 = 1) loop
    v_count := v_count + 1;
    v_taskindex := zxdbm_cms.package_icm_task.f_synctask_search;
    if (v_taskindex  = 0 or v_count >= 50 ) then
      exit;
    end if;
    v_correlateid_20 := null;
    v_correlateid_bms := null;
    v_correlateid_epg := null;
    v_correlateid_cdn := null;
    v_xmlurl_20 := null;
    v_xmlurl_bms := null;
    v_xmlurl_epg := null;
    v_xmlurl_cdn := null;

    --当下面的循环次数为0时不进行deal处理
    v_step := 0;
    for m in (
              select correlateid,syncxmlurl,desttype
              from zxdbm_cms.imp_sh_locked_task_tmp
              where wg_taskindex=v_taskindex and lockflag=0
             )
    loop
      v_step := v_step + 1;
      if (m.desttype = 0) then
        v_correlateid_20 := m.correlateid;
        v_xmlurl_20 := m.syncxmlurl;
      elsif (m.desttype = 1) then
        v_correlateid_bms := m.correlateid;
        v_xmlurl_bms := m.syncxmlurl;
      elsif (m.desttype = 2) then
        v_correlateid_epg := m.correlateid;
        v_xmlurl_epg := m.syncxmlurl;
      elsif (m.desttype = 3) then
        v_correlateid_cdn := m.correlateid;
        v_xmlurl_cdn := m.syncxmlurl;
      end if;
    end loop;

    if(v_step > 0)then
      --防止定时任务并发执行
      --by lsm 20130819
      zxdbm_cms.sp_update_locked_task_status
      (
       v_taskindex,  --正在解锁的任务号
       1,            -- 0-待解锁    1-正在解锁中
       v_num,        -- 更新的行数
       v_retcode,    -- 结果码 0-成功
       v_desc        -- 结果描述信息
      );
      if((v_retcode = 0) and (v_num = v_step))then
        --生成下游任务
        zxdbm_cms.package_imp_icm.sp_imp_synctask_deal
        (
         v_taskindex,        -- 上游同步任务主键
         0,                  -- 操作结果 0-成功 非0-失败
         v_correlateid_20,   -- iptv2.0 对象日志对应的流水号
         v_correlateid_cdn,  -- cdn 对象日志对应的流水号
         v_correlateid_bms,  -- bms 对象日志对应的流水号
         v_correlateid_epg,  -- epg 对象日志对应的流水号
         v_xmlurl_20,        -- iptv2.0 同步任务xml路径
         v_xmlurl_cdn,       -- cdn 同步任务xml路径
         v_xmlurl_bms,       -- bms 同步任务xml路径
         v_xmlurl_epg,       -- epg 同步任务xml路径
         v_retcode,          -- 结果码 0-成功
         v_desc              -- 结果描述信息
        );

        if(v_retcode = 0) then
          delete from zxdbm_cms.imp_sh_locked_task_tmp
          where wg_taskindex=v_taskindex;
        else
          update zxdbm_cms.imp_sh_locked_task_tmp
          set endtime=to_char(sysdate,'yyyymmddhh24miss'),
              status=2,
              description=v_desc
          where wg_taskindex=v_taskindex;
          zxdbm_cms.sp_update_locked_task_status
          (
           v_taskindex,  --正在解锁的任务号
           0,            -- 0-待解锁    1-正在解锁中
           v_num,        -- 更新的行数
           v_retcode,    -- 结果码 0-成功
           v_desc        -- 结果描述信息
          );
        end if;
      end if;
    end if;
  end loop;

  commit;

end sp_job_minute_cmsc2imp329;
/


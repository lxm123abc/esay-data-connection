create procedure           sp_update_locked_task_status
(
 i_taskindex  in  number,   --解锁任务号
 i_status     in  number,   --0-待解锁   1-正在解锁中
 o_updatenum  out number,   --更新数据行数
 o_retcode    out number,   --0-成功   1-失败
 o_retdesc    out varchar2  --返回结果描述
)
as
  pragma autonomous_transaction;
begin
  o_updatenum := 0;
  o_retcode := 0;
  o_retdesc := 'success';

  update zxdbm_cms.imp_sh_locked_task_tmp
  set lockflag=i_status
  where wg_taskindex=i_taskindex and lockflag=decode(i_status,0,1,1,0,0);
  o_updatenum := sql%rowcount;
  commit;
exception
  when others then
    o_retcode := 1;
    o_retdesc := substr(sqlerrm,1,255);
end sp_update_locked_task_status;
/


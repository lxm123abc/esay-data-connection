create view V_CATEGORY_CONTENT as
select
     ctg.categoryname,          --栏目名称
     cp.categoryid,             --栏目id
     ctg.catagorycode,          --栏目文广编码
     3 as contenttype,          --内容类型 3-点播内容 4-连续剧 5-直播频道
     p.namecn,                  --内容名称
     cp.programid as contentid, --内容id
     p.cpcontentid,             --内容文广编码
     p.cpid,                    --cpid,内容提供商id
     ucp.cpcnshortname          --cp名称,内容提供商名称
from zxdbm_cms.category_program_map cp
     left join zxdbm_cms.categorycdn ctg on cp.categoryid = ctg.categoryid
     left join zxdbm_cms.cms_program p on cp.programindex = p.programindex
     left join zxdbm_umap.ucp_basic ucp on p.cpid = ucp.cpid and ucp.cptype =1
union all
select
     ctg.categoryname,          --栏目名称
     cs.categoryid,             --栏目id
     ctg.catagorycode,          --栏目文广编码
     4 as contenttype,          --内容类型 3-点播内容 4-连续剧 5-直播频道
     s.namecn,                  --内容名称
     cs.seriesid as contentid,  --内容id
     s.cpcontentid,             --内容文广编码
     s.cpid,                    --cpid,内容提供商id
     ucp.cpcnshortname          --cp名称,内容提供商名称
from category_series_map cs
     left join zxdbm_cms.categorycdn ctg on cs.categoryid = ctg.categoryid
     left join zxdbm_cms.cms_series s on cs.seriesindex = s.seriesindex
     left join zxdbm_umap.ucp_basic ucp on s.cpid = ucp.cpid and ucp.cptype =1
union all
select
     ctg.categoryname,          --栏目名称
     cc.categoryid,             --栏目id
     ctg.catagorycode,          --栏目文广编码
     5 as contenttype,          --内容类型 3-点播内容 4-连续剧 5-直播频道
     c.channelname as namecn,   --内容名称
     cc.channelid as contentid, --内容id
     c.cpcontentid,             --内容文广编码
     c.cpid,                    --cpid,内容提供商id
     ucp.cpcnshortname          --cp名称,内容提供商名称
from category_channel_map cc
     left join zxdbm_cms.categorycdn ctg on cc.categoryid = ctg.categoryid
     left join zxdbm_cms.cms_channel c on cc.channelindex = c.channelindex
     left join zxdbm_umap.ucp_basic ucp on c.cpid = ucp.cpid and ucp.cptype =1
/


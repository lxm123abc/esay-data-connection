create view V_SERIES_PROGRAM as
select s.seriesid,               --连续剧id
       s.namecn seriesname,      --连续剧名称
       s.cpid scpid,             --连续剧cpid，连续剧的内容提供商id
       cp.cpcnshortname scpname, --连续剧cp名称，连续剧的内容提供商名称
       sp.programid,             --连续剧单集id
       p.namecn programname,     --连续剧单集名称
       p.cpid pcpid,             --连续剧单集cpid，连续剧单集的内容提供商id
       cp.cpcnshortname pcpname  --连续剧单集cp名称，连续剧单集的内容提供商名称
from zxdbm_cms.cms_series s
     right join zxdbm_cms.series_program_map sp on s.seriesid = sp.seriesid
     left join zxdbm_cms.cms_program p on sp.programid = p.programid
     left join zxdbm_umap.ucp_basic cp on s.cpid = cp.cpid and cp.cptype =1
group by s.seriesid,s.namecn,s.cpid,cp.cpcnshortname,sp.programid,p.namecn,p.cpid,cp.cpcnshortname
/

